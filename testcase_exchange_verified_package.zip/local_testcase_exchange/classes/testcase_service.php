<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Testcase workflow service.
 *
 * @package    local_testcase_exchange
 * @copyright  2026 Nguyen Quoc Thinh
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_testcase_exchange;

/**
 * Application service for private runs, contributions, review and rewards.
 */
final class testcase_service {
    /** @var \mysqli External repository connection. */
    private \mysqli $connection;

    /**
     * Create the workflow service.
     *
     * @param \mysqli $connection External repository connection.
     */
    public function __construct(\mysqli $connection) {
        $this->connection = $connection;
    }

    /**
     * Unescape literal \n or \r\n characters if a string was flattened without real newlines.
     *
     * @param string $text Source text.
     * @return string Sanitized text with real newlines.
     */
    public static function sanitize_multiline_text(string $text): string {
        if (strpos($text, "\n") === false && strpos($text, "\\n") !== false) {
            return str_replace(["\\r\\n", "\\n", "\\r"], "\n", $text);
        }
        return $text;
    }

    /**
     * Return settings for a Quiz.
     *
     * @param int $quizid Quiz ID.
     * @return array Quiz settings.
     */
    public function quiz_settings(int $quizid): array {
        $stmt = $this->connection->prepare('SELECT * FROM quiz_settings WHERE quiz_id = ?');
        $stmt->bind_param('i', $quizid);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?: [
            'quiz_id' => $quizid, 'enabled' => 0, 'review_mode' => 'teacher',
            'reward_policy' => 'one_for_one', 'show_oracle_output' => 1,
            'leaderboard_enabled' => 1, 'max_runs_per_minute' => 10, 'max_input_bytes' => 8192,
        ];
    }

    /**
     * Return execution policy for a question.
     *
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param string $coderunnertype CodeRunner question type.
     * @return array Question policy.
     */
    public function question_policy(int $quizid, int $questionid, string $coderunnertype = ''): array {
        $stmt = $this->connection->prepare('SELECT * FROM question_policies WHERE quiz_id = ? AND question_id = ?');
        $stmt->bind_param('ii', $quizid, $questionid);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            return $row;
        }
        return [
            'quiz_id' => $quizid,
            'question_id' => $questionid,
            'input_mode' => str_contains($coderunnertype, 'program') ? 'stdin' : 'testcode',
            'testcode_template' => '',
            'normalization_mode' => 'trim',
            'categories' => 'normal,boundary,empty,invalid,large,branch,other',
        ];
    }

    /**
     * Execute and store a private testcase run.
     *
     * @param int $courseid Course ID.
     * @param \stdClass $quiz Quiz record.
     * @param \stdClass $questioncontext Validated question context.
     * @param int $userid User ID.
     * @param string $studentsource Student source.
     * @param string $input Raw input.
     * @param string $predicted Predicted output.
     * @param string $purpose Test purpose.
     * @param string $category Test category.
     * @param string $reflection Student reflection.
     * @return array Created run result.
     */
    public function create_run(
        int $courseid,
        \stdClass $quiz,
        \stdClass $questioncontext,
        int $userid,
        string $studentsource,
        string $input,
        string $predicted,
        string $purpose,
        string $category,
        string $reflection
    ): array {
        $studentsource = self::sanitize_multiline_text($studentsource);
        $input = self::sanitize_multiline_text($input);
        $settings = $this->quiz_settings((int) $quiz->id);
        if (empty($settings['enabled'])) {
            throw new \moodle_exception('featuredisabled', 'local_testcase_exchange');
        }
        if (strlen($input) > (int) $settings['max_input_bytes']) {
            throw new \moodle_exception('inputtoolarge', 'local_testcase_exchange');
        }
        $this->enforce_rate_limit($userid, (int) $quiz->id, (int) $settings['max_runs_per_minute']);
        $policy = $this->question_policy(
            (int) $quiz->id,
            (int) $questioncontext->questionid,
            (string) $questioncontext->coderunnertype
        );
        try {
            $normalized = normalizer::normalize($input, (string) $policy['normalization_mode']);
        } catch (\JsonException $e) {
            throw new \moodle_exception('invalidjsoninput', 'local_testcase_exchange');
        }
        $fingerprint = normalizer::fingerprint($normalized);
        $sourcehash = hash('sha256', $studentsource);
        $rawinputhash = hash('sha256', $input);
        $qid = (int) $questioncontext->questionid;

        // Tải context để lấy oracle_version_hash và sample testcases
        $execcontext = execution_service::resolve_context($qid, $policy);
        $oracleversionhash = (string) $execcontext['oracle_version_hash'];

        // Kiểm tra chống spam & giảm tải: Khóa tra cứu bao quát input thô, mã sinh viên và phiên bản oracle
        $duplicatestmt = $this->connection->prepare(
            'SELECT id, student_run_output, oracle_output, student_outcome, oracle_outcome,
                    predicted_output, jobe_server, created_at, code_revision_id
               FROM testcase_runs
              WHERE user_id = ?
                AND question_id = ?
                AND input_raw_hash = ?
                AND student_source_hash = ?
                AND oracle_version_hash = ?
              ORDER BY id DESC LIMIT 1'
        );
        $duplicatestmt->bind_param('iisss', $userid, $qid, $rawinputhash, $sourcehash, $oracleversionhash);
        $duplicatestmt->execute();
        $existingrun = $duplicatestmt->get_result()->fetch_assoc();
        $duplicatestmt->close();

        if ($existingrun) {
            $is_same_prediction = (trim((string) $existingrun['predicted_output']) === trim((string) $predicted));
            if ($is_same_prediction) {
                // Toàn bộ code, input và expected đều giống hệt -> Chặn hoàn toàn và trả lại lượt chạy cũ
                return [
                    'id' => (int) $existingrun['id'],
                    'is_duplicate_run' => true,
                    'student' => [
                        'outcome' => $existingrun['student_outcome'],
                        'output' => $existingrun['student_run_output'],
                        'server' => $existingrun['jobe_server'],
                    ],
                    'oracle' => [
                        'outcome' => $existingrun['oracle_outcome'],
                        'output' => $existingrun['oracle_output'],
                        'server' => $existingrun['jobe_server'],
                    ],
                    'input' => $input,
                    'normalized' => $normalized,
                    'fingerprint' => $fingerprint,
                    'code_revision_id' => $existingrun['code_revision_id'],
                ];
            }

            // Sinh viên điều chỉnh Expected Output: Tái sử dụng 100% kết quả thực thi Jobe cũ nhưng ghi nhận dự đoán mới
            $cached_results = [
                'student' => [
                    'outcome' => $existingrun['student_outcome'],
                    'output' => $existingrun['student_run_output'],
                    'server' => 'cached',
                ],
                'oracle' => [
                    'outcome' => $existingrun['oracle_outcome'],
                    'output' => $existingrun['oracle_output'],
                    'server' => 'cached',
                ],
                'oracle_solution' => (string) ($execcontext['oracle_solution'] ?? ''),
                'template' => (string) ($execcontext['template'] ?? ''),
                'question_version' => (int) ($execcontext['question_version'] ?? 1),
                'grader_type' => (string) ($execcontext['grader_type'] ?? 'EqualityGrader'),
                'oracle_version_hash' => $oracleversionhash,
                'test_suite_version_hash' => (string) ($execcontext['test_suite_version_hash'] ?? ''),
                'execution_limits' => (string) ($execcontext['execution_limits'] ?? ''),
            ];
            $server = 'cached';
            $runtimecontext = json_encode([
                'coderunnertype' => (string) ($questioncontext->coderunnertype ?? ''),
                'input_mode' => (string) ($policy['input_mode'] ?? 'testcode'),
                'normalization_mode' => (string) ($policy['normalization_mode'] ?? 'trim'),
                'jobe_server' => 'cached',
                'prediction_updated' => true,
                'timestamp' => date('c'),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            return $this->persist_run_record(
                $courseid, $quiz, $questioncontext, $userid,
                $studentsource, $input, $normalized, $fingerprint, $rawinputhash, $sourcehash,
                $predicted, $purpose, $category, $reflection,
                $cached_results, $server, $runtimecontext
            );
        }

        // Tra cứu bộ nhớ đệm kết quả Solution: Khóa cache phải khớp input thô và phiên bản Lời giải mẫu
        $cachedoracle = null;
        $oraclestmt = $this->connection->prepare(
            'SELECT oracle_output, oracle_outcome, jobe_server 
               FROM testcase_runs 
              WHERE question_id = ? AND input_raw_hash = ? AND oracle_version_hash = ? AND oracle_outcome = "success" 
              ORDER BY id DESC LIMIT 1'
        );
        $oraclestmt->bind_param('iss', $qid, $rawinputhash, $oracleversionhash);
        $oraclestmt->execute();
        $oraclerow = $oraclestmt->get_result()->fetch_assoc();
        $oraclestmt->close();
        if ($oraclerow && trim((string)$oraclerow['oracle_output']) !== '') {
            $cachedoracle = [
                'outcome' => $oraclerow['oracle_outcome'],
                'output' => $oraclerow['oracle_output'],
                'server' => 'cached',
            ];
        }

        $results = execution_service::run_pair(
            (int) $questioncontext->questionid,
            $studentsource,
            $input,
            $policy,
            $quiz,
            $cachedoracle
        );
        $server = $results['student']['server'] ?: $results['oracle']['server'];
        $studentsnapshot = $studentsource;
        $oraclesnapshot = (string) ($results['oracle_solution'] ?? '');
        $templatesnapshot = (string) ($results['template'] ?? '');
        $runtimecontext = json_encode([
            'coderunnertype' => (string) ($questioncontext->coderunnertype ?? ''),
            'input_mode' => (string) ($policy['input_mode'] ?? 'testcode'),
            'normalization_mode' => (string) ($policy['normalization_mode'] ?? 'trim'),
            'jobe_server' => $server,
            'timestamp' => date('c'),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return $this->persist_run_record(
            $courseid, $quiz, $questioncontext, $userid,
            $studentsource, $input, $normalized, $fingerprint, $rawinputhash, $sourcehash,
            $predicted, $purpose, $category, $reflection,
            $results, $server, $runtimecontext
        );
    }

    /**
     * Persist run execution record and calculate prediction matching.
     */
    private function persist_run_record(
        int $courseid,
        \stdClass $quiz,
        \stdClass $questioncontext,
        int $userid,
        string $studentsource,
        string $input,
        string $normalized,
        string $fingerprint,
        string $rawinputhash,
        string $sourcehash,
        string $predicted,
        string $purpose,
        string $category,
        string $reflection,
        array $results,
        string $server,
        string $runtimecontext
    ): array {
        $qversion = (int) ($results['question_version'] ?? 1);
        $gradertype = (string) ($results['grader_type'] ?? 'EqualityGrader');
        $oracleversionhash = (string) ($results['oracle_version_hash'] ?? '');
        $testsuiteversionhash = (string) ($results['test_suite_version_hash'] ?? '');
        $executionlimits = (string) ($results['execution_limits'] ?? '');
        $oraclesnapshot = (string) ($results['oracle_solution'] ?? '');
        $templatesnapshot = (string) ($results['template'] ?? '');
        $studentsnapshot = $studentsource;

        // Persist solution version immutably
        if ($oraclesnapshot !== '') {
            $this->ensure_solution_version(
                $courseid,
                (int) $quiz->id,
                (int) $questioncontext->questionid,
                $oraclesnapshot,
                $templatesnapshot,
                $qversion
            );
        }

        $revinfo = $this->record_or_get_code_revision(
            $courseid,
            (int) $quiz->id,
            (int) $questioncontext->questionid,
            $userid,
            $studentsource
        );
        $coderevisionid = $revinfo['id'] !== null ? (int) $revinfo['id'] : null;

        $stmt = $this->connection->prepare(
            'INSERT INTO testcase_runs
            (course_id, quiz_id, question_id, user_id, code_revision_id, input_raw, input_raw_hash, input_normalized, input_fingerprint,
             predicted_output, student_run_output, oracle_output, student_outcome, oracle_outcome,
             purpose, category, reflection, jobe_server, student_source_hash,
             student_code_snapshot, oracle_solution_snapshot, template_snapshot, runtime_context,
             question_version, grader_type, oracle_version_hash, test_suite_version_hash, execution_limits)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $quizid = (int) $quiz->id;
        $questionid = (int) $questioncontext->questionid;
        $studentoutput = $results['student']['output'];
        $oracleoutput = $results['oracle']['output'];
        $studentoutcome = $results['student']['outcome'];
        $oracleoutcome = $results['oracle']['outcome'];
        $stmt->bind_param(
            'iiiiissssssssssssssssssissss',
            $courseid,
            $quizid,
            $questionid,
            $userid,
            $coderevisionid,
            $input,
            $rawinputhash,
            $normalized,
            $fingerprint,
            $predicted,
            $studentoutput,
            $oracleoutput,
            $studentoutcome,
            $oracleoutcome,
            $purpose,
            $category,
            $reflection,
            $server,
            $sourcehash,
            $studentsnapshot,
            $oraclesnapshot,
            $templatesnapshot,
            $runtimecontext,
            $qversion,
            $gradertype,
            $oracleversionhash,
            $testsuiteversionhash,
            $executionlimits
        );
        $stmt->execute();
        $runid = (int) $stmt->insert_id;
        $stmt->close();

        return [
            'id' => $runid,
            'is_duplicate_run' => false,
            'student' => $results['student'],
            'oracle' => $results['oracle'],
            'prediction_matches_oracle' => $oracleoutcome === 'success' &&
                trim($predicted) !== '' &&
                trim($predicted) === trim($oracleoutput),
        ];
    }

    /**
     * Submit an owned private run as a contribution.
     *
     * @param int $runid Run ID.
     * @param int $userid Owner user ID.
     * @return array Contribution ID and status.
     */
    public function submit_contribution(int $runid, int $userid): array {
        $run = $this->owned_run($runid, $userid);
        $existingstmt = $this->connection->prepare(
            'SELECT id, status FROM testcase_contributions WHERE run_id = ?'
        );
        $existingstmt->bind_param('i', $runid);
        $existingstmt->execute();
        $existing = $existingstmt->get_result()->fetch_assoc();
        $existingstmt->close();
        if ($existing) {
            return ['id' => (int) $existing['id'], 'status' => $existing['status']];
        }
        if ($run['oracle_outcome'] !== 'success') {
            throw new \moodle_exception('oraclenotsuccessful', 'local_testcase_exchange');
        }
        if (trim((string) $run['predicted_output']) === '' ||
            trim((string) $run['predicted_output']) !== trim((string) $run['oracle_output'])) {
            throw new \moodle_exception('predictionmismatchoracle', 'local_testcase_exchange', '',
                'Kết quả kỳ vọng (Expected Output) không khớp với Solution của Thầy/Cô nên không thể đề xuất đóng góp!');
        }
        if ($run['student_outcome'] !== 'success' ||
            trim((string) $run['student_run_output']) !== trim((string) $run['oracle_output'])) {
            throw new \moodle_exception('studentcodenotpassing', 'local_testcase_exchange', '',
                'Kết quả mong đợi của bạn đã được xác nhận. Chương trình hiện tại chưa vượt qua testcase này. Hãy sửa chương trình và chạy lại để đủ điều kiện đóng góp.');
        }
        $settings = $this->quiz_settings((int) $run['quiz_id']);
        $this->connection->begin_transaction();
        try {
            $status = 'submitted';
            $runpk = (int) $run['id'];
            $courseid = (int) $run['course_id'];
            $quizid = (int) $run['quiz_id'];
            $questionid = (int) $run['question_id'];
            $normalized = (string) $run['input_normalized'];
            $fingerprint = (string) $run['input_fingerprint'];
            $oracleoutput = (string) $run['oracle_output'];
            $purpose = (string) $run['purpose'];
            $category = (string) $run['category'];
            $stmt = $this->connection->prepare(
                'INSERT INTO testcase_contributions
                (run_id, course_id, quiz_id, question_id, user_id, input_normalized, input_fingerprint,
                 oracle_output, purpose, category, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->bind_param(
                'iiiiissssss',
                $runpk,
                $courseid,
                $quizid,
                $questionid,
                $userid,
                $normalized,
                $fingerprint,
                $oracleoutput,
                $purpose,
                $category,
                $status
            );
            $stmt->execute();
            $contributionid = (int) $stmt->insert_id;
            $stmt->close();

            $claim = $this->connection->prepare(
                'INSERT IGNORE INTO testcase_canonical_keys
                (course_id, quiz_id, question_id, input_fingerprint, canonical_contribution_id)
                VALUES (?, ?, ?, ?, ?)'
            );
            $claim->bind_param(
                'iiisi',
                $courseid,
                $quizid,
                $questionid,
                $fingerprint,
                $contributionid
            );
            $claim->execute();
            $isownduplicate = false;
            $canonical = null;
            if ($claim->affected_rows === 0) {
                $canonical = $this->canonical_id($run);
                $status = 'duplicate';

                $ownerstmt = $this->connection->prepare('SELECT user_id FROM testcase_contributions WHERE id = ?');
                $ownerstmt->bind_param('i', $canonical);
                $ownerstmt->execute();
                $canonicaluser = (int) ($ownerstmt->get_result()->fetch_assoc()['user_id'] ?? 0);
                $ownerstmt->close();
                $isownduplicate = ($canonicaluser === $userid);

                $update = $this->connection->prepare(
                    'UPDATE testcase_contributions SET status = ?, duplicate_of = ? WHERE id = ?'
                );
                $update->bind_param('sii', $status, $canonical, $contributionid);
                $update->execute();
                $update->close();

                $note = $isownduplicate ? 'Duplicate of own contribution #' . $canonical : 'Exact fingerprint duplicate';
                $this->insert_review($contributionid, 0, 'submitted', 'duplicate', $note);
            } else if ($settings['review_mode'] === 'auto') {
                $status = 'approved';
                $update = $this->connection->prepare('UPDATE testcase_contributions SET status = ? WHERE id = ?');
                $update->bind_param('si', $status, $contributionid);
                $update->execute();
                $update->close();
                $this->insert_review($contributionid, 0, 'submitted', 'approved', 'Automatically approved by Quiz policy');
                $this->grant_reward_for_contribution($contributionid);
            }
            $claim->close();
            $this->connection->commit();
            return [
                'id' => $contributionid,
                'status' => $status,
                'is_own_duplicate' => $isownduplicate,
                'canonical_id' => $canonical,
            ];
        } catch (\Throwable $e) {
            $this->connection->rollback();
            throw $e;
        }
    }

    /**
     * Apply a review transition and audit it.
     *
     * @param int $contributionid Contribution ID.
     * @param int $courseid Course ID.
     * @param int $reviewerid Reviewer user ID.
     * @param string $newstatus Requested status.
     * @param string $note Review note.
     */
    public function review(
        int $contributionid,
        int $courseid,
        int $reviewerid,
        string $newstatus,
        string $note = '',
        int $rating = 0,
        string $ratingreason = ''
    ): void {
        $allowed = ['approved', 'rejected', 'needs_explanation', 'archived', 'rate_only'];
        if (!in_array($newstatus, $allowed, true)) {
            throw new \moodle_exception('invalidstatus', 'local_testcase_exchange');
        }
        $stmt = $this->connection->prepare(
            'SELECT status, rating, review_comment FROM testcase_contributions WHERE id = ? AND course_id = ? FOR UPDATE'
        );
        $this->connection->begin_transaction();
        try {
            $stmt->bind_param('ii', $contributionid, $courseid);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$row) {
                throw new \moodle_exception('invalidcontribution', 'local_testcase_exchange');
            }
            $from = $row['status'];
            $targetstatus = ($newstatus === 'rate_only') ? $from : $newstatus;

            if ($targetstatus !== $from) {
                $transitions = [
                    'submitted' => ['approved', 'rejected', 'needs_explanation'],
                    'needs_explanation' => ['approved', 'rejected'],
                    'approved' => ['archived', 'rejected'],
                    'rejected' => ['approved'],
                ];
                if (!in_array($targetstatus, $transitions[$from] ?? [], true)) {
                    throw new \moodle_exception('invalidtransition', 'local_testcase_exchange');
                }
            }

            $finalrating = ($rating >= 1 && $rating <= 5) ? $rating : ($row['rating'] !== null ? (int) $row['rating'] : null);
            $finalcomment = (trim($note) !== '') ? trim($note) : $row['review_comment'];

            $update = $this->connection->prepare(
                'UPDATE testcase_contributions SET status = ?, rating = ?, review_comment = ? WHERE id = ?'
            );
            $update->bind_param('sisi', $targetstatus, $finalrating, $finalcomment, $contributionid);
            $update->execute();
            $update->close();

            $this->insert_review($contributionid, $reviewerid, $from, $targetstatus, $note, $finalrating, $ratingreason);
            if ($targetstatus === 'approved' && $from !== 'approved') {
                $this->grant_reward_for_contribution($contributionid);
            }
            $this->connection->commit();
        } catch (\Throwable $e) {
            $this->connection->rollback();
            throw $e;
        }
    }

    /**
     * Add an explanation and resubmit a contribution.
     *
     * @param int $contributionid Contribution ID.
     * @param int $userid Owner user ID.
     * @param string $explanation Explanation text.
     */
    public function resubmit_explanation(int $contributionid, int $userid, string $explanation): void {
        if (trim($explanation) === '') {
            throw new \moodle_exception('explanationrequired', 'local_testcase_exchange');
        }
        $this->connection->begin_transaction();
        try {
            $stmt = $this->connection->prepare(
                "SELECT status FROM testcase_contributions
                  WHERE id = ? AND user_id = ? FOR UPDATE"
            );
            $stmt->bind_param('ii', $contributionid, $userid);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$row || $row['status'] !== 'needs_explanation') {
                throw new \moodle_exception('invalidtransition', 'local_testcase_exchange');
            }
            $status = 'submitted';
            $update = $this->connection->prepare(
                "UPDATE testcase_contributions
                    SET status = ?, purpose = CONCAT(COALESCE(purpose, ''), '\nExplanation: ', ?)
                  WHERE id = ?"
            );
            $update->bind_param('ssi', $status, $explanation, $contributionid);
            $update->execute();
            $update->close();
            $this->insert_review(
                $contributionid,
                $userid,
                'needs_explanation',
                'submitted',
                $explanation
            );
            $this->connection->commit();
        } catch (\Throwable $e) {
            $this->connection->rollback();
            throw $e;
        }
    }

    /**
     * Save Quiz-level policy settings.
     *
     * @param int $quizid Quiz ID.
     * @param int $userid Editor user ID.
     * @param array $values Submitted values.
     */
    public function save_quiz_settings(int $quizid, int $userid, array $values): void {
        $stmt = $this->connection->prepare(
            'INSERT INTO quiz_settings
            (quiz_id, is_enabled, enabled, review_mode, reward_policy, show_oracle_output,
             leaderboard_enabled, max_runs_per_minute, max_input_bytes, updated_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE is_enabled=VALUES(is_enabled), enabled=VALUES(enabled),
             review_mode=VALUES(review_mode), reward_policy=VALUES(reward_policy),
             show_oracle_output=VALUES(show_oracle_output), leaderboard_enabled=VALUES(leaderboard_enabled),
             max_runs_per_minute=VALUES(max_runs_per_minute), max_input_bytes=VALUES(max_input_bytes),
             updated_by=VALUES(updated_by)'
        );
        $enabled = !empty($values['enabled']) ? 1 : 0;
        $showoracle = !empty($values['show_oracle_output']) ? 1 : 0;
        $leaderboard = !empty($values['leaderboard_enabled']) ? 1 : 0;
        $reviewmode = in_array($values['review_mode'], ['auto', 'teacher'], true) ? $values['review_mode'] : 'teacher';
        $rewardpolicy = in_array($values['reward_policy'], ['disabled', 'one_for_one'], true) ?
            $values['reward_policy'] : 'one_for_one';
        $maxruns = max(1, min(120, (int) $values['max_runs_per_minute']));
        $maxbytes = max(64, min(1048576, (int) $values['max_input_bytes']));
        $stmt->bind_param(
            'iiissiiiii',
            $quizid,
            $enabled,
            $enabled,
            $reviewmode,
            $rewardpolicy,
            $showoracle,
            $leaderboard,
            $maxruns,
            $maxbytes,
            $userid
        );
        $stmt->execute();
        $stmt->close();
    }

    /**
     * Save question-level execution policy.
     *
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param int $userid Editor user ID.
     * @param array $values Submitted values.
     */
    public function save_question_policy(int $quizid, int $questionid, int $userid, array $values): void {
        // Fetch current policy to preserve fields that are not explicitly provided in $values
        $stmt_curr = $this->connection->prepare(
            'SELECT input_mode, testcode_template, normalization_mode, categories FROM question_policies WHERE question_id = ?'
        );
        $stmt_curr->bind_param('i', $questionid);
        $stmt_curr->execute();
        $curr = $stmt_curr->get_result()->fetch_assoc() ?: [];
        $stmt_curr->close();

        $mode_val = array_key_exists('input_mode', $values) ? $values['input_mode'] : ($curr['input_mode'] ?? 'testcode');
        $mode = in_array($mode_val, ['stdin', 'testcode', 'template'], true) ? $mode_val : 'testcode';

        $norm_val = array_key_exists('normalization_mode', $values) ? $values['normalization_mode'] : ($curr['normalization_mode'] ?? 'trim');
        $normalization = in_array($norm_val, ['raw', 'trim', 'json'], true) ? $norm_val : 'trim';

        $template = array_key_exists('testcode_template', $values) ? (string) $values['testcode_template'] : (string) ($curr['testcode_template'] ?? '');
        $categories = array_key_exists('categories', $values) ? (string) $values['categories'] : (string) ($curr['categories'] ?? '');

        $stmt = $this->connection->prepare(
            'INSERT INTO question_policies
            (question_id, quiz_id, input_mode, testcode_template, normalization_mode, categories, updated_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE quiz_id=VALUES(quiz_id), input_mode=VALUES(input_mode),
            testcode_template=VALUES(testcode_template), normalization_mode=VALUES(normalization_mode),
            categories=VALUES(categories), updated_by=VALUES(updated_by)'
        );
        $stmt->bind_param('iissssi', $questionid, $quizid, $mode, $template, $normalization, $categories, $userid);
        $stmt->execute();
        $stmt->close();
    }

    /**
     * Return private runs for a user, enriched with code revision step numbers.
     *
     * @param int $courseid Course ID.
     * @param int $userid User ID.
     * @return array Private runs.
     */
    public function runs_for_user(int $courseid, int $userid): array {
        $stmt = $this->connection->prepare(
            'SELECT r.*,
                    rev.step_number AS revision_step,
                    rev.created_at AS revision_created_at
               FROM testcase_runs r
          LEFT JOIN student_code_revisions rev ON rev.id = r.code_revision_id
              WHERE r.course_id = ? AND r.user_id = ?
           ORDER BY r.id DESC LIMIT 100'
        );
        $stmt->bind_param('ii', $courseid, $userid);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    /**
     * Record a new code revision if the submitted code differs from the immediately preceding revision.
     * If code is identical to the preceding revision, return existing revision info.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param int $userid User ID.
     * @param string $codecontent Code content.
     * @return array{id: ?int, step_number: int, is_new: bool}
     */
    public function record_or_get_code_revision(
        int $courseid,
        int $quizid,
        int $questionid,
        int $userid,
        string $codecontent
    ): array {
        $trimmed = trim(self::sanitize_multiline_text($codecontent));
        if ($trimmed === '') {
            return ['id' => null, 'step_number' => 0, 'is_new' => false];
        }

        $codehash = hash('sha256', $trimmed);

        // Find the immediately preceding revision for this user on this specific question
        $stmt = $this->connection->prepare(
            'SELECT id, code_hash, step_number FROM student_code_revisions
              WHERE course_id = ? AND quiz_id = ? AND question_id = ? AND user_id = ?
              ORDER BY id DESC LIMIT 1'
        );
        $stmt->bind_param('iiii', $courseid, $quizid, $questionid, $userid);
        $stmt->execute();
        $last = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // If the immediately preceding revision has the exact same hash, reuse it
        if ($last && (string) $last['code_hash'] === $codehash) {
            return [
                'id' => (int) $last['id'],
                'step_number' => (int) $last['step_number'],
                'is_new' => false,
            ];
        }

        // Code differs from the immediately preceding revision (or this is the very first revision)
        // Calculate the next step number (e.g. 1, 2, 3...)
        $newstep = $last ? ((int) $last['step_number'] + 1) : 1;
        $mode = 'playground';
        $ins = $this->connection->prepare(
            'INSERT INTO student_code_revisions
            (course_id, quiz_id, question_id, user_id, step_number, code_content, code_hash, execution_mode)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $ins->bind_param(
            'iiiiisss',
            $courseid,
            $quizid,
            $questionid,
            $userid,
            $newstep,
            $trimmed,
            $codehash,
            $mode
        );
        $ins->execute();
        $newid = (int) $ins->insert_id;
        $ins->close();

        return [
            'id' => $newid,
            'step_number' => $newstep,
            'is_new' => true,
        ];
    }

    /**
     * Get the latest run context (code, inputs) for prefilling the playground form.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param int $userid User ID.
     * @return array|null Latest run record or revision.
     */
    public function get_latest_student_run_context(int $courseid, int $quizid, int $questionid, int $userid): ?array {
        $stmt = $this->connection->prepare(
            'SELECT r.student_code_snapshot, r.input_raw, r.predicted_output, r.purpose, r.category,
                    rev.step_number AS revision_step, rev.code_content AS revision_code
               FROM testcase_runs r
          LEFT JOIN student_code_revisions rev ON rev.id = r.code_revision_id
              WHERE r.course_id = ? AND r.quiz_id = ? AND r.question_id = ? AND r.user_id = ?
              ORDER BY r.id DESC LIMIT 1'
        );
        $stmt->bind_param('iiii', $courseid, $quizid, $questionid, $userid);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            return $row;
        }

        // Fallback to latest revision if no runs yet
        $stmt2 = $this->connection->prepare(
            'SELECT code_content AS revision_code, step_number AS revision_step
               FROM student_code_revisions
              WHERE course_id = ? AND quiz_id = ? AND question_id = ? AND user_id = ?
              ORDER BY id DESC LIMIT 1'
        );
        $stmt2->bind_param('iiii', $courseid, $quizid, $questionid, $userid);
        $stmt2->execute();
        $row2 = $stmt2->get_result()->fetch_assoc();
        $stmt2->close();
        return $row2 ?: null;
    }

    /**
     * Get summary of code revisions and their associated testcases for a user and question.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param int $userid User ID.
     * @return array List of code revisions with linked testcases and timestamps.
     */
    public function code_revisions_summary(int $courseid, int $quizid, int $questionid, int $userid): array {
        $stmt = $this->connection->prepare(
            'SELECT id, step_number, code_content, code_hash, created_at
               FROM student_code_revisions
              WHERE course_id = ? AND quiz_id = ? AND question_id = ? AND user_id = ?
              ORDER BY step_number DESC'
        );
        $stmt->bind_param('iiii', $courseid, $quizid, $questionid, $userid);
        $stmt->execute();
        $revisions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        if (empty($revisions)) {
            return [];
        }

        $stmtruns = $this->connection->prepare(
            'SELECT id, code_revision_id, input_raw, student_run_output, oracle_outcome,
                    student_outcome, created_at
               FROM testcase_runs
              WHERE course_id = ? AND quiz_id = ? AND question_id = ? AND user_id = ?
              ORDER BY id ASC'
        );
        $stmtruns->bind_param('iiii', $courseid, $quizid, $questionid, $userid);
        $stmtruns->execute();
        $allruns = $stmtruns->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmtruns->close();

        $runsbyrevision = [];
        foreach ($allruns as $r) {
            $revid = (int) ($r['code_revision_id'] ?? 0);
            if ($revid > 0) {
                $runsbyrevision[$revid][] = $r;
            }
        }

        $result = [];
        foreach ($revisions as $idx => $rev) {
            $revid = (int) $rev['id'];
            $linkedruns = $runsbyrevision[$revid] ?? [];
            $runids = array_column($linkedruns, 'id');
            $testcaselabels = array_map(function($id) {
                return '#' . $id;
            }, $runids);

            $snippetlines = explode("\n", trim($rev['code_content']));
            $snippet = implode("\n", array_slice($snippetlines, 0, 3));
            if (count($snippetlines) > 3) {
                $snippet .= "\n...";
            }

            $result[] = [
                'id' => $revid,
                'step_number' => (int) $rev['step_number'],
                'created_at' => $rev['created_at'],
                'created_at_formatted' => date('H:i:s - d/m/Y', strtotime($rev['created_at'])),
                'code_content' => $rev['code_content'],
                'code_content_json' => json_encode($rev['code_content']),
                'code_snippet' => $snippet,
                'testcase_count' => count($linkedruns),
                'testcase_ids_string' => !empty($testcaselabels) ? implode(', ', $testcaselabels) : 'Chưa chạy testcase nào',
                'has_testcases' => !empty($linkedruns),
                'is_latest' => ($idx === 0),
            ];
        }

        return $result;
    }

    /**
     * Return contributions for a user.
     *
     * @param int $courseid Course ID.
     * @param int $userid User ID.
     * @return array Contributions.
     */
    public function contributions_for_user(int $courseid, int $userid): array {
        $stmt = $this->connection->prepare(
            'SELECT c.*,
                    (SELECT cr.review_note FROM contribution_reviews cr
                      WHERE cr.contribution_id = c.id AND cr.review_note IS NOT NULL AND cr.review_note <> \'\'
                      ORDER BY cr.id DESC LIMIT 1) AS latest_review_note,
                    (SELECT cr.rating FROM contribution_reviews cr
                      WHERE cr.contribution_id = c.id AND cr.rating IS NOT NULL AND cr.rating > 0
                      ORDER BY cr.id DESC LIMIT 1) AS latest_rating
               FROM testcase_contributions c
              WHERE c.course_id = ? AND c.user_id = ? ORDER BY c.id DESC LIMIT 100'
        );
        $stmt->bind_param('ii', $courseid, $userid);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }


    /**
     * Return contributions awaiting review.
     *
     * @param int $courseid Course ID.
     * @return array Pending contributions.
     */
    public function pending_contributions(int $courseid): array {
        return $this->course_contributions($courseid, 'pending');
    }

    /**
     * Return contributions for a course with optional status, quiz, and question filters.
     *
     * @param int $courseid Course ID.
     * @param string $status Filter status ('all', 'pending', 'submitted', 'approved', 'rejected', 'duplicate', 'needs_explanation').
     * @param int $quizid Optional Quiz ID filter.
     * @param int $questionid Optional Question ID filter.
     * @return array Contributions.
     */
    public function course_contributions(int $courseid, string $status = 'all', int $quizid = 0, int $questionid = 0): array {
        $conditions = ['c.course_id = ?'];
        $params = [$courseid];
        $types = 'i';

        if ($status === 'pending') {
            $conditions[] = "c.status IN ('submitted', 'needs_explanation')";
        } else if ($status !== 'all' && in_array($status, ['submitted', 'approved', 'rejected', 'duplicate', 'needs_explanation', 'archived'], true)) {
            $conditions[] = 'c.status = ?';
            $params[] = $status;
            $types .= 's';
        }

        if ($quizid > 0) {
            $conditions[] = 'c.quiz_id = ?';
            $params[] = $quizid;
            $types .= 'i';
        }

        if ($questionid > 0) {
            $conditions[] = 'c.question_id = ?';
            $params[] = $questionid;
            $types .= 'i';
        }

        $where = implode(' AND ', $conditions);
        $sql = "SELECT c.*,
                       (SELECT cr.review_note FROM contribution_reviews cr
                         WHERE cr.contribution_id = c.id AND cr.review_note IS NOT NULL AND cr.review_note <> ''
                         ORDER BY cr.id DESC LIMIT 1) AS latest_review_note,
                       (SELECT cr.rating FROM contribution_reviews cr
                         WHERE cr.contribution_id = c.id AND cr.rating IS NOT NULL AND cr.rating > 0
                         ORDER BY cr.id DESC LIMIT 1) AS latest_rating
                  FROM testcase_contributions c
                 WHERE {$where}
              ORDER BY c.id DESC LIMIT 500";

        $stmt = $this->connection->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    /**
     * Return contribution counts by status for a course with optional quiz/question filters.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Optional Quiz ID.
     * @param int $questionid Optional Question ID.
     * @return array<string, int>
     */
    public function contribution_counts(int $courseid, int $quizid = 0, int $questionid = 0): array {
        $conditions = ['course_id = ?'];
        $params = [$courseid];
        $types = 'i';

        if ($quizid > 0) {
            $conditions[] = 'quiz_id = ?';
            $params[] = $quizid;
            $types .= 'i';
        }

        if ($questionid > 0) {
            $conditions[] = 'question_id = ?';
            $params[] = $questionid;
            $types .= 'i';
        }

        $where = implode(' AND ', $conditions);
        $sql = "SELECT status, COUNT(*) AS cnt FROM testcase_contributions WHERE {$where} GROUP BY status";

        $stmt = $this->connection->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();

        $counts = [
            'all' => 0,
            'pending' => 0,
            'approved' => 0,
            'duplicate' => 0,
            'rejected' => 0,
            'needs_explanation' => 0,
            'submitted' => 0,
        ];

        while ($row = $result->fetch_assoc()) {
            $st = (string) $row['status'];
            $cnt = (int) $row['cnt'];
            $counts[$st] = $cnt;
            $counts['all'] += $cnt;
            if ($st === 'submitted' || $st === 'needs_explanation') {
                $counts['pending'] += $cnt;
            }
        }
        $stmt->close();
        return $counts;
    }

    /**
     * Load a private run owned by a user.
     *
     * @param int $runid Run ID.
     * @param int $userid Owner user ID.
     * @return array Owned run.
     */
    private function owned_run(int $runid, int $userid): array {
        $stmt = $this->connection->prepare('SELECT * FROM testcase_runs WHERE id = ? AND user_id = ?');
        $stmt->bind_param('ii', $runid, $userid);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) {
            throw new \moodle_exception('invalidrun', 'local_testcase_exchange');
        }
        return $row;
    }

    /**
     * Enforce the per-user Quiz run limit.
     *
     * @param int $userid User ID.
     * @param int $quizid Quiz ID.
     * @param int $limit Maximum runs per minute.
     */
    private function enforce_rate_limit(int $userid, int $quizid, int $limit): void {
        $stmt = $this->connection->prepare(
            'SELECT COUNT(*) AS total FROM testcase_runs
              WHERE user_id = ? AND quiz_id = ? AND created_at >= (NOW() - INTERVAL 1 MINUTE)'
        );
        $stmt->bind_param('ii', $userid, $quizid);
        $stmt->execute();
        $count = (int) $stmt->get_result()->fetch_assoc()['total'];
        $stmt->close();
        if ($count >= $limit) {
            throw new \moodle_exception('ratelimited', 'local_testcase_exchange');
        }
    }

    /**
     * Get existing canonical testcases and seeds for a course.
     *
     * @param int $courseid Course ID.
     * @return array<string, array{type: string, id: int}> Map of 'qid:fingerprint' => info.
     */
    public function existing_fingerprints_for_course(int $courseid): array {
        $map = [];
        $stmt = $this->connection->prepare(
            'SELECT question_id, input_fingerprint, canonical_contribution_id 
               FROM testcase_canonical_keys 
              WHERE course_id = ?'
        );
        $stmt->bind_param('i', $courseid);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $key = (int) $row['question_id'] . ':' . (string) $row['input_fingerprint'];
            $map[$key] = [
                'type' => 'contribution',
                'id' => (int) $row['canonical_contribution_id'],
            ];
        }
        $stmt->close();

        $stmt2 = $this->connection->prepare(
            'SELECT id, question_id, input_fingerprint 
               FROM question_seed_testcases 
              WHERE course_id = ? AND is_active = 1'
        );
        $stmt2->bind_param('i', $courseid);
        $stmt2->execute();
        $res2 = $stmt2->get_result();
        while ($row2 = $res2->fetch_assoc()) {
            $key = (int) $row2['question_id'] . ':' . (string) $row2['input_fingerprint'];
            if (!isset($map[$key])) {
                $map[$key] = [
                    'type' => 'seed',
                    'id' => (int) $row2['id'],
                ];
            }
        }
        $stmt2->close();

        return $map;
    }

    /**
     * Find the canonical contribution ID for a run.
     *
     * @param array $run Private run.
     * @return int Canonical contribution ID.
     */
    private function canonical_id(array $run): int {
        $stmt = $this->connection->prepare(
            'SELECT canonical_contribution_id FROM testcase_canonical_keys
              WHERE course_id = ? AND quiz_id = ? AND question_id = ? AND input_fingerprint = ?'
        );
        $courseid = (int) $run['course_id'];
        $quizid = (int) $run['quiz_id'];
        $questionid = (int) $run['question_id'];
        $fingerprint = (string) $run['input_fingerprint'];
        $stmt->bind_param('iiis', $courseid, $quizid, $questionid, $fingerprint);
        $stmt->execute();
        $id = (int) $stmt->get_result()->fetch_assoc()['canonical_contribution_id'];
        $stmt->close();
        return $id;
    }

    /**
     * Ensure a solution version snapshot exists in question_solution_versions.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param string $solutioncode Teacher answer code.
     * @param string $templatecode Question template code.
     * @param int $questionversion Version number.
     * @param int $authorid Teacher user ID.
     * @return array{id:int, solution_hash:string}
     */
    public function ensure_solution_version(
        int $courseid,
        int $quizid,
        int $questionid,
        string $solutioncode,
        string $templatecode = '',
        int $questionversion = 1,
        int $authorid = 0
    ): array {
        $hash = hash('sha256', trim($solutioncode));
        $stmt = $this->connection->prepare(
            'SELECT id, solution_hash FROM question_solution_versions
              WHERE course_id = ? AND quiz_id = ? AND question_id = ? AND solution_hash = ?'
        );
        $stmt->bind_param('iiis', $courseid, $quizid, $questionid, $hash);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            return ['id' => (int) $row['id'], 'solution_hash' => (string) $row['solution_hash']];
        }

        $ins = $this->connection->prepare(
            'INSERT IGNORE INTO question_solution_versions
            (course_id, quiz_id, question_id, question_version, solution_code, solution_hash, template_code, author_user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $ins->bind_param(
            'iiiisssi',
            $courseid,
            $quizid,
            $questionid,
            $questionversion,
            $solutioncode,
            $hash,
            $templatecode,
            $authorid
        );
        $ins->execute();
        $id = $ins->insert_id ?: 0;
        $ins->close();

        return ['id' => (int) $id, 'solution_hash' => $hash];
    }

    /**
     * Synchronize Suite 2 (Reward Bank / Seeds) from Moodle Question Bank for a specific question.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @return int Number of seed testcases synchronized.
     */
    public function sync_question_testsuites(int $courseid, int $quizid, int $questionid): int {
        global $DB;

        $tests = $DB->get_records('question_coderunner_tests', ['questionid' => $questionid]);
        if (!$tests) {
            return 0;
        }

        $synced = 0;
        foreach ($tests as $t) {
            $extra = strtolower(trim((string) ($t->extra ?? '')));
            // Accept 's', 'seed', 'reward_bank', 'suite2' or extra containing 'reward'.
            $is_reward_seed = in_array($extra, ['s', 'seed', 'reward_bank', 'suite2'], true) ||
                              (strpos($extra, 'reward') !== false && (int) $t->useasexample === 0);

            if (!$is_reward_seed) {
                continue;
            }

            $rawinput = trim((string) ($t->stdin ?? ''));
            if ($rawinput === '') {
                $rawinput = trim((string) ($t->testcode ?? ''));
            }
            if ($rawinput === '') {
                continue;
            }

            $normalized = normalizer::normalize($rawinput, 'trim');
            $fingerprint = normalizer::fingerprint($normalized);
            $testcode = (string) ($t->testcode ?? '');
            $stdin = (string) ($t->stdin ?? '');
            $expected = (string) ($t->expected ?? '');

            $stmt = $this->connection->prepare(
                'INSERT INTO question_seed_testcases
                (course_id, quiz_id, question_id, moodle_test_id, testcode, stdin, input_raw, input_normalized, input_fingerprint, expected_output, category, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "seed", 1)
                ON DUPLICATE KEY UPDATE
                    testcode = VALUES(testcode),
                    stdin = VALUES(stdin),
                    input_raw = VALUES(input_raw),
                    input_normalized = VALUES(input_normalized),
                    expected_output = VALUES(expected_output),
                    is_active = 1'
            );
            $mid = (int) $t->id;
            $stmt->bind_param(
                'iiiissssss',
                $courseid,
                $quizid,
                $questionid,
                $mid,
                $testcode,
                $stdin,
                $rawinput,
                $normalized,
                $fingerprint,
                $expected
            );
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $synced++;
            }
            $stmt->close();
        }

        return $synced;
    }

    /**
     * Return rewards for a user (unclaimed and claimed).
     *
     * @param int $courseid Course ID.
     * @param int $userid User ID.
     * @return array Rewards with masked input/output if unclaimed.
     */
    public function rewards_for_user(int $courseid, int $userid): array {
        $stmt = $this->connection->prepare(
            'SELECT r.id, r.course_id, r.quiz_id, r.question_id, r.receiver_user_id, r.contribution_id,
                    r.reward_source, r.seed_id, r.is_claimed, r.claimed_at, r.created_at,
                    COALESCE(c.input_normalized, s.input_normalized, "") AS input_normalized,
                    COALESCE(c.oracle_output, s.expected_output, "") AS oracle_output,
                    COALESCE(c.category, s.category, "seed") AS category
               FROM testcase_rewards r
          LEFT JOIN testcase_contributions c ON (r.reward_source = "contribution" AND c.id = r.contribution_id)
          LEFT JOIN question_seed_testcases s ON (r.reward_source = "seed" AND s.id = r.seed_id)
              WHERE r.course_id = ? AND r.receiver_user_id = ?
           ORDER BY r.id DESC LIMIT 100'
        );
        $stmt->bind_param('ii', $courseid, $userid);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // Process claim state for display
        foreach ($rows as &$row) {
            $row['is_claimed_bool'] = ((int) $row['is_claimed'] === 1);
            if (!$row['is_claimed_bool']) {
                $row['display_input'] = '🔒 [Nhấn "Nhận thưởng" để xem nội dung kiểm thử]';
                $row['display_oracle'] = '🔒 [Ẩn cho đến khi bạn bấm nhận]';
            } else {
                $row['display_input'] = $row['input_normalized'];
                $row['display_oracle'] = $row['oracle_output'];
            }
        }
        unset($row);

        return $rows;
    }

    /**
     * Claim a pending reward to reveal its testcase and record precise viewed_at timestamp.
     *
     * @param int $rewardid Reward ID.
     * @param int $userid User ID.
     * @param int $courseid Course ID.
     * @return bool True if claimed, false if invalid.
     */
    public function claim_reward(int $rewardid, int $userid, int $courseid): bool {
        $stmt = $this->connection->prepare(
            'SELECT * FROM testcase_rewards WHERE id = ? AND receiver_user_id = ? AND course_id = ?'
        );
        $stmt->bind_param('iii', $rewardid, $userid, $courseid);
        $stmt->execute();
        $reward = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$reward) {
            return false;
        }

        if ((int) $reward['is_claimed'] === 1) {
            return true;
        }

        $now = date('Y-m-d H:i:s');
        $upd = $this->connection->prepare(
            'UPDATE testcase_rewards SET is_claimed = 1, claimed_at = ? WHERE id = ?'
        );
        $upd->bind_param('si', $now, $rewardid);
        $upd->execute();
        $upd->close();

        // Log view event
        $log = $this->connection->prepare(
            'INSERT INTO testcase_view_logs
            (course_id, quiz_id, question_id, user_id, reward_id, contribution_id, action, created_at)
            VALUES (?, ?, ?, ?, ?, ?, "claim_reward", ?)'
        );
        $cid = (int) $reward['course_id'];
        $qid = (int) $reward['quiz_id'];
        $quid = (int) $reward['question_id'];
        $contribid = (int) ($reward['contribution_id'] ?? 0);
        $log->bind_param('iiiiiss', $cid, $qid, $quid, $userid, $rewardid, $contribid, $now);
        $log->execute();
        $log->close();

        return true;
    }

    /**
     * Return course leaderboard sorted by: total_stars DESC, approved_count DESC, earliest_submitted_at ASC.
     *
     * @param int $courseid Course ID.
     * @param int $currentuserid Current user ID.
     * @return array{leaderboard:array, my_rank:int, my_stars:int, my_count:int, top_user_name:string, top_stars:int, top_count:int}
     */
    public function course_leaderboard(int $courseid, int $currentuserid): array {
        global $DB;

        $sql = "
            SELECT user_id,
                   COALESCE(SUM(COALESCE(rating, 0)), 0) AS total_stars,
                   COUNT(id) AS approved_count,
                   MIN(submitted_at) AS first_submitted_at
              FROM testcase_contributions
             WHERE course_id = ? AND status = 'approved'
             GROUP BY user_id
             ORDER BY total_stars DESC, approved_count DESC, first_submitted_at ASC, user_id ASC
        ";
        $stmt = $this->connection->prepare($sql);
        $stmt->bind_param('i', $courseid);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        $leaderboard = [];
        $rank = 1;
        $myrank = 0;
        $mystars = 0;
        $mycount = 0;

        foreach ($res as $row) {
            $uid = (int) $row['user_id'];
            $stars = (int) $row['total_stars'];
            $count = (int) $row['approved_count'];

            $userobj = $DB->get_record('user', ['id' => $uid], 'id, firstname, lastname, username');
            $fullname = $userobj ? fullname($userobj) : ('Sinh viên #' . $uid);

            $iscurrent = ($uid === $currentuserid);
            if ($iscurrent) {
                $myrank = $rank;
                $mystars = $stars;
                $mycount = $count;
            }

            $starsdisplay = $stars . ' ⭐';

            $leaderboard[] = [
                'rank' => $rank,
                'user_id' => $uid,
                'fullname' => $fullname,
                'username' => $userobj ? $userobj->username : '',
                'total_stars' => $stars,
                'stars_display' => $starsdisplay,
                'approved_count' => $count,
                'first_submitted_at' => $row['first_submitted_at'],
                'is_current_user' => $iscurrent,
                'badge_class' => ($rank === 1 ? 'badge-warning text-dark font-weight-bold' :
                                 ($rank === 2 ? 'badge-secondary' :
                                 ($rank === 3 ? 'badge-info' : 'badge-light text-muted'))),
                'medal' => ($rank === 1 ? '🥇' : ($rank === 2 ? '🥈' : ($rank === 3 ? '🥉' : ('#' . $rank)))),
            ];
            $rank++;
        }

        $top = $leaderboard[0] ?? null;

        return [
            'leaderboard' => $leaderboard,
            'my_rank' => $myrank,
            'my_stars' => $mystars,
            'my_count' => $mycount,
            'top_user_name' => $top ? $top['fullname'] : '',
            'top_stars' => $top ? $top['total_stars'] : 0,
            'top_count' => $top ? $top['approved_count'] : 0,
            'has_leaderboard' => !empty($leaderboard),
        ];
    }

    /**
     * Grant an idempotent reward after approval, avoiding duplicates across contributions and seeds.
     *
     * @param int $contributionid Approved contribution ID.
     */
    private function grant_reward_for_contribution(int $contributionid): void {
        $contribution = $this->connection->query(
            'SELECT * FROM testcase_contributions WHERE id = ' . (int) $contributionid
        )->fetch_assoc();
        if (!$contribution) {
            return;
        }
        $settings = $this->quiz_settings((int) $contribution['quiz_id']);
        if ($settings['reward_policy'] !== 'one_for_one') {
            return;
        }
        $courseid = (int) $contribution['course_id'];
        $quizid = (int) $contribution['quiz_id'];
        $questionid = (int) $contribution['question_id'];
        $ownerid = (int) $contribution['user_id'];

        // Lấy danh sách fingerprint của testcase mẫu công khai (public sample testcases) từ câu hỏi
        $policy = $this->question_policy($quizid, $questionid);
        $samplefingerprints = [];
        try {
            $execcontext = execution_service::resolve_context($questionid, $policy);
            $samplefingerprints = $execcontext['sample_fingerprints'] ?? [];
        } catch (\Throwable $e) {
            $samplefingerprints = [];
        }
        $samplecond = '';
        if (!empty($samplefingerprints)) {
            $escaped = array_map(function($f) {
                return "'" . $this->connection->real_escape_string($f) . "'";
            }, $samplefingerprints);
            $samplecond = ' AND input_fingerprint NOT IN (' . implode(',', $escaped) . ')';
        }

        // 1. Tìm ứng viên từ kho đóng góp của bạn học (Peer Pool)
        // Điều kiện: approved, khác user, chưa nhận thưởng, không phải bài mình, CHƯA TỪNG CHẠY trên Playground, KHÔNG PHẢI testcase mẫu công khai
        // Sắp xếp: ORDER BY RAND() để phân phối ngẫu nhiên đồng đều (Pure Random)
        $peerpeerquery = "SELECT c.id, c.input_fingerprint, 'contribution' AS source
               FROM testcase_contributions c
              WHERE c.course_id = ? AND c.quiz_id = ? AND c.question_id = ?
                AND c.status = 'approved' AND c.user_id <> ?
                AND NOT EXISTS (
                    SELECT 1 FROM testcase_rewards r
                     WHERE r.receiver_user_id = ? AND r.course_id = ? AND r.question_id = ?
                       AND r.contribution_id = c.id
                )
                AND NOT EXISTS (
                    SELECT 1 FROM testcase_contributions own
                     WHERE own.user_id = ? AND own.course_id = ? AND own.question_id = ?
                       AND own.input_fingerprint = c.input_fingerprint
                )
                AND NOT EXISTS (
                    SELECT 1 FROM testcase_runs tr
                     WHERE tr.user_id = ? AND tr.question_id = ?
                       AND tr.input_fingerprint = c.input_fingerprint
                )" . str_replace('input_fingerprint', 'c.input_fingerprint', $samplecond) . "
              ORDER BY RAND() LIMIT 1";

        $stmt = $this->connection->prepare($peerpeerquery);
        $stmt->bind_param(
            'iiiiiiiiiiii',
            $courseid, $quizid, $questionid, $ownerid,
            $ownerid, $courseid, $questionid,
            $ownerid, $courseid, $questionid,
            $ownerid, $questionid
        );
        $stmt->execute();
        $candidate = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // 2. Nếu kho peer không có ứng viên hợp lệ, fallback sang Kho hạt giống (Seed Bank)
        // Điều kiện: is_active, chưa nhận thưởng, không trùng bài mình, CHƯA TỪNG CHẠY trên Playground, KHÔNG PHẢI mẫu công khai
        if (!$candidate) {
            $seedquery = "SELECT s.id, s.input_fingerprint, 'seed' AS source
                   FROM question_seed_testcases s
                  WHERE s.course_id = ? AND s.quiz_id = ? AND s.question_id = ? AND s.is_active = 1
                    AND NOT EXISTS (
                        SELECT 1 FROM testcase_rewards r
                         WHERE r.receiver_user_id = ? AND r.course_id = ? AND r.question_id = ?
                           AND r.reward_source = 'seed' AND r.seed_id = s.id
                    )
                    AND NOT EXISTS (
                        SELECT 1 FROM testcase_contributions own
                         WHERE own.user_id = ? AND own.course_id = ? AND own.question_id = ?
                           AND own.input_fingerprint = s.input_fingerprint
                    )
                    AND NOT EXISTS (
                        SELECT 1 FROM testcase_runs tr
                         WHERE tr.user_id = ? AND tr.question_id = ?
                           AND tr.input_fingerprint = s.input_fingerprint
                    )" . str_replace('input_fingerprint', 's.input_fingerprint', $samplecond) . "
                  ORDER BY RAND() LIMIT 1";

            $stmt = $this->connection->prepare($seedquery);
            $stmt->bind_param(
                'iiiiiiiiiii',
                $courseid, $quizid, $questionid,
                $ownerid, $courseid, $questionid,
                $ownerid, $courseid, $questionid,
                $ownerid, $questionid
            );
            $stmt->execute();
            $candidate = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        }

        if (!$candidate) {
            return;
        }

        $source = (string) $candidate['source'];
        $targetid = (int) $candidate['id'];
        $contribid = ($source === 'contribution') ? $targetid : null;
        $seedid = ($source === 'seed') ? $targetid : null;

        $insert = $this->connection->prepare(
            'INSERT IGNORE INTO testcase_rewards
            (course_id, quiz_id, question_id, receiver_user_id, contribution_id, reward_source, seed_id, is_claimed, claimed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, NULL)'
        );
        $insert->bind_param(
            'iiiiisi',
            $courseid,
            $quizid,
            $questionid,
            $ownerid,
            $contribid,
            $source,
            $seedid
        );
        $insert->execute();
        $insert->close();
    }

    /**
     * Insert an immutable review audit row.
     *
     * @param int $contributionid Contribution ID.
     * @param int $reviewerid Reviewer user ID.
     * @param string $from Previous status.
     * @param string $to New status.
     * @param string $note Review note.
     * @param ?int $rating Rating 1-5.
     * @param string $ratingreason Rating reason.
     */
    private function insert_review(
        int $contributionid,
        int $reviewerid,
        string $from,
        string $to,
        string $note,
        ?int $rating = null,
        string $ratingreason = ''
    ): void {
        $audit = $this->connection->prepare(
            'INSERT INTO contribution_reviews
            (contribution_id, reviewer_user_id, from_status, to_status, review_note, rating, rating_reason)
            VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $audit->bind_param('iisssis', $contributionid, $reviewerid, $from, $to, $note, $rating, $ratingreason);
        $audit->execute();
        $audit->close();
    }

    /**
     * Return summary statistics for all courses in testcase_contributions.
     *
     * @return array<int, array{course_id:int, total_count:int, pending_count:int, approved_count:int, rejected_count:int, duplicate_count:int, student_count:int}>
     */
    public function courses_summary(): array {
        $result = $this->connection->query(
            "SELECT course_id,
                    COUNT(*) AS total_count,
                    SUM(CASE WHEN status IN ('submitted', 'needs_explanation') THEN 1 ELSE 0 END) AS pending_count,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_count,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_count,
                    SUM(CASE WHEN status = 'duplicate' THEN 1 ELSE 0 END) AS duplicate_count,
                    COUNT(DISTINCT user_id) AS student_count
               FROM testcase_contributions
              GROUP BY course_id"
        );
        if (!$result) {
            return [];
        }
        $summary = [];
        while ($row = $result->fetch_assoc()) {
            $summary[(int) $row['course_id']] = [
                'course_id' => (int) $row['course_id'],
                'total_count' => (int) $row['total_count'],
                'pending_count' => (int) $row['pending_count'],
                'approved_count' => (int) $row['approved_count'],
                'rejected_count' => (int) $row['rejected_count'],
                'duplicate_count' => (int) $row['duplicate_count'],
                'student_count' => (int) $row['student_count'],
            ];
        }
        return $summary;
    }

    /**
     * List all seed testcases for a specific question.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @return array List of active seed testcases.
     */
    public function list_seed_testcases(int $courseid, int $quizid, int $questionid): array {
        $stmt = $this->connection->prepare(
            'SELECT id, testcode, stdin, expected_output, purpose, source_type, created_at
               FROM question_seed_testcases
              WHERE course_id = ? AND quiz_id = ? AND question_id = ? AND is_active = 1
              ORDER BY id ASC'
        );
        $stmt->bind_param('iii', $courseid, $quizid, $questionid);
        $stmt->execute();
        $res = $stmt->get_result();
        $seeds = [];
        while ($row = $res->fetch_assoc()) {
            $seeds[] = $row;
        }
        $stmt->close();
        return $seeds;
    }

    /**
     * Add a manual seed testcase for a question.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param string $testcode Test code (e.g., print(tinh_tong(10))).
     * @param string $stdin Standard input.
     * @param string $expected Expected output.
     * @param string $purpose Purpose or pedagogical note.
     * @param string $sourcetype 'manual' or 'xml_import'.
     * @return array Added seed record details.
     */
    public function add_manual_seed(
        int $courseid,
        int $quizid,
        int $questionid,
        string $testcode,
        string $stdin,
        string $expected,
        string $purpose = '',
        string $sourcetype = 'manual'
    ): array {
        $rawinput = trim($stdin);
        if ($rawinput === '') {
            $rawinput = trim($testcode);
        }
        $normalized = normalizer::normalize($rawinput, 'trim');
        $fingerprint = normalizer::fingerprint($normalized);

        $stmt = $this->connection->prepare(
            'INSERT INTO question_seed_testcases
            (course_id, quiz_id, question_id, testcode, stdin, input_raw, input_normalized, input_fingerprint, expected_output, category, is_active, source_type, purpose)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "seed", 1, ?, ?)
            ON DUPLICATE KEY UPDATE
                testcode = VALUES(testcode),
                stdin = VALUES(stdin),
                input_raw = VALUES(input_raw),
                input_normalized = VALUES(input_normalized),
                expected_output = VALUES(expected_output),
                purpose = VALUES(purpose),
                source_type = VALUES(source_type),
                is_active = 1'
        );
        $stmt->bind_param(
            'iiissssssss',
            $courseid,
            $quizid,
            $questionid,
            $testcode,
            $stdin,
            $rawinput,
            $normalized,
            $fingerprint,
            $expected,
            $sourcetype,
            $purpose
        );
        $stmt->execute();
        $insertid = (int) $this->connection->insert_id;
        $stmt->close();

        return [
            'id' => $insertid,
            'testcode' => $testcode,
            'expected_output' => $expected,
            'fingerprint' => $fingerprint,
        ];
    }

    /**
     * Delete (deactivate) a seed testcase.
     *
     * @param int $seedid Seed ID.
     * @param int $courseid Course ID for authorization check.
     * @return bool
     */
    public function delete_seed_testcase(int $seedid, int $courseid): bool {
        $stmt = $this->connection->prepare(
            'DELETE FROM question_seed_testcases WHERE id = ? AND course_id = ?'
        );
        $stmt->bind_param('ii', $seedid, $courseid);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    /**
     * Import seed testcases from uploaded Moodle XML file content.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param string $xmlcontent XML file content.
     * @return int Number of imported seed testcases.
     */
    public function import_seeds_from_xml_content(
        int $courseid,
        int $quizid,
        int $questionid,
        string $xmlcontent
    ): int {
        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($xmlcontent);
        if (!$xml) {
            libxml_clear_errors();
            throw new \moodle_exception('invalidxml', 'local_testcase_exchange', '', 'Invalid Moodle XML format');
        }

        $imported = 0;
        $testcase_elements = $xml->xpath('//testcase');
        if (empty($testcase_elements)) {
            $testcase_elements = $xml->xpath('//testcases/testcase');
        }

        foreach ($testcase_elements as $tc) {
            $testcode = '';
            if (isset($tc->testcode->text)) {
                $testcode = (string) $tc->testcode->text;
            } else if (isset($tc->testcode)) {
                $testcode = (string) $tc->testcode;
            }

            $stdin = '';
            if (isset($tc->stdin->text)) {
                $stdin = (string) $tc->stdin->text;
            } else if (isset($tc->stdin)) {
                $stdin = (string) $tc->stdin;
            }

            $expected = '';
            if (isset($tc->expected->text)) {
                $expected = (string) $tc->expected->text;
            } else if (isset($tc->expected)) {
                $expected = (string) $tc->expected;
            }

            $purpose = 'Imported from Moodle XML';
            if (isset($tc->extra->text) && trim((string) $tc->extra->text) !== '') {
                $purpose .= ' (' . trim((string) $tc->extra->text) . ')';
            }

            if (trim($testcode) === '' && trim($stdin) === '') {
                continue;
            }

            $this->add_manual_seed(
                $courseid,
                $quizid,
                $questionid,
                trim($testcode),
                trim($stdin),
                trim($expected),
                $purpose,
                'xml_import'
            );
            $imported++;
        }

        return $imported;
    }

    /**
     * Get total runs count for course, optional quiz and question, isolated to enrolled students.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param array $studentuserids Optional array of student user IDs to isolate from teacher runs.
     * @return int Total run count.
     */
    public function total_runs_count(int $courseid, int $quizid = 0, int $questionid = 0, ?array $studentuserids = null): int {
        // Empty student list must strictly return 0, never fall back to "everyone"
        if ($studentuserids !== null && empty($studentuserids)) {
            return 0;
        }
        $conditions = ['course_id = ?'];
        $params = [$courseid];
        $types = 'i';
        if ($quizid > 0) {
            $conditions[] = 'quiz_id = ?';
            $params[] = $quizid;
            $types .= 'i';
        }
        if ($questionid > 0) {
            $conditions[] = 'question_id = ?';
            $params[] = $questionid;
            $types .= 'i';
        }
        if ($studentuserids !== null && !empty($studentuserids)) {
            $safeids = array_map('intval', $studentuserids);
            $conditions[] = 'user_id IN (' . implode(',', $safeids) . ')';
        }
        $where = implode(' AND ', $conditions);
        $stmt = $this->connection->prepare("SELECT COUNT(*) FROM testcase_runs WHERE {$where}");
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res->fetch_row();
        $stmt->close();
        return (int) ($row[0] ?? 0);
    }

    /**
     * Get rewards statistics for course, optional quiz and question.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param array|null $studentuserids Optional array of student user IDs.
     * @return array Total, claimed and unclaimed counts.
     */
    public function total_rewards_count(int $courseid, int $quizid = 0, int $questionid = 0, ?array $studentuserids = null): array {
        // Empty student list must strictly return 0, never fall back to "everyone"
        if ($studentuserids !== null && empty($studentuserids)) {
            return [
                'total' => 0,
                'claimed' => 0,
                'unclaimed' => 0,
            ];
        }
        $conditions = ['course_id = ?'];
        $params = [$courseid];
        $types = 'i';
        if ($quizid > 0) {
            $conditions[] = 'quiz_id = ?';
            $params[] = $quizid;
            $types .= 'i';
        }
        if ($questionid > 0) {
            $conditions[] = 'question_id = ?';
            $params[] = $questionid;
            $types .= 'i';
        }
        if ($studentuserids !== null && !empty($studentuserids)) {
            $safeids = array_map('intval', $studentuserids);
            $conditions[] = 'receiver_user_id IN (' . implode(',', $safeids) . ')';
        }
        $where = implode(' AND ', $conditions);
        $stmt = $this->connection->prepare(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN is_claimed = 1 THEN 1 ELSE 0 END) AS claimed FROM testcase_rewards WHERE {$where}"
        );
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res->fetch_assoc();
        $stmt->close();
        $total = (int) ($row['total'] ?? 0);
        $claimed = (int) ($row['claimed'] ?? 0);
        return [
            'total' => $total,
            'claimed' => $claimed,
            'unclaimed' => max(0, $total - $claimed),
        ];
    }

    /**
     * Aggregated student activity for a course, quiz and question, isolated to enrolled students.
     *
     * @param int $courseid Course ID.
     * @param int $quizid Quiz ID.
     * @param int $questionid Question ID.
     * @param array|null $studentuserids Optional array of student user IDs to exclude teacher preview runs.
     * @return array List of student records with runs, contributions and rewards counts.
     */
    public function student_activity_summary(int $courseid, int $quizid = 0, int $questionid = 0, ?array $studentuserids = null): array {
        // Empty student list must strictly return empty array, never fall back to "everyone"
        if ($studentuserids !== null && empty($studentuserids)) {
            return [];
        }
        $studentfilterclause = '';
        $safeids = [];
        if ($studentuserids !== null && !empty($studentuserids)) {
            $safeids = array_map('intval', $studentuserids);
            $studentfilterclause = ' AND user_id IN (' . implode(',', $safeids) . ')';
        }

        // 1. Runs per user
        $runconds = ['course_id = ?'];
        $runparams = [$courseid];
        $runtypes = 'i';
        if ($quizid > 0) {
            $runconds[] = 'quiz_id = ?';
            $runparams[] = $quizid;
            $runtypes .= 'i';
        }
        if ($questionid > 0) {
            $runconds[] = 'question_id = ?';
            $runparams[] = $questionid;
            $runtypes .= 'i';
        }
        $runwhere = implode(' AND ', $runconds) . $studentfilterclause;
        $runsql = "SELECT user_id, COUNT(*) AS total_runs, MAX(created_at) AS last_run_at FROM testcase_runs WHERE {$runwhere} GROUP BY user_id";
        $stmt = $this->connection->prepare($runsql);
        $stmt->bind_param($runtypes, ...$runparams);
        $stmt->execute();
        $res = $stmt->get_result();
        $users = [];
        while ($row = $res->fetch_assoc()) {
            $uid = (int) $row['user_id'];
            $users[$uid] = [
                'user_id' => $uid,
                'total_runs' => (int) $row['total_runs'],
                'last_run_at' => $row['last_run_at'],
                'total_contributions' => 0,
                'approved_contributions' => 0,
                'pending_contributions' => 0,
                'total_stars' => 0,
                'claimed_rewards' => 0,
                'total_rewards' => 0,
            ];
        }
        $stmt->close();

        // 2. Contributions per user
        $cconds = ['course_id = ?'];
        $cparams = [$courseid];
        $ctypes = 'i';
        if ($quizid > 0) {
            $cconds[] = 'quiz_id = ?';
            $cparams[] = $quizid;
            $ctypes .= 'i';
        }
        if ($questionid > 0) {
            $cconds[] = 'question_id = ?';
            $cparams[] = $questionid;
            $ctypes .= 'i';
        }
        $cwhere = implode(' AND ', $cconds) . $studentfilterclause;
        $csql = "SELECT user_id,
                        COUNT(*) AS total_c,
                        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_c,
                        SUM(CASE WHEN status IN ('submitted', 'needs_explanation') THEN 1 ELSE 0 END) AS pending_c,
                        SUM(CASE WHEN status = 'approved' THEN COALESCE(rating, 0) ELSE 0 END) AS total_s
                   FROM testcase_contributions
                  WHERE {$cwhere}
                  GROUP BY user_id";
        $stmt = $this->connection->prepare($csql);
        $stmt->bind_param($ctypes, ...$cparams);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $uid = (int) $row['user_id'];
            if (!isset($users[$uid])) {
                $users[$uid] = [
                    'user_id' => $uid,
                    'total_runs' => 0,
                    'last_run_at' => null,
                    'total_contributions' => 0,
                    'approved_contributions' => 0,
                    'pending_contributions' => 0,
                    'total_stars' => 0,
                    'claimed_rewards' => 0,
                    'total_rewards' => 0,
                ];
            }
            $users[$uid]['total_contributions'] = (int) $row['total_c'];
            $users[$uid]['approved_contributions'] = (int) $row['approved_c'];
            $users[$uid]['pending_contributions'] = (int) $row['pending_c'];
            $users[$uid]['total_stars'] = (int) $row['total_s'];
        }
        $stmt->close();

        // 3. Rewards per user
        $rconds = ['course_id = ?'];
        $rparams = [$courseid];
        $rtypes = 'i';
        if ($quizid > 0) {
            $rconds[] = 'quiz_id = ?';
            $rparams[] = $quizid;
            $rtypes .= 'i';
        }
        if ($questionid > 0) {
            $rconds[] = 'question_id = ?';
            $rparams[] = $questionid;
            $rtypes .= 'i';
        }
        $rstudentfilterclause = '';
        if (!empty($studentuserids)) {
            $safeids = array_map('intval', $studentuserids);
            $rstudentfilterclause = ' AND receiver_user_id IN (' . implode(',', $safeids) . ')';
        }
        $rwhere = implode(' AND ', $rconds) . $rstudentfilterclause;
        $rsql = "SELECT receiver_user_id AS user_id,
                        COUNT(*) AS total_r,
                        SUM(CASE WHEN is_claimed = 1 THEN 1 ELSE 0 END) AS claimed_r
                   FROM testcase_rewards
                  WHERE {$rwhere}
                  GROUP BY receiver_user_id";
        $stmt = $this->connection->prepare($rsql);
        $stmt->bind_param($rtypes, ...$rparams);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $uid = (int) $row['user_id'];
            if (!isset($users[$uid])) {
                $users[$uid] = [
                    'user_id' => $uid,
                    'total_runs' => 0,
                    'last_run_at' => null,
                    'total_contributions' => 0,
                    'approved_contributions' => 0,
                    'pending_contributions' => 0,
                    'total_stars' => 0,
                    'claimed_rewards' => 0,
                    'total_rewards' => 0,
                ];
            }
            $users[$uid]['total_rewards'] = (int) $row['total_r'];
            $users[$uid]['claimed_rewards'] = (int) $row['claimed_r'];
        }
        $stmt->close();

        // If studentuserids was passed, ensure no non-students leak in
        if (!empty($studentuserids)) {
            $safeidlookup = array_flip($safeids);
            $users = array_filter($users, function($u) use ($safeidlookup) {
                return isset($safeidlookup[$u['user_id']]);
            });
        }

        // Sort by total_contributions DESC, total_runs DESC
        usort($users, function($a, $b) {
            if ($b['total_contributions'] !== $a['total_contributions']) {
                return $b['total_contributions'] - $a['total_contributions'];
            }
            return $b['total_runs'] - $a['total_runs'];
        });

        return array_values($users);
    }
}

