<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'XH2k5EfYuZtvRNEE3Ok2R35QISkSo6OIlocalhost';
$CFG->bootstraphash = '5d246358791a4e200eaedb6dc008a359';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
