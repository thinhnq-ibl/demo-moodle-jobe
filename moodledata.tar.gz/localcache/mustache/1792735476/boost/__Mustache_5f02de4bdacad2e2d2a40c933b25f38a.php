<?php

class __Mustache_5f02de4bdacad2e2d2a40c933b25f38a extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        $value = $context->find('show_course_switcher');
        $buffer .= $this->section19dc20d609c61af79a73fbd8c5838131($context, $indent, $value);
        $buffer .= $indent . '
';
        $value = $context->find('has_return_url');
        $buffer .= $this->section87c59f451c3c43d874f31d52370163a7($context, $indent, $value);
        $buffer .= $indent . '
';
        $value = $context->find('can_manage_or_review');
        $buffer .= $this->sectionBfaacc9ad82beeea4d52803ed75a03c2($context, $indent, $value);
        $value = $context->find('can_run');
        $buffer .= $this->sectionD22236edc8a4f5906cafdcb73fa758d1($context, $indent, $value);
        $buffer .= $indent . '<div class="card bg-light border-primary mb-4 shadow-sm">
';
        $buffer .= $indent . '    <div class="card-body py-3">
';
        $buffer .= $indent . '        <div class="d-flex flex-wrap justify-content-between align-items-center">
';
        $buffer .= $indent . '            <div class="d-flex align-items-center mb-2 mb-md-0">
';
        $buffer .= $indent . '                <span class="display-4 mr-3" style="font-size: 2.2rem;">🏆</span>
';
        $buffer .= $indent . '                <div>
';
        $buffer .= $indent . '                    <h5 class="mb-1 text-primary font-weight-bold">';
        $value = $context->find('str');
        $buffer .= $this->sectionEf0dbbbbed9dd328063b6447460a6930($context, $indent, $value);
        $buffer .= ' - ';
        $value = $this->resolveValue($context->find('current_course_shortname'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= '</h5>
';
        $buffer .= $indent . '                    <div class="text-muted small">
';
        $value = $context->find('has_leaderboard');
        $buffer .= $this->section7768c526962ce9359c1bd698749c7e1f($context, $indent, $value);
        $value = $context->find('has_leaderboard');
        if (empty($value)) {
            
            $buffer .= $indent . '                        <em>';
            $value = $context->find('str');
            $buffer .= $this->section94b1b2da5a28c1f6863e04c32d93ab0c($context, $indent, $value);
            $buffer .= '</em>
';
        }
        $buffer .= $indent . '                    </div>
';
        $buffer .= $indent . '                </div>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <div class="text-md-right">
';
        $buffer .= $indent . '                <div class="h5 mb-0">
';
        $buffer .= $indent . '                    <span class="badge badge-primary p-2">
';
        $buffer .= $indent . '                        👤 ';
        $value = $context->find('str');
        $buffer .= $this->sectionEf617e187df5c785ced0cfe72cb11e78($context, $indent, $value);
        $buffer .= ': <strong>';
        $value = $context->find('my_rank');
        $buffer .= $this->section04b69f6066b354b24eb89ac13ff9dc04($context, $indent, $value);
        $value = $context->find('my_rank');
        if (empty($value)) {
            
            $buffer .= '—';
        }
        $buffer .= '</strong>
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                    <span class="badge badge-warning text-dark p-2 ml-1">
';
        $buffer .= $indent . '                        ';
        $value = $this->resolveValue($context->find('my_stars'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= ' ⭐
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                    <span class="badge badge-info p-2 ml-1">
';
        $buffer .= $indent . '                        ';
        $value = $this->resolveValue($context->find('my_count'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= ' testcases
';
        $buffer .= $indent . '                    </span>
';
        $buffer .= $indent . '                </div>
';
        $value = $context->find('has_unclaimed_rewards');
        $buffer .= $this->section23562c735e5b36060da1d04ba0af5c64($context, $indent, $value);
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</div>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '<ul class="nav nav-tabs" role="tablist">
';
        $value = $context->find('is_teacher');
        $buffer .= $this->section2cfcb9ec042f9147f840659477ada1af($context, $indent, $value);
        $buffer .= $indent . '    <li class="nav-item"><a class="nav-link ';
        $value = $context->find('is_teacher');
        if (empty($value)) {
            
            $buffer .= 'active';
        }
        $buffer .= '" data-toggle="tab" href="#runs">';
        $value = $context->find('str');
        $buffer .= $this->sectionF9891d6cb4e7be1138d2f0b89848cc5f($context, $indent, $value);
        $buffer .= ' (';
        $value = $this->resolveValue($context->find('run_count'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= ')</a></li>
';
        $buffer .= $indent . '    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#contributions">';
        $value = $context->find('str');
        $buffer .= $this->sectionF234ca24bbe7e007b280c1fc685f4fae($context, $indent, $value);
        $buffer .= ' (';
        $value = $this->resolveValue($context->find('contribution_count'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= ')</a></li>
';
        $buffer .= $indent . '    <li class="nav-item">
';
        $buffer .= $indent . '        <a class="nav-link position-relative" data-toggle="tab" href="#rewards">
';
        $buffer .= $indent . '            ';
        $value = $context->find('str');
        $buffer .= $this->section882ffa9f688030d6b54bece2b10773e5($context, $indent, $value);
        $buffer .= ' (';
        $value = $this->resolveValue($context->find('reward_count'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= ')
';
        $value = $context->find('has_unclaimed_rewards');
        $buffer .= $this->section0d8ef84f1aafaba2ddf57d36771d7d70($context, $indent, $value);
        $buffer .= $indent . '        </a>
';
        $buffer .= $indent . '    </li>
';
        $buffer .= $indent . '    <li class="nav-item"><a class="nav-link font-weight-bold text-dark" data-toggle="tab" href="#leaderboard">🏆 ';
        $value = $context->find('str');
        $buffer .= $this->sectionEf0dbbbbed9dd328063b6447460a6930($context, $indent, $value);
        $buffer .= '</a></li>
';
        $buffer .= $indent . '</ul>
';
        $buffer .= $indent . '<div class="tab-content border border-top-0 p-3 mb-4">
';
        $value = $context->find('is_teacher');
        $buffer .= $this->sectionD5e165378c5d857acff683bb0fdd36a3($context, $indent, $value);
        $buffer .= $indent . '    <div class="tab-pane ';
        $value = $context->find('is_teacher');
        if (empty($value)) {
            
            $buffer .= 'active';
        }
        $buffer .= '" id="runs">
';
        $buffer .= $indent . '        <div class="table-responsive">
';
        $buffer .= $indent . '            <table class="table table-sm table-bordered table-hover">
';
        $buffer .= $indent . '                <thead class="thead-light">
';
        $buffer .= $indent . '                    <tr>
';
        $buffer .= $indent . '                        <th style="width: 50px;">ID</th>
';
        $buffer .= $indent . '                        <th>Test Code (Input)</th>
';
        $buffer .= $indent . '                        <th>Kỳ vọng (Expected)</th>
';
        $buffer .= $indent . '                        <th>Code của bạn in ra (Got)</th>
';
        $buffer .= $indent . '                        <th style="width: 150px;">Thẩm định Solution</th>
';
        $buffer .= $indent . '                        <th style="width: 130px;">Hành động</th>
';
        $buffer .= $indent . '                    </tr>
';
        $buffer .= $indent . '                </thead>
';
        $buffer .= $indent . '                <tbody>
';
        $value = $context->find('runs');
        if (empty($value)) {
            
            $buffer .= $indent . '                    <tr><td colspan="6" class="text-center text-muted py-3">Chưa có lượt chạy thử nghiệm nào. Hãy dán code và nhập testcase ở trên để chạy thử!</td></tr>
';
        }
        $value = $context->find('runs');
        $buffer .= $this->section493e01a5a2fa24b0ec00e158824dbc08($context, $indent, $value);
        $buffer .= $indent . '                </tbody>
';
        $buffer .= $indent . '            </table>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '    <div class="tab-pane" id="contributions"><div class="table-responsive"><table class="table table-sm table-striped"><thead><tr><th>ID</th><th>Input</th><th>';
        $value = $context->find('str');
        $buffer .= $this->sectionF6d8114da9c7bff859d802d41c6c3256($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section99380e31c66dc018fdbb40851d8c070c($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section237a5b12de4e3e9871419c02873d73ea($context, $indent, $value);
        $buffer .= ' / ';
        $value = $context->find('str');
        $buffer .= $this->sectionE5e23567ad08a2707675347646352974($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section664f62332772dbc21a7a324f47ad636e($context, $indent, $value);
        $buffer .= '</th></tr></thead><tbody>';
        $value = $context->find('contributions');
        $buffer .= $this->section2091fe7451d4f46b7dba8d5ade9a79a1($context, $indent, $value);
        $buffer .= '</tbody></table></div></div>
';
        $buffer .= $indent . '    
';
        $buffer .= $indent . '    <div class="tab-pane" id="rewards">
';
        $buffer .= $indent . '        <div class="table-responsive">
';
        $buffer .= $indent . '            <table class="table table-sm table-striped">
';
        $buffer .= $indent . '                <thead>
';
        $buffer .= $indent . '                    <tr>
';
        $buffer .= $indent . '                        <th>ID</th>
';
        $buffer .= $indent . '                        <th>Input</th>
';
        $buffer .= $indent . '                        <th>';
        $value = $context->find('str');
        $buffer .= $this->section9b9054987cd3b32d511d5845018cc8b0($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                        <th>';
        $value = $context->find('str');
        $buffer .= $this->sectionF6d8114da9c7bff859d802d41c6c3256($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                        <th>';
        $value = $context->find('str');
        $buffer .= $this->section99380e31c66dc018fdbb40851d8c070c($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                        <th>';
        $value = $context->find('str');
        $buffer .= $this->section4ea99b2dd3e1e25afe390c32a57d09bb($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                    </tr>
';
        $buffer .= $indent . '                </thead>
';
        $buffer .= $indent . '                <tbody>
';
        $value = $context->find('rewards');
        if (empty($value)) {
            
            $buffer .= $indent . '                    <tr><td colspan="6" class="text-center text-muted py-3">';
            $value = $context->find('str');
            $buffer .= $this->section44bd0bf65d2bd35d6e8110a9e70e69fb($context, $indent, $value);
            $buffer .= '</td></tr>
';
        }
        $value = $context->find('rewards');
        $buffer .= $this->sectionF537780184fa158d8d9598fc6ec03ffa($context, $indent, $value);
        $buffer .= $indent . '                </tbody>
';
        $buffer .= $indent . '            </table>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '    <div class="tab-pane" id="leaderboard">
';
        $buffer .= $indent . '        <div class="d-flex justify-content-between align-items-center mb-3">
';
        $buffer .= $indent . '            <h5 class="mb-0 font-weight-bold">🏆 ';
        $value = $context->find('str');
        $buffer .= $this->section59e5010696165b305ea4cb6f45a68873($context, $indent, $value);
        $buffer .= '</h5>
';
        $buffer .= $indent . '            <small class="text-muted">';
        $value = $context->find('str');
        $buffer .= $this->sectionBc2396f8cbc8c92133626f11ab08ef77($context, $indent, $value);
        $buffer .= '</small>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="table-responsive">
';
        $buffer .= $indent . '            <table class="table table-sm table-hover table-striped">
';
        $buffer .= $indent . '                <thead class="thead-light">
';
        $buffer .= $indent . '                    <tr>
';
        $buffer .= $indent . '                        <th style="width: 80px;">';
        $value = $context->find('str');
        $buffer .= $this->section63ef24c100f49daa6c2f991766a40503($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                        <th>';
        $value = $context->find('str');
        $buffer .= $this->section058949d940063367d3d5381df0d810c8($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                        <th>';
        $value = $context->find('str');
        $buffer .= $this->sectionDab60f792eac9826ddee3789a8e33540($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                        <th>';
        $value = $context->find('str');
        $buffer .= $this->sectionDc17d461b9e731821f5ded54a6569bd5($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                        <th>';
        $value = $context->find('str');
        $buffer .= $this->section063999259675464f559f4e47ee3f3866($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                    </tr>
';
        $buffer .= $indent . '                </thead>
';
        $buffer .= $indent . '                <tbody>
';
        $value = $context->find('has_leaderboard');
        if (empty($value)) {
            
            $buffer .= $indent . '                    <tr><td colspan="5" class="text-center text-muted py-3">';
            $value = $context->find('str');
            $buffer .= $this->section94b1b2da5a28c1f6863e04c32d93ab0c($context, $indent, $value);
            $buffer .= '</td></tr>
';
        }
        $value = $context->find('leaderboard');
        $buffer .= $this->sectionB5dcb3139e02d168e8072b5bf6c46613($context, $indent, $value);
        $buffer .= $indent . '                </tbody>
';
        $buffer .= $indent . '            </table>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</div>
';

        return $buffer;
    }

    private function section935207dbb135155d9033286c71d96189(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' course ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' course ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4b647e8c317e0c7bd8dc69b2d92349ab(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' allcourses, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' allcourses, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section85cf18307942aa0a878ed360612632ea(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' switchcourse, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' switchcourse, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9e2875c627d2dbad7c957250bbb623f7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'selected';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'selected';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC56bd66fc097d0a33857c935199760f4(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                <option value="{{switch_url}}" {{#is_current}}selected{{/is_current}}>{{shortname}} - {{fullname}}</option>
                ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                <option value="';
                $value = $this->resolveValue($context->find('switch_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" ';
                $value = $context->find('is_current');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $this->resolveValue($context->find('shortname'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' - ';
                $value = $this->resolveValue($context->find('fullname'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section19dc20d609c61af79a73fbd8c5838131(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="card bg-light mb-3 p-2">
    <div class="d-flex flex-wrap justify-content-between align-items-center">
        <div>
            <span class="text-muted mr-1">📚 {{#str}} course {{/str}}:</span>
            <strong>{{current_course_name}}</strong>
            <a href="{{course_hub_url}}" class="badge badge-secondary ml-2">&larr; {{#str}} allcourses, local_testcase_exchange {{/str}}</a>
        </div>
        <div class="d-flex align-items-center mt-1 mt-md-0">
            <label for="switchCourseSelect" class="small text-muted mb-0 mr-2">{{#str}} switchcourse, local_testcase_exchange {{/str}}:</label>
            <select id="switchCourseSelect" class="custom-select custom-select-sm" onchange="if (this.value) window.location.href=this.value;">
                {{#available_courses}}
                <option value="{{switch_url}}" {{#is_current}}selected{{/is_current}}>{{shortname}} - {{fullname}}</option>
                {{/available_courses}}
            </select>
        </div>
    </div>
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="card bg-light mb-3 p-2">
';
                $buffer .= $indent . '    <div class="d-flex flex-wrap justify-content-between align-items-center">
';
                $buffer .= $indent . '        <div>
';
                $buffer .= $indent . '            <span class="text-muted mr-1">📚 ';
                $value = $context->find('str');
                $buffer .= $this->section935207dbb135155d9033286c71d96189($context, $indent, $value);
                $buffer .= ':</span>
';
                $buffer .= $indent . '            <strong>';
                $value = $this->resolveValue($context->find('current_course_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong>
';
                $buffer .= $indent . '            <a href="';
                $value = $this->resolveValue($context->find('course_hub_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" class="badge badge-secondary ml-2">&larr; ';
                $value = $context->find('str');
                $buffer .= $this->section4b647e8c317e0c7bd8dc69b2d92349ab($context, $indent, $value);
                $buffer .= '</a>
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '        <div class="d-flex align-items-center mt-1 mt-md-0">
';
                $buffer .= $indent . '            <label for="switchCourseSelect" class="small text-muted mb-0 mr-2">';
                $value = $context->find('str');
                $buffer .= $this->section85cf18307942aa0a878ed360612632ea($context, $indent, $value);
                $buffer .= ':</label>
';
                $buffer .= $indent . '            <select id="switchCourseSelect" class="custom-select custom-select-sm" onchange="if (this.value) window.location.href=this.value;">
';
                $value = $context->find('available_courses');
                $buffer .= $this->sectionC56bd66fc097d0a33857c935199760f4($context, $indent, $value);
                $buffer .= $indent . '            </select>
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '    </div>
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7b108c120350250de45d032e1ccc0e06(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' backtocurrentquiz, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' backtocurrentquiz, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section70c2ecfed881d1707308d6e1e1b28afd(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ': <strong>{{return_quiz_name}}</strong>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ': <strong>';
                $value = $this->resolveValue($context->find('return_quiz_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section87c59f451c3c43d874f31d52370163a7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="mb-3 d-flex align-items-center">
    <a class="btn btn-outline-secondary font-weight-bold" href="{{return_url}}">
        &larr; {{#str}} backtocurrentquiz, local_testcase_exchange {{/str}}{{#return_quiz_name}}: <strong>{{return_quiz_name}}</strong>{{/return_quiz_name}}
    </a>
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="mb-3 d-flex align-items-center">
';
                $buffer .= $indent . '    <a class="btn btn-outline-secondary font-weight-bold" href="';
                $value = $this->resolveValue($context->find('return_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '        &larr; ';
                $value = $context->find('str');
                $buffer .= $this->section7b108c120350250de45d032e1ccc0e06($context, $indent, $value);
                $value = $context->find('return_quiz_name');
                $buffer .= $this->section70c2ecfed881d1707308d6e1e1b28afd($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '    </a>
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section813ec5a09be0517982e993b59ae572e1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' managepolicies, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' managepolicies, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBb0fa0981f84b55bb525290d43006ea0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<a class="btn btn-secondary mr-2 mb-2" href="{{policy_url}}">{{#str}} managepolicies, local_testcase_exchange {{/str}}</a>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<a class="btn btn-secondary mr-2 mb-2" href="';
                $value = $this->resolveValue($context->find('policy_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $context->find('str');
                $buffer .= $this->section813ec5a09be0517982e993b59ae572e1($context, $indent, $value);
                $buffer .= '</a>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD6c9c7713099e6e1d3a0d5742327ae77(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' reviewcontributions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' reviewcontributions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionEa1915e2afe8b2ed4bc70127991b37da(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<a class="btn btn-primary mr-2 mb-2" href="{{review_url}}">{{#str}} reviewcontributions, local_testcase_exchange {{/str}} <span class="badge badge-light ml-1">{{pending_contribution_count}}</span></a>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<a class="btn btn-primary mr-2 mb-2" href="';
                $value = $this->resolveValue($context->find('review_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $context->find('str');
                $buffer .= $this->sectionD6c9c7713099e6e1d3a0d5742327ae77($context, $indent, $value);
                $buffer .= ' <span class="badge badge-light ml-1">';
                $value = $this->resolveValue($context->find('pending_contribution_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span></a>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBfaacc9ad82beeea4d52803ed75a03c2(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="mb-3 d-flex flex-wrap align-items-center">
    {{#can_manage}}<a class="btn btn-secondary mr-2 mb-2" href="{{policy_url}}">{{#str}} managepolicies, local_testcase_exchange {{/str}}</a>{{/can_manage}}
    {{#can_review}}<a class="btn btn-primary mr-2 mb-2" href="{{review_url}}">{{#str}} reviewcontributions, local_testcase_exchange {{/str}} <span class="badge badge-light ml-1">{{pending_contribution_count}}</span></a>{{/can_review}}
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="mb-3 d-flex flex-wrap align-items-center">
';
                $buffer .= $indent . '    ';
                $value = $context->find('can_manage');
                $buffer .= $this->sectionBb0fa0981f84b55bb525290d43006ea0($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '    ';
                $value = $context->find('can_review');
                $buffer .= $this->sectionEa1915e2afe8b2ed4bc70127991b37da($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section06c4ac2f77fe4992bc6fbdea0085b571(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
        <a class="btn btn-outline-secondary btn-sm mb-3" href="{{return_url}}">
            &larr; {{#str}} backtocurrentquiz, local_testcase_exchange {{/str}}
        </a>
        ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        <a class="btn btn-outline-secondary btn-sm mb-3" href="';
                $value = $this->resolveValue($context->find('return_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '            &larr; ';
                $value = $context->find('str');
                $buffer .= $this->section7b108c120350250de45d032e1ccc0e06($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '        </a>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBd2d40cdfbac59f93e95c6f826d86349(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' nocoderunnerquestions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' nocoderunnerquestions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section5b3c2c7359200a0f9ca8de84cb395381(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' selectquestion, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' selectquestion, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC87198b06c7ce18b3aeed72afb34afb9(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'disabled';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'disabled';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section17be0db7ffe678fe3f9cc9b5cf2576e6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <option value="{{value}}" {{#disabled}}disabled{{/disabled}} {{#selected}}selected{{/selected}}>{{label}}</option>
                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <option value="';
                $value = $this->resolveValue($context->find('value'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" ';
                $value = $context->find('disabled');
                $buffer .= $this->sectionC87198b06c7ce18b3aeed72afb34afb9($context, $indent, $value);
                $buffer .= ' ';
                $value = $context->find('selected');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $this->resolveValue($context->find('label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section09d00216d9bf705a2474a88f8f21c355(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                            <option value="{{value}}">{{label}}</option>
                            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                            <option value="';
                $value = $this->resolveValue($context->find('value'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $this->resolveValue($context->find('label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA7d19e444293c59cf4011635540ee063(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
        <form method="post">
            <input type="hidden" name="sesskey" value="{{sesskey}}">
            <input type="hidden" name="action" value="run">

            <div class="form-group mb-3">
                <label for="question"><strong>🎯 {{#str}} selectquestion, local_testcase_exchange {{/str}}:</strong></label>
                <select class="form-control font-weight-bold" id="question" name="question" required>
                    {{#questions}}
                    <option value="{{value}}" {{#disabled}}disabled{{/disabled}} {{#selected}}selected{{/selected}}>{{label}}</option>
                    {{/questions}}
                </select>
            </div>

            <!-- Khung soạn thảo / dán mã nguồn sinh viên -->
            <div class="form-group mb-3">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <label for="student_code" class="mb-0"><strong>💻 Mã nguồn chương trình của bạn (Student Source Code):</strong></label>
                    <small class="text-muted">Bạn có thể tự do dán (paste) hoặc gõ code mới vào đây để thử nghiệm</small>
                </div>
                <textarea class="form-control font-monospace text-dark bg-light" id="student_code" name="student_code" rows="7" required placeholder="def tinh_tong(n):&#10;    # Dán mã nguồn Python của bạn vào đây&#10;    pass" style="font-family: Consolas, Monaco, monospace; font-size: 0.95rem;">{{student_code}}</textarea>
            </div>

            <!-- Khung định nghĩa Testcase theo phong cách CodeRunner -->
            <div class="card bg-light border p-3 mb-3">
                <h6 class="font-weight-bold text-dark mb-3">📝 Định nghĩa Ca kiểm thử (Testcase Definition):</h6>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="test_input"><strong>Test Code (Lệnh gọi hàm kiểm thử):</strong></label>
                        <textarea class="form-control font-monospace" id="test_input" name="test_input" rows="3" required placeholder="Ví dụ: print(tinh_tong(10))" style="font-family: Consolas, monospace;"></textarea>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="predicted_output"><strong>Expected Output (Kết quả bạn kỳ vọng in ra):</strong></label>
                        <textarea class="form-control font-monospace" id="predicted_output" name="predicted_output" rows="3" required placeholder="Ví dụ: 55" style="font-family: Consolas, monospace;"></textarea>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="category">Phân loại ca kiểm thử:</label>
                        <select class="form-control" id="category" name="category">
                            {{#categories}}
                            <option value="{{value}}">{{label}}</option>
                            {{/categories}}
                        </select>
                    </div>
                    <div class="col-md-8 form-group">
                        <label for="purpose">Mục đích kiểm thử (Giải thích lý do bạn thiết kế test này):</label>
                        <input class="form-control" id="purpose" name="purpose" maxlength="1000" placeholder="Ví dụ: Kiểm tra trường hợp số nguyên dương lớn n=10">
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <button class="btn btn-primary font-weight-bold px-4 py-2 shadow-sm" type="submit">
                    ▶️ Chạy Thử Nghiệm Vi Sai (Run Test)
                </button>
                <small class="text-muted">Hệ thống sẽ chạy song song trên Code của bạn và Solution của Thầy/Cô</small>
            </div>
        </form>
        ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        <form method="post">
';
                $buffer .= $indent . '            <input type="hidden" name="sesskey" value="';
                $value = $this->resolveValue($context->find('sesskey'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '            <input type="hidden" name="action" value="run">
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '            <div class="form-group mb-3">
';
                $buffer .= $indent . '                <label for="question"><strong>🎯 ';
                $value = $context->find('str');
                $buffer .= $this->section5b3c2c7359200a0f9ca8de84cb395381($context, $indent, $value);
                $buffer .= ':</strong></label>
';
                $buffer .= $indent . '                <select class="form-control font-weight-bold" id="question" name="question" required>
';
                $value = $context->find('questions');
                $buffer .= $this->section17be0db7ffe678fe3f9cc9b5cf2576e6($context, $indent, $value);
                $buffer .= $indent . '                </select>
';
                $buffer .= $indent . '            </div>
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '            <!-- Khung soạn thảo / dán mã nguồn sinh viên -->
';
                $buffer .= $indent . '            <div class="form-group mb-3">
';
                $buffer .= $indent . '                <div class="d-flex justify-content-between align-items-center mb-1">
';
                $buffer .= $indent . '                    <label for="student_code" class="mb-0"><strong>💻 Mã nguồn chương trình của bạn (Student Source Code):</strong></label>
';
                $buffer .= $indent . '                    <small class="text-muted">Bạn có thể tự do dán (paste) hoặc gõ code mới vào đây để thử nghiệm</small>
';
                $buffer .= $indent . '                </div>
';
                $buffer .= $indent . '                <textarea class="form-control font-monospace text-dark bg-light" id="student_code" name="student_code" rows="7" required placeholder="def tinh_tong(n):&#10;    # Dán mã nguồn Python của bạn vào đây&#10;    pass" style="font-family: Consolas, Monaco, monospace; font-size: 0.95rem;">';
                $value = $this->resolveValue($context->find('student_code'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</textarea>
';
                $buffer .= $indent . '            </div>
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '            <!-- Khung định nghĩa Testcase theo phong cách CodeRunner -->
';
                $buffer .= $indent . '            <div class="card bg-light border p-3 mb-3">
';
                $buffer .= $indent . '                <h6 class="font-weight-bold text-dark mb-3">📝 Định nghĩa Ca kiểm thử (Testcase Definition):</h6>
';
                $buffer .= $indent . '                <div class="row">
';
                $buffer .= $indent . '                    <div class="col-md-6 form-group">
';
                $buffer .= $indent . '                        <label for="test_input"><strong>Test Code (Lệnh gọi hàm kiểm thử):</strong></label>
';
                $buffer .= $indent . '                        <textarea class="form-control font-monospace" id="test_input" name="test_input" rows="3" required placeholder="Ví dụ: print(tinh_tong(10))" style="font-family: Consolas, monospace;"></textarea>
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                    <div class="col-md-6 form-group">
';
                $buffer .= $indent . '                        <label for="predicted_output"><strong>Expected Output (Kết quả bạn kỳ vọng in ra):</strong></label>
';
                $buffer .= $indent . '                        <textarea class="form-control font-monospace" id="predicted_output" name="predicted_output" rows="3" required placeholder="Ví dụ: 55" style="font-family: Consolas, monospace;"></textarea>
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                </div>
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '                <div class="row">
';
                $buffer .= $indent . '                    <div class="col-md-4 form-group">
';
                $buffer .= $indent . '                        <label for="category">Phân loại ca kiểm thử:</label>
';
                $buffer .= $indent . '                        <select class="form-control" id="category" name="category">
';
                $value = $context->find('categories');
                $buffer .= $this->section09d00216d9bf705a2474a88f8f21c355($context, $indent, $value);
                $buffer .= $indent . '                        </select>
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                    <div class="col-md-8 form-group">
';
                $buffer .= $indent . '                        <label for="purpose">Mục đích kiểm thử (Giải thích lý do bạn thiết kế test này):</label>
';
                $buffer .= $indent . '                        <input class="form-control" id="purpose" name="purpose" maxlength="1000" placeholder="Ví dụ: Kiểm tra trường hợp số nguyên dương lớn n=10">
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                </div>
';
                $buffer .= $indent . '            </div>
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '            <div class="d-flex justify-content-between align-items-center">
';
                $buffer .= $indent . '                <button class="btn btn-primary font-weight-bold px-4 py-2 shadow-sm" type="submit">
';
                $buffer .= $indent . '                    ▶️ Chạy Thử Nghiệm Vi Sai (Run Test)
';
                $buffer .= $indent . '                </button>
';
                $buffer .= $indent . '                <small class="text-muted">Hệ thống sẽ chạy song song trên Code của bạn và Solution của Thầy/Cô</small>
';
                $buffer .= $indent . '            </div>
';
                $buffer .= $indent . '        </form>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD22236edc8a4f5906cafdcb73fa758d1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="card mb-4 border-primary shadow-sm">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <strong>🧪 Phòng Thí Nghiệm Kiểm Thử Vi Sai (Differential Testing Playground)</strong>
        <span class="badge badge-light text-dark">Thử nghiệm tự do — Không tính điểm phạt</span>
    </div>
    <div class="card-body">
        <p class="text-muted small mb-3">
            Tại đây bạn có thể dán mã nguồn chương trình, tự thiết kế testcase và chạy thử nghiệm. Hệ thống sẽ đối chiếu kết quả giữa <strong>Chương trình của bạn</strong> và <strong>Đáp án chuẩn của Thầy/Cô (Solution)</strong> để giúp bạn phát hiện lỗi logic trước khi nộp bài thi Quiz.
        </p>

        {{#has_return_url}}
        <a class="btn btn-outline-secondary btn-sm mb-3" href="{{return_url}}">
            &larr; {{#str}} backtocurrentquiz, local_testcase_exchange {{/str}}
        </a>
        {{/has_return_url}}

        {{^has_questions}}
        <div class="alert alert-warning">{{#str}} nocoderunnerquestions, local_testcase_exchange {{/str}}</div>
        {{/has_questions}}

        {{#has_questions}}
        <form method="post">
            <input type="hidden" name="sesskey" value="{{sesskey}}">
            <input type="hidden" name="action" value="run">

            <div class="form-group mb-3">
                <label for="question"><strong>🎯 {{#str}} selectquestion, local_testcase_exchange {{/str}}:</strong></label>
                <select class="form-control font-weight-bold" id="question" name="question" required>
                    {{#questions}}
                    <option value="{{value}}" {{#disabled}}disabled{{/disabled}} {{#selected}}selected{{/selected}}>{{label}}</option>
                    {{/questions}}
                </select>
            </div>

            <!-- Khung soạn thảo / dán mã nguồn sinh viên -->
            <div class="form-group mb-3">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <label for="student_code" class="mb-0"><strong>💻 Mã nguồn chương trình của bạn (Student Source Code):</strong></label>
                    <small class="text-muted">Bạn có thể tự do dán (paste) hoặc gõ code mới vào đây để thử nghiệm</small>
                </div>
                <textarea class="form-control font-monospace text-dark bg-light" id="student_code" name="student_code" rows="7" required placeholder="def tinh_tong(n):&#10;    # Dán mã nguồn Python của bạn vào đây&#10;    pass" style="font-family: Consolas, Monaco, monospace; font-size: 0.95rem;">{{student_code}}</textarea>
            </div>

            <!-- Khung định nghĩa Testcase theo phong cách CodeRunner -->
            <div class="card bg-light border p-3 mb-3">
                <h6 class="font-weight-bold text-dark mb-3">📝 Định nghĩa Ca kiểm thử (Testcase Definition):</h6>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="test_input"><strong>Test Code (Lệnh gọi hàm kiểm thử):</strong></label>
                        <textarea class="form-control font-monospace" id="test_input" name="test_input" rows="3" required placeholder="Ví dụ: print(tinh_tong(10))" style="font-family: Consolas, monospace;"></textarea>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="predicted_output"><strong>Expected Output (Kết quả bạn kỳ vọng in ra):</strong></label>
                        <textarea class="form-control font-monospace" id="predicted_output" name="predicted_output" rows="3" required placeholder="Ví dụ: 55" style="font-family: Consolas, monospace;"></textarea>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 form-group">
                        <label for="category">Phân loại ca kiểm thử:</label>
                        <select class="form-control" id="category" name="category">
                            {{#categories}}
                            <option value="{{value}}">{{label}}</option>
                            {{/categories}}
                        </select>
                    </div>
                    <div class="col-md-8 form-group">
                        <label for="purpose">Mục đích kiểm thử (Giải thích lý do bạn thiết kế test này):</label>
                        <input class="form-control" id="purpose" name="purpose" maxlength="1000" placeholder="Ví dụ: Kiểm tra trường hợp số nguyên dương lớn n=10">
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <button class="btn btn-primary font-weight-bold px-4 py-2 shadow-sm" type="submit">
                    ▶️ Chạy Thử Nghiệm Vi Sai (Run Test)
                </button>
                <small class="text-muted">Hệ thống sẽ chạy song song trên Code của bạn và Solution của Thầy/Cô</small>
            </div>
        </form>
        {{/has_questions}}
    </div>
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="card mb-4 border-primary shadow-sm">
';
                $buffer .= $indent . '    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
';
                $buffer .= $indent . '        <strong>🧪 Phòng Thí Nghiệm Kiểm Thử Vi Sai (Differential Testing Playground)</strong>
';
                $buffer .= $indent . '        <span class="badge badge-light text-dark">Thử nghiệm tự do — Không tính điểm phạt</span>
';
                $buffer .= $indent . '    </div>
';
                $buffer .= $indent . '    <div class="card-body">
';
                $buffer .= $indent . '        <p class="text-muted small mb-3">
';
                $buffer .= $indent . '            Tại đây bạn có thể dán mã nguồn chương trình, tự thiết kế testcase và chạy thử nghiệm. Hệ thống sẽ đối chiếu kết quả giữa <strong>Chương trình của bạn</strong> và <strong>Đáp án chuẩn của Thầy/Cô (Solution)</strong> để giúp bạn phát hiện lỗi logic trước khi nộp bài thi Quiz.
';
                $buffer .= $indent . '        </p>
';
                $buffer .= $indent . '
';
                $value = $context->find('has_return_url');
                $buffer .= $this->section06c4ac2f77fe4992bc6fbdea0085b571($context, $indent, $value);
                $buffer .= $indent . '
';
                $value = $context->find('has_questions');
                if (empty($value)) {
                    
                    $buffer .= $indent . '        <div class="alert alert-warning">';
                    $value = $context->find('str');
                    $buffer .= $this->sectionBd2d40cdfbac59f93e95c6f826d86349($context, $indent, $value);
                    $buffer .= '</div>
';
                }
                $buffer .= $indent . '
';
                $value = $context->find('has_questions');
                $buffer .= $this->sectionA7d19e444293c59cf4011635540ee063($context, $indent, $value);
                $buffer .= $indent . '    </div>
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionEf0dbbbbed9dd328063b6447460a6930(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' leaderboard, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' leaderboard, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section28d6be11cd952c679431d50740dd4f73(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rank_1, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rank_1, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7768c526962ce9359c1bd698749c7e1f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                        🥇 <strong>{{#str}} rank_1, local_testcase_exchange {{/str}}:</strong> {{top_user_name}} (<span class="text-warning font-weight-bold">{{top_stars}} ⭐</span> | {{top_count}} testcases)
                        ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                        🥇 <strong>';
                $value = $context->find('str');
                $buffer .= $this->section28d6be11cd952c679431d50740dd4f73($context, $indent, $value);
                $buffer .= ':</strong> ';
                $value = $this->resolveValue($context->find('top_user_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' (<span class="text-warning font-weight-bold">';
                $value = $this->resolveValue($context->find('top_stars'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' ⭐</span> | ';
                $value = $this->resolveValue($context->find('top_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' testcases)
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section94b1b2da5a28c1f6863e04c32d93ab0c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' no_leaderboard_yet, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' no_leaderboard_yet, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionEf617e187df5c785ced0cfe72cb11e78(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' your_rank, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' your_rank, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section04b69f6066b354b24eb89ac13ff9dc04(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '#{{my_rank}}';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '#';
                $value = $this->resolveValue($context->find('my_rank'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section58199ea3e9cb6a5ad5f30219106308b2(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' unclaimed_rewards_alert, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' unclaimed_rewards_alert, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section23562c735e5b36060da1d04ba0af5c64(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                <div class="mt-2">
                    <a href="#rewards" data-toggle="tab" class="badge badge-danger p-2 animate-pulse text-white">
                        🎁 {{#str}} unclaimed_rewards_alert, local_testcase_exchange {{/str}}: <strong>{{unclaimed_rewards_count}}</strong>
                    </a>
                </div>
                ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                <div class="mt-2">
';
                $buffer .= $indent . '                    <a href="#rewards" data-toggle="tab" class="badge badge-danger p-2 animate-pulse text-white">
';
                $buffer .= $indent . '                        🎁 ';
                $value = $context->find('str');
                $buffer .= $this->section58199ea3e9cb6a5ad5f30219106308b2($context, $indent, $value);
                $buffer .= ': <strong>';
                $value = $this->resolveValue($context->find('unclaimed_rewards_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong>
';
                $buffer .= $indent . '                    </a>
';
                $buffer .= $indent . '                </div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section08cb77ec4dd9c03b222e69f54d34993a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' coursecontributions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' coursecontributions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2cfcb9ec042f9147f840659477ada1af(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <li class="nav-item"><a class="nav-link active font-weight-bold" data-toggle="tab" href="#course_contributions">{{#str}} coursecontributions, local_testcase_exchange {{/str}} ({{course_contribution_count}})</a></li>
    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <li class="nav-item"><a class="nav-link active font-weight-bold" data-toggle="tab" href="#course_contributions">';
                $value = $context->find('str');
                $buffer .= $this->section08cb77ec4dd9c03b222e69f54d34993a($context, $indent, $value);
                $buffer .= ' (';
                $value = $this->resolveValue($context->find('course_contribution_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ')</a></li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF9891d6cb4e7be1138d2f0b89848cc5f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' myruns, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' myruns, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF234ca24bbe7e007b280c1fc685f4fae(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' mycontributions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' mycontributions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section882ffa9f688030d6b54bece2b10773e5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' myrewards, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' myrewards, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section0d8ef84f1aafaba2ddf57d36771d7d70(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
            <span class="badge badge-danger ml-1">{{unclaimed_rewards_count}}</span>
            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '            <span class="badge badge-danger ml-1">';
                $value = $this->resolveValue($context->find('unclaimed_rewards_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section622d1f2d1148fb424607e49d3ad122da(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<a class="btn btn-sm btn-primary" href="{{review_url}}">{{#str}} reviewcontributions, local_testcase_exchange {{/str}} &rarr;</a>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<a class="btn btn-sm btn-primary" href="';
                $value = $this->resolveValue($context->find('review_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $context->find('str');
                $buffer .= $this->sectionD6c9c7713099e6e1d3a0d5742327ae77($context, $indent, $value);
                $buffer .= ' &rarr;</a>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section058949d940063367d3d5381df0d810c8(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' student, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' student, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFbf3bb14fdfb73409b8836554df1d06d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' quizquestion, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' quizquestion, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB944b350b43a30cdf4afb7551a33da5d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' testinput, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' testinput, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9b9054987cd3b32d511d5845018cc8b0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' oracleoutput, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' oracleoutput, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF6d8114da9c7bff859d802d41c6c3256(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' category, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' category, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section99380e31c66dc018fdbb40851d8c070c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' status ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' status ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section664f62332772dbc21a7a324f47ad636e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' time ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' time ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDb7d5e03b02fdbe6f383a142674d4357(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' nocontributionsfound, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' nocontributionsfound, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDcb7c630b327b3921b8c9316baeaf839(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<br><small class="text-muted">{{purpose}}</small>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<br><small class="text-muted">';
                $value = $this->resolveValue($context->find('purpose'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section6934b3556cd13e1ef08ec215d9f74237(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<div class="mt-1" title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <small class="badge badge-warning text-dark">{{rating_val}}/5 ★</small></div>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<div class="mt-1" title="';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 sao"><span class="text-warning font-weight-bold">';
                $value = $this->resolveValue($context->find('stars_emoji'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span> <small class="badge badge-warning text-dark">';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 ★</small></div>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA945db33b7a7a3a2b3d9612f06c964bd(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 {{teacher_comment}}</div>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 ';
                $value = $this->resolveValue($context->find('teacher_comment'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</div>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9772f68c89b33d6dbfd01fb72d678874(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<tr><td><strong>#{{id}}</strong></td><td><div><strong>{{student_name}}</strong></div><small class="text-muted">{{student_username}}</small></td><td><div><strong>{{quiz_name}}</strong></div><small class="text-muted">{{question_name}}</small></td><td><pre class="mb-0">{{input_normalized}}</pre></td><td><pre class="mb-0">{{oracle_output}}</pre></td><td><span class="badge badge-info">{{category}}</span>{{#purpose}}<br><small class="text-muted">{{purpose}}</small>{{/purpose}}</td><td><span class="{{status_badge_class}}">{{status_label}}</span>{{#has_rating}}<div class="mt-1" title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <small class="badge badge-warning text-dark">{{rating_val}}/5 ★</small></div>{{/has_rating}}{{#has_teacher_comment}}<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 {{teacher_comment}}</div>{{/has_teacher_comment}}</td><td><small>{{submitted_at}}</small></td></tr>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<tr><td><strong>#';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></td><td><div><strong>';
                $value = $this->resolveValue($context->find('student_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></div><small class="text-muted">';
                $value = $this->resolveValue($context->find('student_username'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td><td><div><strong>';
                $value = $this->resolveValue($context->find('quiz_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></div><small class="text-muted">';
                $value = $this->resolveValue($context->find('question_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('input_normalized'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('oracle_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td><span class="badge badge-info">';
                $value = $this->resolveValue($context->find('category'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>';
                $value = $context->find('purpose');
                $buffer .= $this->sectionDcb7c630b327b3921b8c9316baeaf839($context, $indent, $value);
                $buffer .= '</td><td><span class="';
                $value = $this->resolveValue($context->find('status_badge_class'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $this->resolveValue($context->find('status_label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>';
                $value = $context->find('has_rating');
                $buffer .= $this->section6934b3556cd13e1ef08ec215d9f74237($context, $indent, $value);
                $value = $context->find('has_teacher_comment');
                $buffer .= $this->sectionA945db33b7a7a3a2b3d9612f06c964bd($context, $indent, $value);
                $buffer .= '</td><td><small>';
                $value = $this->resolveValue($context->find('submitted_at'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td></tr>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD5e165378c5d857acff683bb0fdd36a3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <div class="tab-pane active" id="course_contributions">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="mb-0">{{#str}} coursecontributions, local_testcase_exchange {{/str}}</h5>
            {{#can_review}}<a class="btn btn-sm btn-primary" href="{{review_url}}">{{#str}} reviewcontributions, local_testcase_exchange {{/str}} &rarr;</a>{{/can_review}}
        </div>
        <div class="table-responsive"><table class="table table-sm table-striped table-hover"><thead><tr><th>ID</th><th>{{#str}} student, local_testcase_exchange {{/str}}</th><th>{{#str}} quizquestion, local_testcase_exchange {{/str}}</th><th>{{#str}} testinput, local_testcase_exchange {{/str}}</th><th>{{#str}} oracleoutput, local_testcase_exchange {{/str}}</th><th>{{#str}} category, local_testcase_exchange {{/str}}</th><th>{{#str}} status {{/str}}</th><th>{{#str}} time {{/str}}</th></tr></thead><tbody>
        {{^has_course_contributions}}<tr><td colspan="8" class="text-center text-muted py-3">{{#str}} nocontributionsfound, local_testcase_exchange {{/str}}</td></tr>{{/has_course_contributions}}
        {{#course_contributions}}<tr><td><strong>#{{id}}</strong></td><td><div><strong>{{student_name}}</strong></div><small class="text-muted">{{student_username}}</small></td><td><div><strong>{{quiz_name}}</strong></div><small class="text-muted">{{question_name}}</small></td><td><pre class="mb-0">{{input_normalized}}</pre></td><td><pre class="mb-0">{{oracle_output}}</pre></td><td><span class="badge badge-info">{{category}}</span>{{#purpose}}<br><small class="text-muted">{{purpose}}</small>{{/purpose}}</td><td><span class="{{status_badge_class}}">{{status_label}}</span>{{#has_rating}}<div class="mt-1" title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <small class="badge badge-warning text-dark">{{rating_val}}/5 ★</small></div>{{/has_rating}}{{#has_teacher_comment}}<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 {{teacher_comment}}</div>{{/has_teacher_comment}}</td><td><small>{{submitted_at}}</small></td></tr>{{/course_contributions}}
        </tbody></table></div>
    </div>
    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <div class="tab-pane active" id="course_contributions">
';
                $buffer .= $indent . '        <div class="d-flex justify-content-between align-items-center mb-3">
';
                $buffer .= $indent . '            <h5 class="mb-0">';
                $value = $context->find('str');
                $buffer .= $this->section08cb77ec4dd9c03b222e69f54d34993a($context, $indent, $value);
                $buffer .= '</h5>
';
                $buffer .= $indent . '            ';
                $value = $context->find('can_review');
                $buffer .= $this->section622d1f2d1148fb424607e49d3ad122da($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '        <div class="table-responsive"><table class="table table-sm table-striped table-hover"><thead><tr><th>ID</th><th>';
                $value = $context->find('str');
                $buffer .= $this->section058949d940063367d3d5381df0d810c8($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->sectionFbf3bb14fdfb73409b8836554df1d06d($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->sectionB944b350b43a30cdf4afb7551a33da5d($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->section9b9054987cd3b32d511d5845018cc8b0($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->sectionF6d8114da9c7bff859d802d41c6c3256($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->section99380e31c66dc018fdbb40851d8c070c($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->section664f62332772dbc21a7a324f47ad636e($context, $indent, $value);
                $buffer .= '</th></tr></thead><tbody>
';
                $buffer .= $indent . '        ';
                $value = $context->find('has_course_contributions');
                if (empty($value)) {
                    
                    $buffer .= '<tr><td colspan="8" class="text-center text-muted py-3">';
                    $value = $context->find('str');
                    $buffer .= $this->sectionDb7d5e03b02fdbe6f383a142674d4357($context, $indent, $value);
                    $buffer .= '</td></tr>';
                }
                $buffer .= '
';
                $buffer .= $indent . '        ';
                $value = $context->find('course_contributions');
                $buffer .= $this->section9772f68c89b33d6dbfd01fb72d678874($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '        </tbody></table></div>
';
                $buffer .= $indent . '    </div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionEae20a0aa6a54148ec311729a7fb74b3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'bg-success text-white';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'bg-success text-white';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF12616d380df85997d2f3d21910996c9(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'bg-danger text-white';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'bg-danger text-white';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC255bece5710694d699efa296f760968(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<span class="badge badge-success">✓ Khớp kỳ vọng</span>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<span class="badge badge-success">✓ Khớp kỳ vọng</span>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section27f46b163ef56b8dbb5760d3b33bfd7c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<span class="badge badge-danger">❌ Lệch kỳ vọng</span>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<span class="badge badge-danger">❌ Lệch kỳ vọng</span>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE77b8f857ce580eb1ca1a5ee734a6f52(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                            <span class="badge badge-success p-2 d-block text-wrap">✓ ĐÚNG CHUẨN ĐỀ</span>
                            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                            <span class="badge badge-success p-2 d-block text-wrap">✓ ĐÚNG CHUẨN ĐỀ</span>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA969cf271c208670c661bf6dc0fd5e88(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                            <pre class="mb-0 mt-1 small bg-dark text-white p-1 rounded">{{oracle_output}}</pre>
                            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                            <pre class="mb-0 mt-1 small bg-dark text-white p-1 rounded">';
                $value = $this->resolveValue($context->find('oracle_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA618b3f8cc74a68804332d1b967d923a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                            <form method="post" class="m-0">
                                <input type="hidden" name="sesskey" value="{{sesskey}}">
                                <input type="hidden" name="action" value="contribute">
                                <input type="hidden" name="run_id" value="{{id}}">
                                <button class="btn btn-sm btn-success font-weight-bold shadow-sm" type="submit">
                                    🚀 Đề xuất Đóng góp
                                </button>
                            </form>
                            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                            <form method="post" class="m-0">
';
                $buffer .= $indent . '                                <input type="hidden" name="sesskey" value="';
                $value = $this->resolveValue($context->find('sesskey'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '                                <input type="hidden" name="action" value="contribute">
';
                $buffer .= $indent . '                                <input type="hidden" name="run_id" value="';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '                                <button class="btn btn-sm btn-success font-weight-bold shadow-sm" type="submit">
';
                $buffer .= $indent . '                                    🚀 Đề xuất Đóng góp
';
                $buffer .= $indent . '                                </button>
';
                $buffer .= $indent . '                            </form>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section493e01a5a2fa24b0ec00e158824dbc08(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <tr>
                        <td><strong>#{{id}}</strong></td>
                        <td><pre class="mb-0 font-monospace bg-light p-1 border rounded">{{input_raw}}</pre></td>
                        <td><pre class="mb-0 font-monospace bg-light p-1 border rounded">{{predicted_output}}</pre></td>
                        <td>
                            <pre class="mb-1 font-monospace p-1 border rounded {{#student_matches_expected}}bg-success text-white{{/student_matches_expected}}{{#student_differs_expected}}bg-danger text-white{{/student_differs_expected}}">{{student_run_output}}</pre>
                            {{#student_matches_expected}}<span class="badge badge-success">✓ Khớp kỳ vọng</span>{{/student_matches_expected}}
                            {{#student_differs_expected}}<span class="badge badge-danger">❌ Lệch kỳ vọng</span>{{/student_differs_expected}}
                            <small class="text-muted d-block mt-1">Status: {{student_outcome}}</small>
                        </td>
                        <td>
                            {{#oracle_valid}}
                            <span class="badge badge-success p-2 d-block text-wrap">✓ ĐÚNG CHUẨN ĐỀ</span>
                            {{/oracle_valid}}
                            {{^oracle_valid}}
                            <span class="badge badge-danger p-2 d-block text-wrap">❌ SAI QUY ƯỚC</span>
                            {{/oracle_valid}}
                            {{#show_oracle}}
                            <pre class="mb-0 mt-1 small bg-dark text-white p-1 rounded">{{oracle_output}}</pre>
                            {{/show_oracle}}
                            <small class="text-muted d-block mt-1">Oracle: {{oracle_outcome}}</small>
                        </td>
                        <td class="align-middle text-center">
                            {{#can_contribute}}
                            <form method="post" class="m-0">
                                <input type="hidden" name="sesskey" value="{{sesskey}}">
                                <input type="hidden" name="action" value="contribute">
                                <input type="hidden" name="run_id" value="{{id}}">
                                <button class="btn btn-sm btn-success font-weight-bold shadow-sm" type="submit">
                                    🚀 Đề xuất Đóng góp
                                </button>
                            </form>
                            {{/can_contribute}}
                            {{^can_contribute}}
                            <span class="badge badge-secondary p-1">{{display_status}}</span>
                            {{/can_contribute}}
                        </td>
                    </tr>
                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <tr>
';
                $buffer .= $indent . '                        <td><strong>#';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></td>
';
                $buffer .= $indent . '                        <td><pre class="mb-0 font-monospace bg-light p-1 border rounded">';
                $value = $this->resolveValue($context->find('input_raw'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td>
';
                $buffer .= $indent . '                        <td><pre class="mb-0 font-monospace bg-light p-1 border rounded">';
                $value = $this->resolveValue($context->find('predicted_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td>
';
                $buffer .= $indent . '                        <td>
';
                $buffer .= $indent . '                            <pre class="mb-1 font-monospace p-1 border rounded ';
                $value = $context->find('student_matches_expected');
                $buffer .= $this->sectionEae20a0aa6a54148ec311729a7fb74b3($context, $indent, $value);
                $value = $context->find('student_differs_expected');
                $buffer .= $this->sectionF12616d380df85997d2f3d21910996c9($context, $indent, $value);
                $buffer .= '">';
                $value = $this->resolveValue($context->find('student_run_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre>
';
                $buffer .= $indent . '                            ';
                $value = $context->find('student_matches_expected');
                $buffer .= $this->sectionC255bece5710694d699efa296f760968($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '                            ';
                $value = $context->find('student_differs_expected');
                $buffer .= $this->section27f46b163ef56b8dbb5760d3b33bfd7c($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '                            <small class="text-muted d-block mt-1">Status: ';
                $value = $this->resolveValue($context->find('student_outcome'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small>
';
                $buffer .= $indent . '                        </td>
';
                $buffer .= $indent . '                        <td>
';
                $value = $context->find('oracle_valid');
                $buffer .= $this->sectionE77b8f857ce580eb1ca1a5ee734a6f52($context, $indent, $value);
                $value = $context->find('oracle_valid');
                if (empty($value)) {
                    
                    $buffer .= $indent . '                            <span class="badge badge-danger p-2 d-block text-wrap">❌ SAI QUY ƯỚC</span>
';
                }
                $value = $context->find('show_oracle');
                $buffer .= $this->sectionA969cf271c208670c661bf6dc0fd5e88($context, $indent, $value);
                $buffer .= $indent . '                            <small class="text-muted d-block mt-1">Oracle: ';
                $value = $this->resolveValue($context->find('oracle_outcome'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small>
';
                $buffer .= $indent . '                        </td>
';
                $buffer .= $indent . '                        <td class="align-middle text-center">
';
                $value = $context->find('can_contribute');
                $buffer .= $this->sectionA618b3f8cc74a68804332d1b967d923a($context, $indent, $value);
                $value = $context->find('can_contribute');
                if (empty($value)) {
                    
                    $buffer .= $indent . '                            <span class="badge badge-secondary p-1">';
                    $value = $this->resolveValue($context->find('display_status'), $context);
                    $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                    $buffer .= '</span>
';
                }
                $buffer .= $indent . '                        </td>
';
                $buffer .= $indent . '                    </tr>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section237a5b12de4e3e9871419c02873d73ea(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' starrating, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' starrating, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE5e23567ad08a2707675347646352974(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' teachercomment, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' teachercomment, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBfaec5c595cdda909054b8cb1a9e20ed(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' resubmitexplanation, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' resubmitexplanation, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section8caef4868704df31045d6a8ea66a37fc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<form method="post" class="mt-2"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="explain"><input type="hidden" name="contribution_id" value="{{id}}"><input class="form-control form-control-sm mb-1" name="explanation" required><button class="btn btn-sm btn-primary">{{#str}} resubmitexplanation, local_testcase_exchange {{/str}}</button></form>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<form method="post" class="mt-2"><input type="hidden" name="sesskey" value="';
                $value = $this->resolveValue($context->find('sesskey'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><input type="hidden" name="action" value="explain"><input type="hidden" name="contribution_id" value="';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><input class="form-control form-control-sm mb-1" name="explanation" required><button class="btn btn-sm btn-primary">';
                $value = $context->find('str');
                $buffer .= $this->sectionBfaec5c595cdda909054b8cb1a9e20ed($context, $indent, $value);
                $buffer .= '</button></form>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section17cea5af3ed72110e0cb70040acbc387(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<div title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <span class="badge badge-warning text-dark ml-1">{{rating_val}}/5 ★</span></div>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<div title="';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 sao"><span class="text-warning font-weight-bold">';
                $value = $this->resolveValue($context->find('stars_emoji'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span> <span class="badge badge-warning text-dark ml-1">';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 ★</span></div>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2091fe7451d4f46b7dba8d5ade9a79a1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<tr><td>{{id}}</td><td><pre class="mb-0">{{input_normalized}}</pre></td><td>{{category}}</td><td><span class="{{status_badge_class}}">{{status_label}}</span>{{#can_explain}}<form method="post" class="mt-2"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="explain"><input type="hidden" name="contribution_id" value="{{id}}"><input class="form-control form-control-sm mb-1" name="explanation" required><button class="btn btn-sm btn-primary">{{#str}} resubmitexplanation, local_testcase_exchange {{/str}}</button></form>{{/can_explain}}</td><td>{{#has_rating}}<div title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <span class="badge badge-warning text-dark ml-1">{{rating_val}}/5 ★</span></div>{{/has_rating}}{{^has_rating}}<span class="text-muted small">—</span>{{/has_rating}}{{#has_teacher_comment}}<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 {{teacher_comment}}</div>{{/has_teacher_comment}}</td><td>{{submitted_at}}</td></tr>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<tr><td>';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('input_normalized'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td>';
                $value = $this->resolveValue($context->find('category'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td><td><span class="';
                $value = $this->resolveValue($context->find('status_badge_class'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $this->resolveValue($context->find('status_label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>';
                $value = $context->find('can_explain');
                $buffer .= $this->section8caef4868704df31045d6a8ea66a37fc($context, $indent, $value);
                $buffer .= '</td><td>';
                $value = $context->find('has_rating');
                $buffer .= $this->section17cea5af3ed72110e0cb70040acbc387($context, $indent, $value);
                $value = $context->find('has_rating');
                if (empty($value)) {
                    
                    $buffer .= '<span class="text-muted small">—</span>';
                }
                $value = $context->find('has_teacher_comment');
                $buffer .= $this->sectionA945db33b7a7a3a2b3d9612f06c964bd($context, $indent, $value);
                $buffer .= '</td><td>';
                $value = $this->resolveValue($context->find('submitted_at'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td></tr>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4ea99b2dd3e1e25afe390c32a57d09bb(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' action ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' action ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section44bd0bf65d2bd35d6e8110a9e70e69fb(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' norewardsfound, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' norewardsfound, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section610f1179589cec845cd7f83132cd7edc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' claimed, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' claimed, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC9c768aba56d7a839bb8c5d86a0b6a5a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                            <span class="badge badge-success">✓ {{#str}} claimed, local_testcase_exchange {{/str}}</span>
                            <div class="small text-muted">{{claimed_at}}</div>
                            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                            <span class="badge badge-success">✓ ';
                $value = $context->find('str');
                $buffer .= $this->section610f1179589cec845cd7f83132cd7edc($context, $indent, $value);
                $buffer .= '</span>
';
                $buffer .= $indent . '                            <div class="small text-muted">';
                $value = $this->resolveValue($context->find('claimed_at'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC729ee50cf915fd99c01311c8bc97acf(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' unclaimed, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' unclaimed, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD6cfa077e0361a4903222ecb12e1f4bc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' claim_reward_btn, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' claim_reward_btn, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB6afaa89363f7c5dd9068260028336ce(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' ready_for_check, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' ready_for_check, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD45beb98d23a326f69a02c5943ebdc65(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                            <span class="text-success small font-weight-bold">✓ {{#str}} ready_for_check, local_testcase_exchange {{/str}}</span>
                            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                            <span class="text-success small font-weight-bold">✓ ';
                $value = $context->find('str');
                $buffer .= $this->sectionB6afaa89363f7c5dd9068260028336ce($context, $indent, $value);
                $buffer .= '</span>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF537780184fa158d8d9598fc6ec03ffa(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <tr class="{{^is_claimed_bool}}table-warning font-weight-bold{{/is_claimed_bool}}">
                        <td>#{{id}}</td>
                        <td><pre class="mb-0">{{display_input}}</pre></td>
                        <td><pre class="mb-0">{{display_oracle}}</pre></td>
                        <td><span class="badge badge-secondary">{{category}}</span></td>
                        <td>
                            {{#is_claimed_bool}}
                            <span class="badge badge-success">✓ {{#str}} claimed, local_testcase_exchange {{/str}}</span>
                            <div class="small text-muted">{{claimed_at}}</div>
                            {{/is_claimed_bool}}
                            {{^is_claimed_bool}}
                            <span class="badge badge-warning text-dark">🔒 {{#str}} unclaimed, local_testcase_exchange {{/str}}</span>
                            {{/is_claimed_bool}}
                        </td>
                        <td>
                            {{^is_claimed_bool}}
                            <form method="post" class="d-inline">
                                <input type="hidden" name="sesskey" value="{{sesskey}}">
                                <input type="hidden" name="action" value="claim_reward">
                                <input type="hidden" name="reward_id" value="{{id}}">
                                <button type="submit" class="btn btn-sm btn-primary font-weight-bold shadow-sm">
                                    🎁 {{#str}} claim_reward_btn, local_testcase_exchange {{/str}}
                                </button>
                            </form>
                            {{/is_claimed_bool}}
                            {{#is_claimed_bool}}
                            <span class="text-success small font-weight-bold">✓ {{#str}} ready_for_check, local_testcase_exchange {{/str}}</span>
                            {{/is_claimed_bool}}
                        </td>
                    </tr>
                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <tr class="';
                $value = $context->find('is_claimed_bool');
                if (empty($value)) {
                    
                    $buffer .= 'table-warning font-weight-bold';
                }
                $buffer .= '">
';
                $buffer .= $indent . '                        <td>#';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td>
';
                $buffer .= $indent . '                        <td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('display_input'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td>
';
                $buffer .= $indent . '                        <td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('display_oracle'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td>
';
                $buffer .= $indent . '                        <td><span class="badge badge-secondary">';
                $value = $this->resolveValue($context->find('category'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span></td>
';
                $buffer .= $indent . '                        <td>
';
                $value = $context->find('is_claimed_bool');
                $buffer .= $this->sectionC9c768aba56d7a839bb8c5d86a0b6a5a($context, $indent, $value);
                $value = $context->find('is_claimed_bool');
                if (empty($value)) {
                    
                    $buffer .= $indent . '                            <span class="badge badge-warning text-dark">🔒 ';
                    $value = $context->find('str');
                    $buffer .= $this->sectionC729ee50cf915fd99c01311c8bc97acf($context, $indent, $value);
                    $buffer .= '</span>
';
                }
                $buffer .= $indent . '                        </td>
';
                $buffer .= $indent . '                        <td>
';
                $value = $context->find('is_claimed_bool');
                if (empty($value)) {
                    
                    $buffer .= $indent . '                            <form method="post" class="d-inline">
';
                    $buffer .= $indent . '                                <input type="hidden" name="sesskey" value="';
                    $value = $this->resolveValue($context->find('sesskey'), $context);
                    $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                    $buffer .= '">
';
                    $buffer .= $indent . '                                <input type="hidden" name="action" value="claim_reward">
';
                    $buffer .= $indent . '                                <input type="hidden" name="reward_id" value="';
                    $value = $this->resolveValue($context->find('id'), $context);
                    $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                    $buffer .= '">
';
                    $buffer .= $indent . '                                <button type="submit" class="btn btn-sm btn-primary font-weight-bold shadow-sm">
';
                    $buffer .= $indent . '                                    🎁 ';
                    $value = $context->find('str');
                    $buffer .= $this->sectionD6cfa077e0361a4903222ecb12e1f4bc($context, $indent, $value);
                    $buffer .= '
';
                    $buffer .= $indent . '                                </button>
';
                    $buffer .= $indent . '                            </form>
';
                }
                $value = $context->find('is_claimed_bool');
                $buffer .= $this->sectionD45beb98d23a326f69a02c5943ebdc65($context, $indent, $value);
                $buffer .= $indent . '                        </td>
';
                $buffer .= $indent . '                    </tr>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section59e5010696165b305ea4cb6f45a68873(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' course_leaderboard_title, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' course_leaderboard_title, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBc2396f8cbc8c92133626f11ab08ef77(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' leaderboard_rules_hint, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' leaderboard_rules_hint, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section63ef24c100f49daa6c2f991766a40503(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rank, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rank, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDab60f792eac9826ddee3789a8e33540(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' total_stars, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' total_stars, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDc17d461b9e731821f5ded54a6569bd5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' approved_testcases, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' approved_testcases, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section063999259675464f559f4e47ee3f3866(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' first_contribution, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' first_contribution, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE77a027d7fe9a59393f8200c015d342f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'table-primary font-weight-bold';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'table-primary font-weight-bold';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section10d78ef50c0cf7819384a919292a88cc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' you, core ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' you, core ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section89d6f5b51e94492259d4f94889c0fb56(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<span class="badge badge-info ml-1">({{#str}} you, core {{/str}})</span>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<span class="badge badge-info ml-1">(';
                $value = $context->find('str');
                $buffer .= $this->section10d78ef50c0cf7819384a919292a88cc($context, $indent, $value);
                $buffer .= ')</span>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB5dcb3139e02d168e8072b5bf6c46613(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <tr class="{{#is_current_user}}table-primary font-weight-bold{{/is_current_user}}">
                        <td><span class="badge {{badge_class}} p-2 font-weight-bold">{{medal}}</span></td>
                        <td>
                            <div><strong>{{fullname}}</strong> {{#is_current_user}}<span class="badge badge-info ml-1">({{#str}} you, core {{/str}})</span>{{/is_current_user}}</div>
                            <small class="text-muted">{{username}}</small>
                        </td>
                        <td>
                            <span class="badge badge-warning text-dark font-weight-bold px-2 py-1" style="font-size: 0.95rem;">
                                {{total_stars}} ⭐
                            </span>
                        </td>
                        <td><span class="badge badge-secondary p-1">{{approved_count}} testcases</span></td>
                        <td><small class="text-muted">{{first_submitted_at}}</small></td>
                    </tr>
                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <tr class="';
                $value = $context->find('is_current_user');
                $buffer .= $this->sectionE77a027d7fe9a59393f8200c015d342f($context, $indent, $value);
                $buffer .= '">
';
                $buffer .= $indent . '                        <td><span class="badge ';
                $value = $this->resolveValue($context->find('badge_class'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' p-2 font-weight-bold">';
                $value = $this->resolveValue($context->find('medal'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span></td>
';
                $buffer .= $indent . '                        <td>
';
                $buffer .= $indent . '                            <div><strong>';
                $value = $this->resolveValue($context->find('fullname'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong> ';
                $value = $context->find('is_current_user');
                $buffer .= $this->section89d6f5b51e94492259d4f94889c0fb56($context, $indent, $value);
                $buffer .= '</div>
';
                $buffer .= $indent . '                            <small class="text-muted">';
                $value = $this->resolveValue($context->find('username'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small>
';
                $buffer .= $indent . '                        </td>
';
                $buffer .= $indent . '                        <td>
';
                $buffer .= $indent . '                            <span class="badge badge-warning text-dark font-weight-bold px-2 py-1" style="font-size: 0.95rem;">
';
                $buffer .= $indent . '                                ';
                $value = $this->resolveValue($context->find('total_stars'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' ⭐
';
                $buffer .= $indent . '                            </span>
';
                $buffer .= $indent . '                        </td>
';
                $buffer .= $indent . '                        <td><span class="badge badge-secondary p-1">';
                $value = $this->resolveValue($context->find('approved_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' testcases</span></td>
';
                $buffer .= $indent . '                        <td><small class="text-muted">';
                $value = $this->resolveValue($context->find('first_submitted_at'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td>
';
                $buffer .= $indent . '                    </tr>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

}
