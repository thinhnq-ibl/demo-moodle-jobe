<?php

class __Mustache_cc05b9b7963ca34ea44f1a003c539408 extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        $value = $context->find('show_course_switcher');
        $buffer .= $this->section478850984c6a24d97e12fe3be2cf5eba($context, $indent, $value);
        $buffer .= $indent . '
';
        $buffer .= $indent . '<div class="d-flex justify-content-between align-items-center mb-3">
';
        $buffer .= $indent . '    <div>
';
        $buffer .= $indent . '        <a class="btn btn-secondary mr-2" href="';
        $value = $this->resolveValue($context->find('dashboard_url'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= '">
';
        $buffer .= $indent . '            &larr; ';
        $value = $context->find('str');
        $buffer .= $this->sectionEdd56f6056b50138d927605cc9f223fa($context, $indent, $value);
        $buffer .= '
';
        $buffer .= $indent . '        </a>
';
        $value = $context->find('has_return_url');
        $buffer .= $this->section7d89c95d044cea1071e98aa55c535991($context, $indent, $value);
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '    <span class="text-muted">';
        $value = $context->find('str');
        $buffer .= $this->sectionF3bc1d8fcc0633c07cd9d132b0c0886c($context, $indent, $value);
        $buffer .= ': <strong>';
        $value = $this->resolveValue($context->find('total_count'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= '</strong> testcase</span>
';
        $buffer .= $indent . '</div>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '<div class="card mb-4 shadow-sm">
';
        $buffer .= $indent . '    <div class="card-body p-3">
';
        $buffer .= $indent . '        <form method="get" class="form-inline d-flex flex-wrap align-items-center">
';
        $buffer .= $indent . '            <input type="hidden" name="course" value="';
        $value = $this->resolveValue($context->find('course_id'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= '">
';
        $buffer .= $indent . '            <input type="hidden" name="status" value="';
        $value = $this->resolveValue($context->find('current_status'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= '">
';
        $value = $context->find('has_question_filter');
        $buffer .= $this->sectionD751f737249e7c018f4929cd73615aa5($context, $indent, $value);
        $buffer .= $indent . '        </form>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</div>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '<ul class="nav nav-tabs mb-3">
';
        $value = $context->find('status_tabs');
        $buffer .= $this->section5699528cde9220a94a0849f7f332cb94($context, $indent, $value);
        $buffer .= $indent . '</ul>
';
        $buffer .= $indent . '
';
        $buffer .= $indent . '<div class="table-responsive bg-white rounded shadow-sm border p-2">
';
        $buffer .= $indent . '    <table class="table table-hover align-middle mb-0">
';
        $buffer .= $indent . '        <thead class="thead-light">
';
        $buffer .= $indent . '            <tr>
';
        $buffer .= $indent . '                <th style="width: 50px;">ID</th>
';
        $buffer .= $indent . '                <th style="width: 180px;">';
        $value = $context->find('str');
        $buffer .= $this->section058949d940063367d3d5381df0d810c8($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                <th>';
        $value = $context->find('str');
        $buffer .= $this->sectionFbf3bb14fdfb73409b8836554df1d06d($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                <th>';
        $value = $context->find('str');
        $buffer .= $this->sectionB944b350b43a30cdf4afb7551a33da5d($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                <th>';
        $value = $context->find('str');
        $buffer .= $this->section9b9054987cd3b32d511d5845018cc8b0($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                <th>';
        $value = $context->find('str');
        $buffer .= $this->sectionC61de41a69f5133af082b83712eb88b3($context, $indent, $value);
        $buffer .= ' / ';
        $value = $context->find('str');
        $buffer .= $this->sectionF6d8114da9c7bff859d802d41c6c3256($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                <th style="width: 120px;">';
        $value = $context->find('str');
        $buffer .= $this->section99380e31c66dc018fdbb40851d8c070c($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '                <th style="min-width: 200px;">';
        $value = $context->find('str');
        $buffer .= $this->section3914857c5a3eb64f39d00fa879fd05ed($context, $indent, $value);
        $buffer .= '</th>
';
        $buffer .= $indent . '            </tr>
';
        $buffer .= $indent . '        </thead>
';
        $buffer .= $indent . '        <tbody>
';
        $value = $context->find('has_items');
        if (empty($value)) {
            
            $buffer .= $indent . '            <tr>
';
            $buffer .= $indent . '                <td colspan="8" class="text-center py-4 text-muted">
';
            $buffer .= $indent . '                    ';
            $value = $context->find('str');
            $buffer .= $this->sectionDb7d5e03b02fdbe6f383a142674d4357($context, $indent, $value);
            $buffer .= '
';
            $buffer .= $indent . '                </td>
';
            $buffer .= $indent . '            </tr>
';
        }
        $value = $context->find('items');
        $buffer .= $this->section311bc36c2a3b507d850bf019aa9402a4($context, $indent, $value);
        $buffer .= $indent . '        </tbody>
';
        $buffer .= $indent . '    </table>
';
        $buffer .= $indent . '</div>
';

        return $buffer;
    }

    private function section935207dbb135155d9033286c71d96189(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' course ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' course ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4b647e8c317e0c7bd8dc69b2d92349ab(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' allcourses, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' allcourses, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section85cf18307942aa0a878ed360612632ea(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' switchcourse, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' switchcourse, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9e2875c627d2dbad7c957250bbb623f7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'selected';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'selected';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC56bd66fc097d0a33857c935199760f4(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                <option value="{{switch_url}}" {{#is_current}}selected{{/is_current}}>{{shortname}} - {{fullname}}</option>
                ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                <option value="';
                $value = $this->resolveValue($context->find('switch_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" ';
                $value = $context->find('is_current');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $this->resolveValue($context->find('shortname'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' - ';
                $value = $this->resolveValue($context->find('fullname'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section478850984c6a24d97e12fe3be2cf5eba(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="card bg-light mb-3 p-2">
    <div class="d-flex flex-wrap justify-content-between align-items-center">
        <div>
            <span class="text-muted mr-1">📚 {{#str}} course {{/str}}:</span>
            <strong>{{current_course_name}}</strong>
            <a href="{{course_hub_url}}" class="badge badge-secondary ml-2">&larr; {{#str}} allcourses, local_testcase_exchange {{/str}}</a>
        </div>
        <div class="d-flex align-items-center mt-1 mt-md-0">
            <label for="switchReviewCourseSelect" class="small text-muted mb-0 mr-2">{{#str}} switchcourse, local_testcase_exchange {{/str}}:</label>
            <select id="switchReviewCourseSelect" class="custom-select custom-select-sm" onchange="if (this.value) window.location.href=this.value;">
                {{#available_courses}}
                <option value="{{switch_url}}" {{#is_current}}selected{{/is_current}}>{{shortname}} - {{fullname}}</option>
                {{/available_courses}}
            </select>
        </div>
    </div>
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="card bg-light mb-3 p-2">
';
                $buffer .= $indent . '    <div class="d-flex flex-wrap justify-content-between align-items-center">
';
                $buffer .= $indent . '        <div>
';
                $buffer .= $indent . '            <span class="text-muted mr-1">📚 ';
                $value = $context->find('str');
                $buffer .= $this->section935207dbb135155d9033286c71d96189($context, $indent, $value);
                $buffer .= ':</span>
';
                $buffer .= $indent . '            <strong>';
                $value = $this->resolveValue($context->find('current_course_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong>
';
                $buffer .= $indent . '            <a href="';
                $value = $this->resolveValue($context->find('course_hub_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" class="badge badge-secondary ml-2">&larr; ';
                $value = $context->find('str');
                $buffer .= $this->section4b647e8c317e0c7bd8dc69b2d92349ab($context, $indent, $value);
                $buffer .= '</a>
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '        <div class="d-flex align-items-center mt-1 mt-md-0">
';
                $buffer .= $indent . '            <label for="switchReviewCourseSelect" class="small text-muted mb-0 mr-2">';
                $value = $context->find('str');
                $buffer .= $this->section85cf18307942aa0a878ed360612632ea($context, $indent, $value);
                $buffer .= ':</label>
';
                $buffer .= $indent . '            <select id="switchReviewCourseSelect" class="custom-select custom-select-sm" onchange="if (this.value) window.location.href=this.value;">
';
                $value = $context->find('available_courses');
                $buffer .= $this->sectionC56bd66fc097d0a33857c935199760f4($context, $indent, $value);
                $buffer .= $indent . '            </select>
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '    </div>
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionEdd56f6056b50138d927605cc9f223fa(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' backtodashboard, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' backtodashboard, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7b108c120350250de45d032e1ccc0e06(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' backtocurrentquiz, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' backtocurrentquiz, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section70c2ecfed881d1707308d6e1e1b28afd(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ': <strong>{{return_quiz_name}}</strong>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ': <strong>';
                $value = $this->resolveValue($context->find('return_quiz_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7d89c95d044cea1071e98aa55c535991(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
        <a class="btn btn-outline-secondary font-weight-bold" href="{{return_url}}">
            &larr; {{#str}} backtocurrentquiz, local_testcase_exchange {{/str}}{{#return_quiz_name}}: <strong>{{return_quiz_name}}</strong>{{/return_quiz_name}}
        </a>
        ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        <a class="btn btn-outline-secondary font-weight-bold" href="';
                $value = $this->resolveValue($context->find('return_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '            &larr; ';
                $value = $context->find('str');
                $buffer .= $this->section7b108c120350250de45d032e1ccc0e06($context, $indent, $value);
                $value = $context->find('return_quiz_name');
                $buffer .= $this->section70c2ecfed881d1707308d6e1e1b28afd($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '        </a>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF3bc1d8fcc0633c07cd9d132b0c0886c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' total, core ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' total, core ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4c0aca8e8cb5f95999175abc1021199c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' filterbyquestion, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' filterbyquestion, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section6d4cd8d98fa5934ffa14d8de912070e8(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                <option value="{{value}}" {{#selected}}selected{{/selected}}>{{label}}</option>
                ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                <option value="';
                $value = $this->resolveValue($context->find('value'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" ';
                $value = $context->find('selected');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $this->resolveValue($context->find('label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9dbf37a0f544ff636ac78cdadec0a0c6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' search, core ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' search, core ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD751f737249e7c018f4929cd73615aa5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
            <label for="filter_question" class="mr-2 mb-2"><strong>{{#str}} filterbyquestion, local_testcase_exchange {{/str}}:</strong></label>
            <select class="form-control mr-2 mb-2" id="filter_question" name="question" onchange="this.form.submit()">
                {{#question_options}}
                <option value="{{value}}" {{#selected}}selected{{/selected}}>{{label}}</option>
                {{/question_options}}
            </select>
            <button class="btn btn-outline-secondary mb-2" type="submit">{{#str}} search, core {{/str}}</button>
            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '            <label for="filter_question" class="mr-2 mb-2"><strong>';
                $value = $context->find('str');
                $buffer .= $this->section4c0aca8e8cb5f95999175abc1021199c($context, $indent, $value);
                $buffer .= ':</strong></label>
';
                $buffer .= $indent . '            <select class="form-control mr-2 mb-2" id="filter_question" name="question" onchange="this.form.submit()">
';
                $value = $context->find('question_options');
                $buffer .= $this->section6d4cd8d98fa5934ffa14d8de912070e8($context, $indent, $value);
                $buffer .= $indent . '            </select>
';
                $buffer .= $indent . '            <button class="btn btn-outline-secondary mb-2" type="submit">';
                $value = $context->find('str');
                $buffer .= $this->section9dbf37a0f544ff636ac78cdadec0a0c6($context, $indent, $value);
                $buffer .= '</button>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section807f30e0679d80e18434668ba332b78c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'active font-weight-bold';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'active font-weight-bold';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF6297b3a98239747248515df92005e9b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'badge-primary';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'badge-primary';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section5699528cde9220a94a0849f7f332cb94(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <li class="nav-item">
        <a class="nav-link {{#is_active}}active font-weight-bold{{/is_active}}" href="{{url}}">
            {{label}} <span class="badge {{#is_active}}badge-primary{{/is_active}}{{^is_active}}badge-light{{/is_active}}">{{count}}</span>
        </a>
    </li>
    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <li class="nav-item">
';
                $buffer .= $indent . '        <a class="nav-link ';
                $value = $context->find('is_active');
                $buffer .= $this->section807f30e0679d80e18434668ba332b78c($context, $indent, $value);
                $buffer .= '" href="';
                $value = $this->resolveValue($context->find('url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '            ';
                $value = $this->resolveValue($context->find('label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' <span class="badge ';
                $value = $context->find('is_active');
                $buffer .= $this->sectionF6297b3a98239747248515df92005e9b($context, $indent, $value);
                $value = $context->find('is_active');
                if (empty($value)) {
                    
                    $buffer .= 'badge-light';
                }
                $buffer .= '">';
                $value = $this->resolveValue($context->find('count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>
';
                $buffer .= $indent . '        </a>
';
                $buffer .= $indent . '    </li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section058949d940063367d3d5381df0d810c8(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' student, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' student, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFbf3bb14fdfb73409b8836554df1d06d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' quizquestion, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' quizquestion, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB944b350b43a30cdf4afb7551a33da5d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' testinput, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' testinput, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9b9054987cd3b32d511d5845018cc8b0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' oracleoutput, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' oracleoutput, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC61de41a69f5133af082b83712eb88b3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' purpose, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' purpose, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF6d8114da9c7bff859d802d41c6c3256(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' category, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' category, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section99380e31c66dc018fdbb40851d8c070c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' status ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' status ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section3914857c5a3eb64f39d00fa879fd05ed(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' actions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' actions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDb7d5e03b02fdbe6f383a142674d4357(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' nocontributionsfound, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' nocontributionsfound, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2fb6980d381e9caa2b31d36c35288cd1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<small class="text-muted">{{purpose}}</small>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<small class="text-muted">';
                $value = $this->resolveValue($context->find('purpose'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section49c0a63f2b778fb5d5a63069d9f134a6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <div class="mt-1" title="{{rating_val}}/5 sao">
                        <span class="text-warning font-weight-bold" style="letter-spacing: 1px;">{{stars_emoji}}</span>
                        <span class="badge badge-warning text-dark ml-1">{{rating_val}}/5 ★</span>
                    </div>
                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <div class="mt-1" title="';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 sao">
';
                $buffer .= $indent . '                        <span class="text-warning font-weight-bold" style="letter-spacing: 1px;">';
                $value = $this->resolveValue($context->find('stars_emoji'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>
';
                $buffer .= $indent . '                        <span class="badge badge-warning text-dark ml-1">';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 ★</span>
';
                $buffer .= $indent . '                    </div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA8767f827a093e8b601661f5a13c2a03(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <div class="small bg-light p-1 rounded border mt-1 text-dark" style="max-width: 220px; word-break: break-word;">
                        <span class="text-primary font-weight-bold">💬</span> {{teacher_comment}}
                    </div>
                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <div class="small bg-light p-1 rounded border mt-1 text-dark" style="max-width: 220px; word-break: break-word;">
';
                $buffer .= $indent . '                        <span class="text-primary font-weight-bold">💬</span> ';
                $value = $this->resolveValue($context->find('teacher_comment'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '
';
                $buffer .= $indent . '                    </div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section237a5b12de4e3e9871419c02873d73ea(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' starrating, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' starrating, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA429f516ca76eebe9a5170b5546f2cf5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' optional, core ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' optional, core ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2c2c500e2da64a2ad7ad926deacc86ef(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' norating, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' norating, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section80717993978cf062d0bd94d0df600647(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' stars, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' stars, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section726139b90ec221461157129539dd3e81(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rating_5_desc, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rating_5_desc, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFcfc98e02b0ac66581c64626332379ae(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rating_4_desc, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rating_4_desc, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF827ee660bfcc1aa5dcf1e227a97fcf3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rating_3_desc, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rating_3_desc, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionAb00e2fc3dfa4a3aa271d0efade7c370(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rating_2_desc, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rating_2_desc, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9dbab0ae2a54faf3a0080bdbeb6caf08(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rating_1_desc, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rating_1_desc, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section32de284951ecb713f5d0fa2dbab04b51(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' reviewnote, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' reviewnote, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE5e23567ad08a2707675347646352974(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' teachercomment, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' teachercomment, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF87d70a05019f27a0df8acd6b11d82d3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' approvecontribution, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' approvecontribution, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section08d74a66edf1ae80974f3f48d58c6302(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' needsexplanation, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' needsexplanation, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9a344b4c759923d2326c738f75dfefad(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rejectcontribution, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rejectcontribution, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9077c74175b405c4a738cfb4363a8211(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <form method="post" class="border p-2 rounded bg-light">
                        <input type="hidden" name="sesskey" value="{{sesskey}}">
                        <input type="hidden" name="contribution_id" value="{{id}}">
                        <div class="form-group mb-2">
                            <label class="small font-weight-bold mb-1 d-block text-muted">{{#str}} starrating, local_testcase_exchange {{/str}} ({{#str}} optional, core {{/str}}):</label>
                            <select class="form-control form-control-sm" name="rating">
                                <option value="0">-- {{#str}} norating, local_testcase_exchange {{/str}} --</option>
                                <option value="5">⭐⭐⭐⭐⭐ 5 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_5_desc, local_testcase_exchange {{/str}}</option>
                                <option value="4">⭐⭐⭐⭐ 4 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_4_desc, local_testcase_exchange {{/str}}</option>
                                <option value="3">⭐⭐⭐ 3 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_3_desc, local_testcase_exchange {{/str}}</option>
                                <option value="2">⭐⭐ 2 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_2_desc, local_testcase_exchange {{/str}}</option>
                                <option value="1">⭐ 1 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_1_desc, local_testcase_exchange {{/str}}</option>
                            </select>
                        </div>
                        <div class="form-group mb-2">
                            <input class="form-control form-control-sm" name="review_note" placeholder="{{#str}} reviewnote, local_testcase_exchange {{/str}} / {{#str}} teachercomment, local_testcase_exchange {{/str}}...">
                        </div>
                        <div class="btn-group btn-group-sm w-100" role="group">
                            <button class="btn btn-success" name="decision" value="approved" title="{{#str}} approvecontribution, local_testcase_exchange {{/str}}">
                                &check; {{#str}} approvecontribution, local_testcase_exchange {{/str}}
                            </button>
                            <button class="btn btn-warning" name="decision" value="needs_explanation" title="{{#str}} needsexplanation, local_testcase_exchange {{/str}}">
                                ? {{#str}} needsexplanation, local_testcase_exchange {{/str}}
                            </button>
                            <button class="btn btn-danger" name="decision" value="rejected" title="{{#str}} rejectcontribution, local_testcase_exchange {{/str}}">
                                &times; {{#str}} rejectcontribution, local_testcase_exchange {{/str}}
                            </button>
                        </div>
                    </form>
                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <form method="post" class="border p-2 rounded bg-light">
';
                $buffer .= $indent . '                        <input type="hidden" name="sesskey" value="';
                $value = $this->resolveValue($context->find('sesskey'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '                        <input type="hidden" name="contribution_id" value="';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '                        <div class="form-group mb-2">
';
                $buffer .= $indent . '                            <label class="small font-weight-bold mb-1 d-block text-muted">';
                $value = $context->find('str');
                $buffer .= $this->section237a5b12de4e3e9871419c02873d73ea($context, $indent, $value);
                $buffer .= ' (';
                $value = $context->find('str');
                $buffer .= $this->sectionA429f516ca76eebe9a5170b5546f2cf5($context, $indent, $value);
                $buffer .= '):</label>
';
                $buffer .= $indent . '                            <select class="form-control form-control-sm" name="rating">
';
                $buffer .= $indent . '                                <option value="0">-- ';
                $value = $context->find('str');
                $buffer .= $this->section2c2c500e2da64a2ad7ad926deacc86ef($context, $indent, $value);
                $buffer .= ' --</option>
';
                $buffer .= $indent . '                                <option value="5">⭐⭐⭐⭐⭐ 5 ';
                $value = $context->find('str');
                $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                $buffer .= ' - ';
                $value = $context->find('str');
                $buffer .= $this->section726139b90ec221461157129539dd3e81($context, $indent, $value);
                $buffer .= '</option>
';
                $buffer .= $indent . '                                <option value="4">⭐⭐⭐⭐ 4 ';
                $value = $context->find('str');
                $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                $buffer .= ' - ';
                $value = $context->find('str');
                $buffer .= $this->sectionFcfc98e02b0ac66581c64626332379ae($context, $indent, $value);
                $buffer .= '</option>
';
                $buffer .= $indent . '                                <option value="3">⭐⭐⭐ 3 ';
                $value = $context->find('str');
                $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                $buffer .= ' - ';
                $value = $context->find('str');
                $buffer .= $this->sectionF827ee660bfcc1aa5dcf1e227a97fcf3($context, $indent, $value);
                $buffer .= '</option>
';
                $buffer .= $indent . '                                <option value="2">⭐⭐ 2 ';
                $value = $context->find('str');
                $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                $buffer .= ' - ';
                $value = $context->find('str');
                $buffer .= $this->sectionAb00e2fc3dfa4a3aa271d0efade7c370($context, $indent, $value);
                $buffer .= '</option>
';
                $buffer .= $indent . '                                <option value="1">⭐ 1 ';
                $value = $context->find('str');
                $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                $buffer .= ' - ';
                $value = $context->find('str');
                $buffer .= $this->section9dbab0ae2a54faf3a0080bdbeb6caf08($context, $indent, $value);
                $buffer .= '</option>
';
                $buffer .= $indent . '                            </select>
';
                $buffer .= $indent . '                        </div>
';
                $buffer .= $indent . '                        <div class="form-group mb-2">
';
                $buffer .= $indent . '                            <input class="form-control form-control-sm" name="review_note" placeholder="';
                $value = $context->find('str');
                $buffer .= $this->section32de284951ecb713f5d0fa2dbab04b51($context, $indent, $value);
                $buffer .= ' / ';
                $value = $context->find('str');
                $buffer .= $this->sectionE5e23567ad08a2707675347646352974($context, $indent, $value);
                $buffer .= '...">
';
                $buffer .= $indent . '                        </div>
';
                $buffer .= $indent . '                        <div class="btn-group btn-group-sm w-100" role="group">
';
                $buffer .= $indent . '                            <button class="btn btn-success" name="decision" value="approved" title="';
                $value = $context->find('str');
                $buffer .= $this->sectionF87d70a05019f27a0df8acd6b11d82d3($context, $indent, $value);
                $buffer .= '">
';
                $buffer .= $indent . '                                &check; ';
                $value = $context->find('str');
                $buffer .= $this->sectionF87d70a05019f27a0df8acd6b11d82d3($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '                            </button>
';
                $buffer .= $indent . '                            <button class="btn btn-warning" name="decision" value="needs_explanation" title="';
                $value = $context->find('str');
                $buffer .= $this->section08d74a66edf1ae80974f3f48d58c6302($context, $indent, $value);
                $buffer .= '">
';
                $buffer .= $indent . '                                ? ';
                $value = $context->find('str');
                $buffer .= $this->section08d74a66edf1ae80974f3f48d58c6302($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '                            </button>
';
                $buffer .= $indent . '                            <button class="btn btn-danger" name="decision" value="rejected" title="';
                $value = $context->find('str');
                $buffer .= $this->section9a344b4c759923d2326c738f75dfefad($context, $indent, $value);
                $buffer .= '">
';
                $buffer .= $indent . '                                &times; ';
                $value = $context->find('str');
                $buffer .= $this->section9a344b4c759923d2326c738f75dfefad($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '                            </button>
';
                $buffer .= $indent . '                        </div>
';
                $buffer .= $indent . '                    </form>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section201d7e785162c4fd6ef89c824f3e172f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                                    <button class="btn btn-sm btn-outline-danger" type="submit" name="decision" value="rejected">
                                        {{#str}} rejectcontribution, local_testcase_exchange {{/str}}
                                    </button>
                                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                                    <button class="btn btn-sm btn-outline-danger" type="submit" name="decision" value="rejected">
';
                $buffer .= $indent . '                                        ';
                $value = $context->find('str');
                $buffer .= $this->section9a344b4c759923d2326c738f75dfefad($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '                                    </button>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF56ae6f64b9baf63bd200fbd4279e646(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                                    <button class="btn btn-sm btn-outline-success" type="submit" name="decision" value="approved">
                                        {{#str}} approvecontribution, local_testcase_exchange {{/str}}
                                    </button>
                                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                                    <button class="btn btn-sm btn-outline-success" type="submit" name="decision" value="approved">
';
                $buffer .= $indent . '                                        ';
                $value = $context->find('str');
                $buffer .= $this->sectionF87d70a05019f27a0df8acd6b11d82d3($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '                                    </button>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1da774bd41df509cb3d076748335333e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                                    <span class="text-muted small">Duplicate of #{{duplicate_of}}</span>
                                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                                    <span class="text-muted small">Duplicate of #';
                $value = $this->resolveValue($context->find('duplicate_of'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section311bc36c2a3b507d850bf019aa9402a4(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
            <tr>
                <td><strong>#{{id}}</strong></td>
                <td>
                    <div class="font-weight-bold">{{student_name}}</div>
                    <small class="text-muted">{{student_username}}</small>
                </td>
                <td>
                    <div class="font-weight-bold">{{quiz_name}}</div>
                    <small class="text-muted">{{question_name}}</small>
                </td>
                <td>
                    <pre class="bg-light p-2 rounded mb-0 text-wrap font-monospace" style="max-height: 120px; overflow-y: auto;">{{input_normalized}}</pre>
                </td>
                <td>
                    <pre class="bg-light p-2 rounded mb-0 text-wrap font-monospace" style="max-height: 120px; overflow-y: auto;">{{oracle_output}}</pre>
                </td>
                <td>
                    <div><span class="badge badge-info">{{category}}</span></div>
                    {{#purpose}}<small class="text-muted">{{purpose}}</small>{{/purpose}}
                </td>
                <td>
                    <span class="{{status_badge_class}}">{{status_label}}</span>
                    {{#has_rating}}
                    <div class="mt-1" title="{{rating_val}}/5 sao">
                        <span class="text-warning font-weight-bold" style="letter-spacing: 1px;">{{stars_emoji}}</span>
                        <span class="badge badge-warning text-dark ml-1">{{rating_val}}/5 ★</span>
                    </div>
                    {{/has_rating}}
                    {{#has_teacher_comment}}
                    <div class="small bg-light p-1 rounded border mt-1 text-dark" style="max-width: 220px; word-break: break-word;">
                        <span class="text-primary font-weight-bold">💬</span> {{teacher_comment}}
                    </div>
                    {{/has_teacher_comment}}
                    <div class="small text-muted mt-1">{{submitted_at}}</div>
                </td>
                <td>
                    {{#is_pending}}
                    <form method="post" class="border p-2 rounded bg-light">
                        <input type="hidden" name="sesskey" value="{{sesskey}}">
                        <input type="hidden" name="contribution_id" value="{{id}}">
                        <div class="form-group mb-2">
                            <label class="small font-weight-bold mb-1 d-block text-muted">{{#str}} starrating, local_testcase_exchange {{/str}} ({{#str}} optional, core {{/str}}):</label>
                            <select class="form-control form-control-sm" name="rating">
                                <option value="0">-- {{#str}} norating, local_testcase_exchange {{/str}} --</option>
                                <option value="5">⭐⭐⭐⭐⭐ 5 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_5_desc, local_testcase_exchange {{/str}}</option>
                                <option value="4">⭐⭐⭐⭐ 4 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_4_desc, local_testcase_exchange {{/str}}</option>
                                <option value="3">⭐⭐⭐ 3 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_3_desc, local_testcase_exchange {{/str}}</option>
                                <option value="2">⭐⭐ 2 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_2_desc, local_testcase_exchange {{/str}}</option>
                                <option value="1">⭐ 1 {{#str}} stars, local_testcase_exchange {{/str}} - {{#str}} rating_1_desc, local_testcase_exchange {{/str}}</option>
                            </select>
                        </div>
                        <div class="form-group mb-2">
                            <input class="form-control form-control-sm" name="review_note" placeholder="{{#str}} reviewnote, local_testcase_exchange {{/str}} / {{#str}} teachercomment, local_testcase_exchange {{/str}}...">
                        </div>
                        <div class="btn-group btn-group-sm w-100" role="group">
                            <button class="btn btn-success" name="decision" value="approved" title="{{#str}} approvecontribution, local_testcase_exchange {{/str}}">
                                &check; {{#str}} approvecontribution, local_testcase_exchange {{/str}}
                            </button>
                            <button class="btn btn-warning" name="decision" value="needs_explanation" title="{{#str}} needsexplanation, local_testcase_exchange {{/str}}">
                                ? {{#str}} needsexplanation, local_testcase_exchange {{/str}}
                            </button>
                            <button class="btn btn-danger" name="decision" value="rejected" title="{{#str}} rejectcontribution, local_testcase_exchange {{/str}}">
                                &times; {{#str}} rejectcontribution, local_testcase_exchange {{/str}}
                            </button>
                        </div>
                    </form>
                    {{/is_pending}}
                    {{^is_pending}}
                    <div class="border p-2 rounded bg-light mb-2">
                        <form method="post" class="mb-0">
                            <input type="hidden" name="sesskey" value="{{sesskey}}">
                            <input type="hidden" name="contribution_id" value="{{id}}">
                            <div class="mb-2">
                                <select class="form-control form-control-sm" name="rating">
                                    <option value="0">-- {{#str}} starrating, local_testcase_exchange {{/str}} --</option>
                                    <option value="5" {{#is_rating_5}}selected{{/is_rating_5}}>⭐⭐⭐⭐⭐ 5 {{#str}} stars, local_testcase_exchange {{/str}}</option>
                                    <option value="4" {{#is_rating_4}}selected{{/is_rating_4}}>⭐⭐⭐⭐ 4 {{#str}} stars, local_testcase_exchange {{/str}}</option>
                                    <option value="3" {{#is_rating_3}}selected{{/is_rating_3}}>⭐⭐⭐ 3 {{#str}} stars, local_testcase_exchange {{/str}}</option>
                                    <option value="2" {{#is_rating_2}}selected{{/is_rating_2}}>⭐⭐ 2 {{#str}} stars, local_testcase_exchange {{/str}}</option>
                                    <option value="1" {{#is_rating_1}}selected{{/is_rating_1}}>⭐ 1 {{#str}} stars, local_testcase_exchange {{/str}}</option>
                                </select>
                            </div>
                            <div class="mb-2">
                                <input class="form-control form-control-sm" name="review_note" placeholder="{{#str}} teachercomment, local_testcase_exchange {{/str}}..." value="{{teacher_comment}}">
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    {{#is_approved}}
                                    <button class="btn btn-sm btn-outline-danger" type="submit" name="decision" value="rejected">
                                        {{#str}} rejectcontribution, local_testcase_exchange {{/str}}
                                    </button>
                                    {{/is_approved}}
                                    {{#is_rejected}}
                                    <button class="btn btn-sm btn-outline-success" type="submit" name="decision" value="approved">
                                        {{#str}} approvecontribution, local_testcase_exchange {{/str}}
                                    </button>
                                    {{/is_rejected}}
                                    {{#is_duplicate}}
                                    <span class="text-muted small">Duplicate of #{{duplicate_of}}</span>
                                    {{/is_duplicate}}
                                </div>
                                <button class="btn btn-sm btn-primary" type="submit" name="decision" value="rate_only">
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                    {{/is_pending}}
                </td>
            </tr>
            ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '            <tr>
';
                $buffer .= $indent . '                <td><strong>#';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></td>
';
                $buffer .= $indent . '                <td>
';
                $buffer .= $indent . '                    <div class="font-weight-bold">';
                $value = $this->resolveValue($context->find('student_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</div>
';
                $buffer .= $indent . '                    <small class="text-muted">';
                $value = $this->resolveValue($context->find('student_username'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small>
';
                $buffer .= $indent . '                </td>
';
                $buffer .= $indent . '                <td>
';
                $buffer .= $indent . '                    <div class="font-weight-bold">';
                $value = $this->resolveValue($context->find('quiz_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</div>
';
                $buffer .= $indent . '                    <small class="text-muted">';
                $value = $this->resolveValue($context->find('question_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small>
';
                $buffer .= $indent . '                </td>
';
                $buffer .= $indent . '                <td>
';
                $buffer .= $indent . '                    <pre class="bg-light p-2 rounded mb-0 text-wrap font-monospace" style="max-height: 120px; overflow-y: auto;">';
                $value = $this->resolveValue($context->find('input_normalized'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre>
';
                $buffer .= $indent . '                </td>
';
                $buffer .= $indent . '                <td>
';
                $buffer .= $indent . '                    <pre class="bg-light p-2 rounded mb-0 text-wrap font-monospace" style="max-height: 120px; overflow-y: auto;">';
                $value = $this->resolveValue($context->find('oracle_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre>
';
                $buffer .= $indent . '                </td>
';
                $buffer .= $indent . '                <td>
';
                $buffer .= $indent . '                    <div><span class="badge badge-info">';
                $value = $this->resolveValue($context->find('category'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span></div>
';
                $buffer .= $indent . '                    ';
                $value = $context->find('purpose');
                $buffer .= $this->section2fb6980d381e9caa2b31d36c35288cd1($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '                </td>
';
                $buffer .= $indent . '                <td>
';
                $buffer .= $indent . '                    <span class="';
                $value = $this->resolveValue($context->find('status_badge_class'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $this->resolveValue($context->find('status_label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>
';
                $value = $context->find('has_rating');
                $buffer .= $this->section49c0a63f2b778fb5d5a63069d9f134a6($context, $indent, $value);
                $value = $context->find('has_teacher_comment');
                $buffer .= $this->sectionA8767f827a093e8b601661f5a13c2a03($context, $indent, $value);
                $buffer .= $indent . '                    <div class="small text-muted mt-1">';
                $value = $this->resolveValue($context->find('submitted_at'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</div>
';
                $buffer .= $indent . '                </td>
';
                $buffer .= $indent . '                <td>
';
                $value = $context->find('is_pending');
                $buffer .= $this->section9077c74175b405c4a738cfb4363a8211($context, $indent, $value);
                $value = $context->find('is_pending');
                if (empty($value)) {
                    
                    $buffer .= $indent . '                    <div class="border p-2 rounded bg-light mb-2">
';
                    $buffer .= $indent . '                        <form method="post" class="mb-0">
';
                    $buffer .= $indent . '                            <input type="hidden" name="sesskey" value="';
                    $value = $this->resolveValue($context->find('sesskey'), $context);
                    $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                    $buffer .= '">
';
                    $buffer .= $indent . '                            <input type="hidden" name="contribution_id" value="';
                    $value = $this->resolveValue($context->find('id'), $context);
                    $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                    $buffer .= '">
';
                    $buffer .= $indent . '                            <div class="mb-2">
';
                    $buffer .= $indent . '                                <select class="form-control form-control-sm" name="rating">
';
                    $buffer .= $indent . '                                    <option value="0">-- ';
                    $value = $context->find('str');
                    $buffer .= $this->section237a5b12de4e3e9871419c02873d73ea($context, $indent, $value);
                    $buffer .= ' --</option>
';
                    $buffer .= $indent . '                                    <option value="5" ';
                    $value = $context->find('is_rating_5');
                    $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                    $buffer .= '>⭐⭐⭐⭐⭐ 5 ';
                    $value = $context->find('str');
                    $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                    $buffer .= '</option>
';
                    $buffer .= $indent . '                                    <option value="4" ';
                    $value = $context->find('is_rating_4');
                    $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                    $buffer .= '>⭐⭐⭐⭐ 4 ';
                    $value = $context->find('str');
                    $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                    $buffer .= '</option>
';
                    $buffer .= $indent . '                                    <option value="3" ';
                    $value = $context->find('is_rating_3');
                    $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                    $buffer .= '>⭐⭐⭐ 3 ';
                    $value = $context->find('str');
                    $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                    $buffer .= '</option>
';
                    $buffer .= $indent . '                                    <option value="2" ';
                    $value = $context->find('is_rating_2');
                    $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                    $buffer .= '>⭐⭐ 2 ';
                    $value = $context->find('str');
                    $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                    $buffer .= '</option>
';
                    $buffer .= $indent . '                                    <option value="1" ';
                    $value = $context->find('is_rating_1');
                    $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                    $buffer .= '>⭐ 1 ';
                    $value = $context->find('str');
                    $buffer .= $this->section80717993978cf062d0bd94d0df600647($context, $indent, $value);
                    $buffer .= '</option>
';
                    $buffer .= $indent . '                                </select>
';
                    $buffer .= $indent . '                            </div>
';
                    $buffer .= $indent . '                            <div class="mb-2">
';
                    $buffer .= $indent . '                                <input class="form-control form-control-sm" name="review_note" placeholder="';
                    $value = $context->find('str');
                    $buffer .= $this->sectionE5e23567ad08a2707675347646352974($context, $indent, $value);
                    $buffer .= '..." value="';
                    $value = $this->resolveValue($context->find('teacher_comment'), $context);
                    $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                    $buffer .= '">
';
                    $buffer .= $indent . '                            </div>
';
                    $buffer .= $indent . '                            <div class="d-flex justify-content-between align-items-center">
';
                    $buffer .= $indent . '                                <div>
';
                    $value = $context->find('is_approved');
                    $buffer .= $this->section201d7e785162c4fd6ef89c824f3e172f($context, $indent, $value);
                    $value = $context->find('is_rejected');
                    $buffer .= $this->sectionF56ae6f64b9baf63bd200fbd4279e646($context, $indent, $value);
                    $value = $context->find('is_duplicate');
                    $buffer .= $this->section1da774bd41df509cb3d076748335333e($context, $indent, $value);
                    $buffer .= $indent . '                                </div>
';
                    $buffer .= $indent . '                                <button class="btn btn-sm btn-primary" type="submit" name="decision" value="rate_only">
';
                    $buffer .= $indent . '                                    Save
';
                    $buffer .= $indent . '                                </button>
';
                    $buffer .= $indent . '                            </div>
';
                    $buffer .= $indent . '                        </form>
';
                    $buffer .= $indent . '                    </div>
';
                }
                $buffer .= $indent . '                </td>
';
                $buffer .= $indent . '            </tr>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

}
