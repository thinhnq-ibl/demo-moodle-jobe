<?php

class __Mustache_8c0cf4970d9f529de028c85d4a6a1a4d extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        $value = $context->find('has_questions');
        if (empty($value)) {
            
            $buffer .= $indent . '<div class="alert alert-warning">';
            $value = $context->find('str');
            $buffer .= $this->sectionBd2d40cdfbac59f93e95c6f826d86349($context, $indent, $value);
            $buffer .= '</div>';
        }
        $buffer .= '
';
        $value = $context->find('has_questions');
        $buffer .= $this->sectionF9706c80c1dfd9ee9f73a575ba9ca731($context, $indent, $value);

        return $buffer;
    }

    private function sectionBd2d40cdfbac59f93e95c6f826d86349(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' nocoderunnerquestions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' nocoderunnerquestions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section5b3c2c7359200a0f9ca8de84cb395381(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' selectquestion, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' selectquestion, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9e2875c627d2dbad7c957250bbb623f7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'selected';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'selected';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF34cd55d22fd5d542cabd659523d8c6c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<option value="{{value}}" {{#selected}}selected{{/selected}}>{{label}}</option>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<option value="';
                $value = $this->resolveValue($context->find('value'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" ';
                $value = $context->find('selected');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $this->resolveValue($context->find('label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1364337097e5de0f12b692ad62b264ef(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' quizpolicy, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' quizpolicy, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section51d7c9c652ced0161cb587bacd669266(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'checked';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'checked';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section559b99473927992ec04a969693ea2384(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' enablefeature, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' enablefeature, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section84e986cd4c1d0f57a09bce0840d9b633(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' showoracle, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' showoracle, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section65c3a1ecf6d387634148812943aaca70(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' enableleaderboard, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' enableleaderboard, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7fc23adbc0746528be3ee811003a2fe1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' reviewmode, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' reviewmode, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section13555cd642c564e514d58b3c1123fc72(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' reviewmode_teacher, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' reviewmode_teacher, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section0bacb117067783f6a347219bf8637be7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' reviewmode_auto, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' reviewmode_auto, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section0f949beabfa76d46cec915327ab22a46(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rewardpolicy, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rewardpolicy, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC3dd61e4ec450860df734db4e9f02e54(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' rewardpolicy_oneforone, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' rewardpolicy_oneforone, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section8c4ccdc1aa71164de28fda42b780c0ef(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' disabled, core ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' disabled, core ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD5364ea9d4a45d6049d20f9f57115ff6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' runsperminute, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' runsperminute, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section666e92f5991d78243a5a44529d5ea659(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' maxinputbytes, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' maxinputbytes, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section300a5abc76b2c1ebb804d96b8a5ad6d2(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' questionpolicy, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' questionpolicy, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE244fb8de216745ef5add3cd5a3fcdaa(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' inputmode, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' inputmode, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE50b78a80172009cb7e66004b34db067(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' testcodetemplate, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' testcodetemplate, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1b897a55800ecb4380ed3faa21162e3c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' normalization, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' normalization, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section5790c442636b51759fbb3f9a8673471e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' categories, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' categories, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section23b3a14ca6ac1fde37ed800e22c17602(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                    <tr>
                        <td><strong>#{{id}}</strong></td>
                        <td><code>{{testcode}}</code></td>
                        <td><code>{{expected_output}}</code></td>
                        <td><small class="text-muted">{{purpose}}</small></td>
                        <td><span class="badge badge-secondary">{{source_type}}</span></td>
                        <td>
                            <button type="submit" name="action" value="delete_seed" onclick="document.getElementById(\'hidden_seed_id\').value=\'{{id}}\'; return confirm(\'Xóa hạt giống này?\');" class="btn btn-sm btn-outline-danger py-0 px-1">Xóa</button>
                        </td>
                    </tr>
                    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                    <tr>
';
                $buffer .= $indent . '                        <td><strong>#';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></td>
';
                $buffer .= $indent . '                        <td><code>';
                $value = $this->resolveValue($context->find('testcode'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</code></td>
';
                $buffer .= $indent . '                        <td><code>';
                $value = $this->resolveValue($context->find('expected_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</code></td>
';
                $buffer .= $indent . '                        <td><small class="text-muted">';
                $value = $this->resolveValue($context->find('purpose'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td>
';
                $buffer .= $indent . '                        <td><span class="badge badge-secondary">';
                $value = $this->resolveValue($context->find('source_type'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span></td>
';
                $buffer .= $indent . '                        <td>
';
                $buffer .= $indent . '                            <button type="submit" name="action" value="delete_seed" onclick="document.getElementById(\'hidden_seed_id\').value=\'';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '\'; return confirm(\'Xóa hạt giống này?\');" class="btn btn-sm btn-outline-danger py-0 px-1">Xóa</button>
';
                $buffer .= $indent . '                        </td>
';
                $buffer .= $indent . '                    </tr>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section82c1bf69b7b6adcefaf5040cd2932867(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
        <div class="table-responsive mb-4">
            <table class="table table-bordered table-sm table-hover">
                <thead class="thead-light">
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th>Test Code</th>
                        <th>Expected Output</th>
                        <th>Ghi chú / Mục đích</th>
                        <th style="width: 100px;">Nguồn</th>
                        <th style="width: 70px;">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    {{#seeds}}
                    <tr>
                        <td><strong>#{{id}}</strong></td>
                        <td><code>{{testcode}}</code></td>
                        <td><code>{{expected_output}}</code></td>
                        <td><small class="text-muted">{{purpose}}</small></td>
                        <td><span class="badge badge-secondary">{{source_type}}</span></td>
                        <td>
                            <button type="submit" name="action" value="delete_seed" onclick="document.getElementById(\'hidden_seed_id\').value=\'{{id}}\'; return confirm(\'Xóa hạt giống này?\');" class="btn btn-sm btn-outline-danger py-0 px-1">Xóa</button>
                        </td>
                    </tr>
                    {{/seeds}}
                </tbody>
            </table>
        </div>
        ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '        <div class="table-responsive mb-4">
';
                $buffer .= $indent . '            <table class="table table-bordered table-sm table-hover">
';
                $buffer .= $indent . '                <thead class="thead-light">
';
                $buffer .= $indent . '                    <tr>
';
                $buffer .= $indent . '                        <th style="width: 50px;">ID</th>
';
                $buffer .= $indent . '                        <th>Test Code</th>
';
                $buffer .= $indent . '                        <th>Expected Output</th>
';
                $buffer .= $indent . '                        <th>Ghi chú / Mục đích</th>
';
                $buffer .= $indent . '                        <th style="width: 100px;">Nguồn</th>
';
                $buffer .= $indent . '                        <th style="width: 70px;">Thao tác</th>
';
                $buffer .= $indent . '                    </tr>
';
                $buffer .= $indent . '                </thead>
';
                $buffer .= $indent . '                <tbody>
';
                $value = $context->find('seeds');
                $buffer .= $this->section23b3a14ca6ac1fde37ed800e22c17602($context, $indent, $value);
                $buffer .= $indent . '                </tbody>
';
                $buffer .= $indent . '            </table>
';
                $buffer .= $indent . '        </div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF9706c80c1dfd9ee9f73a575ba9ca731(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<form method="get" class="mb-4"><input type="hidden" name="course" value="{{courseid}}"><label for="question"><strong>{{#str}} selectquestion, local_testcase_exchange {{/str}}</strong></label><select id="question" name="question" class="form-control" onchange="this.form.submit()">{{#questions}}<option value="{{value}}" {{#selected}}selected{{/selected}}>{{label}}</option>{{/questions}}</select></form>
<form method="post"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="question" value="{{selection}}">
<div class="card mb-3"><div class="card-header"><strong>{{#str}} quizpolicy, local_testcase_exchange {{/str}}</strong></div><div class="card-body">
<div class="form-check"><input type="checkbox" class="form-check-input" id="enabled" name="enabled" value="1" {{#enabled}}checked{{/enabled}}><label class="form-check-label" for="enabled">{{#str}} enablefeature, local_testcase_exchange {{/str}}</label></div>
<div class="form-check"><input type="checkbox" class="form-check-input" id="show_oracle_output" name="show_oracle_output" value="1" {{#show_oracle_output}}checked{{/show_oracle_output}}><label class="form-check-label" for="show_oracle_output">{{#str}} showoracle, local_testcase_exchange {{/str}}</label></div>
<div class="form-check mb-3"><input type="checkbox" class="form-check-input" id="leaderboard_enabled" name="leaderboard_enabled" value="1" {{#leaderboard_enabled}}checked{{/leaderboard_enabled}}><label class="form-check-label" for="leaderboard_enabled">{{#str}} enableleaderboard, local_testcase_exchange {{/str}}</label></div>
<label>{{#str}} reviewmode, local_testcase_exchange {{/str}}</label><select class="form-control mb-2" name="review_mode"><option value="teacher" {{#review_teacher}}selected{{/review_teacher}}>{{#str}} reviewmode_teacher, local_testcase_exchange {{/str}}</option><option value="auto" {{#review_auto}}selected{{/review_auto}}>{{#str}} reviewmode_auto, local_testcase_exchange {{/str}}</option></select>
<label>{{#str}} rewardpolicy, local_testcase_exchange {{/str}}</label><select class="form-control mb-2" name="reward_policy"><option value="one_for_one" {{#reward_one_for_one}}selected{{/reward_one_for_one}}>{{#str}} rewardpolicy_oneforone, local_testcase_exchange {{/str}}</option><option value="disabled" {{#reward_disabled}}selected{{/reward_disabled}}>{{#str}} disabled, core {{/str}}</option></select>
<label>{{#str}} runsperminute, local_testcase_exchange {{/str}}</label><input class="form-control mb-2" type="number" min="1" max="120" name="max_runs_per_minute" value="{{max_runs_per_minute}}"><label>{{#str}} maxinputbytes, local_testcase_exchange {{/str}}</label><input class="form-control" type="number" min="64" max="1048576" name="max_input_bytes" value="{{max_input_bytes}}">
</div></div>
<div class="card mb-3"><div class="card-header"><strong>{{#str}} questionpolicy, local_testcase_exchange {{/str}}</strong></div><div class="card-body">
<label>{{#str}} inputmode, local_testcase_exchange {{/str}}</label><select class="form-control mb-2" name="input_mode"><option value="stdin" {{#input_stdin}}selected{{/input_stdin}}>stdin</option><option value="testcode" {{#input_testcode}}selected{{/input_testcode}}>testcode</option><option value="template" {{#input_template}}selected{{/input_template}}>template</option></select>
<label>{{#str}} testcodetemplate, local_testcase_exchange {{/str}}</label><textarea class="form-control mb-2" name="testcode_template" rows="4">{{testcode_template}}</textarea><label>{{#str}} normalization, local_testcase_exchange {{/str}}</label><select class="form-control mb-2" name="normalization_mode"><option value="raw" {{#normalization_raw}}selected{{/normalization_raw}}>raw</option><option value="trim" {{#normalization_trim}}selected{{/normalization_trim}}>trim</option><option value="json" {{#normalization_json}}selected{{/normalization_json}}>json</option></select><label>{{#str}} categories, local_testcase_exchange {{/str}}</label><input class="form-control" name="categories" value="{{categories}}"></div></div>
<div class="card mb-3 border-primary">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <strong>🌱 Kho Hạt Giống Thưởng Độc Lập (Seed Testcase Bank)</strong>
        <span class="badge badge-light text-dark">{{seeds_count}} hạt giống</span>
    </div>
    <div class="card-body">
        <p class="text-muted small">
            Các ca kiểm thử hạt giống được lưu trữ riêng trong hệ thống, độc lập với bài thi Quiz. Dùng làm phần thưởng ban đầu khi sinh viên đóng góp testcase thành công.
        </p>

        {{#has_seeds}}
        <div class="table-responsive mb-4">
            <table class="table table-bordered table-sm table-hover">
                <thead class="thead-light">
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th>Test Code</th>
                        <th>Expected Output</th>
                        <th>Ghi chú / Mục đích</th>
                        <th style="width: 100px;">Nguồn</th>
                        <th style="width: 70px;">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    {{#seeds}}
                    <tr>
                        <td><strong>#{{id}}</strong></td>
                        <td><code>{{testcode}}</code></td>
                        <td><code>{{expected_output}}</code></td>
                        <td><small class="text-muted">{{purpose}}</small></td>
                        <td><span class="badge badge-secondary">{{source_type}}</span></td>
                        <td>
                            <button type="submit" name="action" value="delete_seed" onclick="document.getElementById(\'hidden_seed_id\').value=\'{{id}}\'; return confirm(\'Xóa hạt giống này?\');" class="btn btn-sm btn-outline-danger py-0 px-1">Xóa</button>
                        </td>
                    </tr>
                    {{/seeds}}
                </tbody>
            </table>
        </div>
        {{/has_seeds}}
        {{^has_seeds}}
        <div class="alert alert-light border text-center text-muted py-3 mb-3">
            Chưa có hạt giống nào cho bài tập này. Thầy/Cô hãy thêm hạt giống bằng tay hoặc tải file XML lên bên dưới.
        </div>
        {{/has_seeds}}

        <input type="hidden" id="hidden_seed_id" name="seed_id" value="0">

        <!-- Tab thêm thủ công & import XML -->
        <div class="row">
            <div class="col-md-7 mb-3">
                <div class="border rounded p-3 bg-light h-100">
                    <h6 class="font-weight-bold text-dark mb-2">➕ Thêm Hạt Giống Thủ Công</h6>
                    <div class="form-group mb-2">
                        <label class="small mb-1"><strong>Test Code (Lệnh gọi hàm/biểu thức):</strong></label>
                        <textarea class="form-control form-control-sm font-monospace" name="seed_testcode" rows="2" placeholder="Ví dụ: print(tinh_tong(10))"></textarea>
                    </div>
                    <div class="form-group mb-2">
                        <label class="small mb-1"><strong>Expected Output (Kết quả in ra):</strong></label>
                        <textarea class="form-control form-control-sm font-monospace" name="seed_expected" rows="1" placeholder="Ví dụ: 55"></textarea>
                    </div>
                    <div class="form-group mb-2">
                        <label class="small mb-1">Standard Input (nếu có, để trống nếu viết hàm):</label>
                        <input type="text" class="form-control form-control-sm font-monospace" name="seed_stdin" placeholder="(để trống nếu không dùng input)">
                    </div>
                    <div class="form-group mb-3">
                        <label class="small mb-1">Mục đích kiểm thử / Ghi chú sư phạm:</label>
                        <input type="text" class="form-control form-control-sm" name="seed_purpose" placeholder="Ví dụ: Kiểm tra số nguyên dương n=10">
                    </div>
                    <button type="submit" name="action" value="add_manual_seed" class="btn btn-success btn-sm font-weight-bold">
                        ➕ Thêm Hạt Giống Này
                    </button>
                </div>
            </div>

            <div class="col-md-5 mb-3">
                <div class="border rounded p-3 bg-light h-100">
                    <h6 class="font-weight-bold text-dark mb-2">📥 Nhập từ File XML Moodle</h6>
                    <p class="small text-muted mb-2">
                        Tải lên file <code>.xml</code> xuất từ Ngân hàng câu hỏi Moodle. Hệ thống sẽ tự động quét và trích xuất các testcase đưa vào kho Hạt giống.
                    </p>
                    <div class="form-group mb-3">
                        <input type="file" class="form-control-file border p-1 bg-white" name="xml_file" accept=".xml">
                    </div>
                    <button type="submit" name="action" value="import_xml_seeds" class="btn btn-info btn-sm font-weight-bold" onclick="this.form.enctype=\'multipart/form-data\';">
                        🚀 Tải lên & Trích xuất Hạt Giống
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mt-3">
    <button class="btn btn-primary font-weight-bold px-4" type="submit" name="action" value="save_policy">💾 Lưu Cấu Hình Chính Sách</button>
</div>
</form>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<form method="get" class="mb-4"><input type="hidden" name="course" value="';
                $value = $this->resolveValue($context->find('courseid'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><label for="question"><strong>';
                $value = $context->find('str');
                $buffer .= $this->section5b3c2c7359200a0f9ca8de84cb395381($context, $indent, $value);
                $buffer .= '</strong></label><select id="question" name="question" class="form-control" onchange="this.form.submit()">';
                $value = $context->find('questions');
                $buffer .= $this->sectionF34cd55d22fd5d542cabd659523d8c6c($context, $indent, $value);
                $buffer .= '</select></form>
';
                $buffer .= $indent . '<form method="post"><input type="hidden" name="sesskey" value="';
                $value = $this->resolveValue($context->find('sesskey'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><input type="hidden" name="question" value="';
                $value = $this->resolveValue($context->find('selection'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '<div class="card mb-3"><div class="card-header"><strong>';
                $value = $context->find('str');
                $buffer .= $this->section1364337097e5de0f12b692ad62b264ef($context, $indent, $value);
                $buffer .= '</strong></div><div class="card-body">
';
                $buffer .= $indent . '<div class="form-check"><input type="checkbox" class="form-check-input" id="enabled" name="enabled" value="1" ';
                $value = $context->find('enabled');
                $buffer .= $this->section51d7c9c652ced0161cb587bacd669266($context, $indent, $value);
                $buffer .= '><label class="form-check-label" for="enabled">';
                $value = $context->find('str');
                $buffer .= $this->section559b99473927992ec04a969693ea2384($context, $indent, $value);
                $buffer .= '</label></div>
';
                $buffer .= $indent . '<div class="form-check"><input type="checkbox" class="form-check-input" id="show_oracle_output" name="show_oracle_output" value="1" ';
                $value = $context->find('show_oracle_output');
                $buffer .= $this->section51d7c9c652ced0161cb587bacd669266($context, $indent, $value);
                $buffer .= '><label class="form-check-label" for="show_oracle_output">';
                $value = $context->find('str');
                $buffer .= $this->section84e986cd4c1d0f57a09bce0840d9b633($context, $indent, $value);
                $buffer .= '</label></div>
';
                $buffer .= $indent . '<div class="form-check mb-3"><input type="checkbox" class="form-check-input" id="leaderboard_enabled" name="leaderboard_enabled" value="1" ';
                $value = $context->find('leaderboard_enabled');
                $buffer .= $this->section51d7c9c652ced0161cb587bacd669266($context, $indent, $value);
                $buffer .= '><label class="form-check-label" for="leaderboard_enabled">';
                $value = $context->find('str');
                $buffer .= $this->section65c3a1ecf6d387634148812943aaca70($context, $indent, $value);
                $buffer .= '</label></div>
';
                $buffer .= $indent . '<label>';
                $value = $context->find('str');
                $buffer .= $this->section7fc23adbc0746528be3ee811003a2fe1($context, $indent, $value);
                $buffer .= '</label><select class="form-control mb-2" name="review_mode"><option value="teacher" ';
                $value = $context->find('review_teacher');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $context->find('str');
                $buffer .= $this->section13555cd642c564e514d58b3c1123fc72($context, $indent, $value);
                $buffer .= '</option><option value="auto" ';
                $value = $context->find('review_auto');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $context->find('str');
                $buffer .= $this->section0bacb117067783f6a347219bf8637be7($context, $indent, $value);
                $buffer .= '</option></select>
';
                $buffer .= $indent . '<label>';
                $value = $context->find('str');
                $buffer .= $this->section0f949beabfa76d46cec915327ab22a46($context, $indent, $value);
                $buffer .= '</label><select class="form-control mb-2" name="reward_policy"><option value="one_for_one" ';
                $value = $context->find('reward_one_for_one');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $context->find('str');
                $buffer .= $this->sectionC3dd61e4ec450860df734db4e9f02e54($context, $indent, $value);
                $buffer .= '</option><option value="disabled" ';
                $value = $context->find('reward_disabled');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $context->find('str');
                $buffer .= $this->section8c4ccdc1aa71164de28fda42b780c0ef($context, $indent, $value);
                $buffer .= '</option></select>
';
                $buffer .= $indent . '<label>';
                $value = $context->find('str');
                $buffer .= $this->sectionD5364ea9d4a45d6049d20f9f57115ff6($context, $indent, $value);
                $buffer .= '</label><input class="form-control mb-2" type="number" min="1" max="120" name="max_runs_per_minute" value="';
                $value = $this->resolveValue($context->find('max_runs_per_minute'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><label>';
                $value = $context->find('str');
                $buffer .= $this->section666e92f5991d78243a5a44529d5ea659($context, $indent, $value);
                $buffer .= '</label><input class="form-control" type="number" min="64" max="1048576" name="max_input_bytes" value="';
                $value = $this->resolveValue($context->find('max_input_bytes'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '</div></div>
';
                $buffer .= $indent . '<div class="card mb-3"><div class="card-header"><strong>';
                $value = $context->find('str');
                $buffer .= $this->section300a5abc76b2c1ebb804d96b8a5ad6d2($context, $indent, $value);
                $buffer .= '</strong></div><div class="card-body">
';
                $buffer .= $indent . '<label>';
                $value = $context->find('str');
                $buffer .= $this->sectionE244fb8de216745ef5add3cd5a3fcdaa($context, $indent, $value);
                $buffer .= '</label><select class="form-control mb-2" name="input_mode"><option value="stdin" ';
                $value = $context->find('input_stdin');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>stdin</option><option value="testcode" ';
                $value = $context->find('input_testcode');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>testcode</option><option value="template" ';
                $value = $context->find('input_template');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>template</option></select>
';
                $buffer .= $indent . '<label>';
                $value = $context->find('str');
                $buffer .= $this->sectionE50b78a80172009cb7e66004b34db067($context, $indent, $value);
                $buffer .= '</label><textarea class="form-control mb-2" name="testcode_template" rows="4">';
                $value = $this->resolveValue($context->find('testcode_template'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</textarea><label>';
                $value = $context->find('str');
                $buffer .= $this->section1b897a55800ecb4380ed3faa21162e3c($context, $indent, $value);
                $buffer .= '</label><select class="form-control mb-2" name="normalization_mode"><option value="raw" ';
                $value = $context->find('normalization_raw');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>raw</option><option value="trim" ';
                $value = $context->find('normalization_trim');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>trim</option><option value="json" ';
                $value = $context->find('normalization_json');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>json</option></select><label>';
                $value = $context->find('str');
                $buffer .= $this->section5790c442636b51759fbb3f9a8673471e($context, $indent, $value);
                $buffer .= '</label><input class="form-control" name="categories" value="';
                $value = $this->resolveValue($context->find('categories'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"></div></div>
';
                $buffer .= $indent . '<div class="card mb-3 border-primary">
';
                $buffer .= $indent . '    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
';
                $buffer .= $indent . '        <strong>🌱 Kho Hạt Giống Thưởng Độc Lập (Seed Testcase Bank)</strong>
';
                $buffer .= $indent . '        <span class="badge badge-light text-dark">';
                $value = $this->resolveValue($context->find('seeds_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' hạt giống</span>
';
                $buffer .= $indent . '    </div>
';
                $buffer .= $indent . '    <div class="card-body">
';
                $buffer .= $indent . '        <p class="text-muted small">
';
                $buffer .= $indent . '            Các ca kiểm thử hạt giống được lưu trữ riêng trong hệ thống, độc lập với bài thi Quiz. Dùng làm phần thưởng ban đầu khi sinh viên đóng góp testcase thành công.
';
                $buffer .= $indent . '        </p>
';
                $buffer .= $indent . '
';
                $value = $context->find('has_seeds');
                $buffer .= $this->section82c1bf69b7b6adcefaf5040cd2932867($context, $indent, $value);
                $value = $context->find('has_seeds');
                if (empty($value)) {
                    
                    $buffer .= $indent . '        <div class="alert alert-light border text-center text-muted py-3 mb-3">
';
                    $buffer .= $indent . '            Chưa có hạt giống nào cho bài tập này. Thầy/Cô hãy thêm hạt giống bằng tay hoặc tải file XML lên bên dưới.
';
                    $buffer .= $indent . '        </div>
';
                }
                $buffer .= $indent . '
';
                $buffer .= $indent . '        <input type="hidden" id="hidden_seed_id" name="seed_id" value="0">
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '        <!-- Tab thêm thủ công & import XML -->
';
                $buffer .= $indent . '        <div class="row">
';
                $buffer .= $indent . '            <div class="col-md-7 mb-3">
';
                $buffer .= $indent . '                <div class="border rounded p-3 bg-light h-100">
';
                $buffer .= $indent . '                    <h6 class="font-weight-bold text-dark mb-2">➕ Thêm Hạt Giống Thủ Công</h6>
';
                $buffer .= $indent . '                    <div class="form-group mb-2">
';
                $buffer .= $indent . '                        <label class="small mb-1"><strong>Test Code (Lệnh gọi hàm/biểu thức):</strong></label>
';
                $buffer .= $indent . '                        <textarea class="form-control form-control-sm font-monospace" name="seed_testcode" rows="2" placeholder="Ví dụ: print(tinh_tong(10))"></textarea>
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                    <div class="form-group mb-2">
';
                $buffer .= $indent . '                        <label class="small mb-1"><strong>Expected Output (Kết quả in ra):</strong></label>
';
                $buffer .= $indent . '                        <textarea class="form-control form-control-sm font-monospace" name="seed_expected" rows="1" placeholder="Ví dụ: 55"></textarea>
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                    <div class="form-group mb-2">
';
                $buffer .= $indent . '                        <label class="small mb-1">Standard Input (nếu có, để trống nếu viết hàm):</label>
';
                $buffer .= $indent . '                        <input type="text" class="form-control form-control-sm font-monospace" name="seed_stdin" placeholder="(để trống nếu không dùng input)">
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                    <div class="form-group mb-3">
';
                $buffer .= $indent . '                        <label class="small mb-1">Mục đích kiểm thử / Ghi chú sư phạm:</label>
';
                $buffer .= $indent . '                        <input type="text" class="form-control form-control-sm" name="seed_purpose" placeholder="Ví dụ: Kiểm tra số nguyên dương n=10">
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                    <button type="submit" name="action" value="add_manual_seed" class="btn btn-success btn-sm font-weight-bold">
';
                $buffer .= $indent . '                        ➕ Thêm Hạt Giống Này
';
                $buffer .= $indent . '                    </button>
';
                $buffer .= $indent . '                </div>
';
                $buffer .= $indent . '            </div>
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '            <div class="col-md-5 mb-3">
';
                $buffer .= $indent . '                <div class="border rounded p-3 bg-light h-100">
';
                $buffer .= $indent . '                    <h6 class="font-weight-bold text-dark mb-2">📥 Nhập từ File XML Moodle</h6>
';
                $buffer .= $indent . '                    <p class="small text-muted mb-2">
';
                $buffer .= $indent . '                        Tải lên file <code>.xml</code> xuất từ Ngân hàng câu hỏi Moodle. Hệ thống sẽ tự động quét và trích xuất các testcase đưa vào kho Hạt giống.
';
                $buffer .= $indent . '                    </p>
';
                $buffer .= $indent . '                    <div class="form-group mb-3">
';
                $buffer .= $indent . '                        <input type="file" class="form-control-file border p-1 bg-white" name="xml_file" accept=".xml">
';
                $buffer .= $indent . '                    </div>
';
                $buffer .= $indent . '                    <button type="submit" name="action" value="import_xml_seeds" class="btn btn-info btn-sm font-weight-bold" onclick="this.form.enctype=\'multipart/form-data\';">
';
                $buffer .= $indent . '                        🚀 Tải lên & Trích xuất Hạt Giống
';
                $buffer .= $indent . '                    </button>
';
                $buffer .= $indent . '                </div>
';
                $buffer .= $indent . '            </div>
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '    </div>
';
                $buffer .= $indent . '</div>
';
                $buffer .= $indent . '
';
                $buffer .= $indent . '<div class="d-flex justify-content-between align-items-center mt-3">
';
                $buffer .= $indent . '    <button class="btn btn-primary font-weight-bold px-4" type="submit" name="action" value="save_policy">💾 Lưu Cấu Hình Chính Sách</button>
';
                $buffer .= $indent . '</div>
';
                $buffer .= $indent . '</form>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

}
