<?php

class __Mustache_3f05812e9ffb70f107774ef5fc194f1c extends Mustache_Template
{
    private $lambdaHelper;

    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $this->lambdaHelper = new Mustache_LambdaHelper($this->mustache, $context);
        $buffer = '';

        $value = $context->find('show_course_switcher');
        $buffer .= $this->section19dc20d609c61af79a73fbd8c5838131($context, $indent, $value);
        $buffer .= $indent . '
';
        $value = $context->find('has_return_url');
        $buffer .= $this->section87c59f451c3c43d874f31d52370163a7($context, $indent, $value);
        $buffer .= $indent . '
';
        $value = $context->find('can_manage_or_review');
        $buffer .= $this->sectionBfaacc9ad82beeea4d52803ed75a03c2($context, $indent, $value);
        $value = $context->find('can_run');
        $buffer .= $this->section304fa2eb9e4ba53d7cd3f469ac64b78b($context, $indent, $value);
        $buffer .= $indent . '<ul class="nav nav-tabs" role="tablist">
';
        $value = $context->find('is_teacher');
        $buffer .= $this->section2cfcb9ec042f9147f840659477ada1af($context, $indent, $value);
        $buffer .= $indent . '    <li class="nav-item"><a class="nav-link ';
        $value = $context->find('is_teacher');
        if (empty($value)) {
            
            $buffer .= 'active';
        }
        $buffer .= '" data-toggle="tab" href="#runs">';
        $value = $context->find('str');
        $buffer .= $this->sectionF9891d6cb4e7be1138d2f0b89848cc5f($context, $indent, $value);
        $buffer .= ' (';
        $value = $this->resolveValue($context->find('run_count'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= ')</a></li>
';
        $buffer .= $indent . '    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#contributions">';
        $value = $context->find('str');
        $buffer .= $this->sectionF234ca24bbe7e007b280c1fc685f4fae($context, $indent, $value);
        $buffer .= ' (';
        $value = $this->resolveValue($context->find('contribution_count'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= ')</a></li>
';
        $buffer .= $indent . '    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#rewards">';
        $value = $context->find('str');
        $buffer .= $this->section882ffa9f688030d6b54bece2b10773e5($context, $indent, $value);
        $buffer .= ' (';
        $value = $this->resolveValue($context->find('reward_count'), $context);
        $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
        $buffer .= ')</a></li>
';
        $buffer .= $indent . '</ul>
';
        $buffer .= $indent . '<div class="tab-content border border-top-0 p-3 mb-4">
';
        $value = $context->find('is_teacher');
        $buffer .= $this->sectionD5e165378c5d857acff683bb0fdd36a3($context, $indent, $value);
        $buffer .= $indent . '    <div class="tab-pane ';
        $value = $context->find('is_teacher');
        if (empty($value)) {
            
            $buffer .= 'active';
        }
        $buffer .= '" id="runs"><div class="table-responsive"><table class="table table-sm table-striped"><thead><tr><th>ID</th><th>Input</th><th>';
        $value = $context->find('str');
        $buffer .= $this->sectionA232c2b70c8f3ce2647a2471a7d66f5d($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section276f858459cc46f9ced627000e61c1c7($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section9b9054987cd3b32d511d5845018cc8b0($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section99380e31c66dc018fdbb40851d8c070c($context, $indent, $value);
        $buffer .= '</th><th></th></tr></thead><tbody>';
        $value = $context->find('runs');
        $buffer .= $this->sectionBdcb6a9a484e5b218a793ca0af5afc41($context, $indent, $value);
        $buffer .= '</tbody></table></div></div>
';
        $buffer .= $indent . '    <div class="tab-pane" id="contributions"><div class="table-responsive"><table class="table table-sm table-striped"><thead><tr><th>ID</th><th>Input</th><th>';
        $value = $context->find('str');
        $buffer .= $this->sectionF6d8114da9c7bff859d802d41c6c3256($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section99380e31c66dc018fdbb40851d8c070c($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section237a5b12de4e3e9871419c02873d73ea($context, $indent, $value);
        $buffer .= ' / ';
        $value = $context->find('str');
        $buffer .= $this->sectionE5e23567ad08a2707675347646352974($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section664f62332772dbc21a7a324f47ad636e($context, $indent, $value);
        $buffer .= '</th></tr></thead><tbody>';
        $value = $context->find('contributions');
        $buffer .= $this->section2091fe7451d4f46b7dba8d5ade9a79a1($context, $indent, $value);
        $buffer .= '</tbody></table></div></div>
';
        $buffer .= $indent . '    <div class="tab-pane" id="rewards"><div class="table-responsive"><table class="table table-sm table-striped"><thead><tr><th>ID</th><th>Input</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section9b9054987cd3b32d511d5845018cc8b0($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->sectionF6d8114da9c7bff859d802d41c6c3256($context, $indent, $value);
        $buffer .= '</th><th>';
        $value = $context->find('str');
        $buffer .= $this->section664f62332772dbc21a7a324f47ad636e($context, $indent, $value);
        $buffer .= '</th></tr></thead><tbody>';
        $value = $context->find('rewards');
        $buffer .= $this->section8669761b537ce5a6424ed580d3da2fe1($context, $indent, $value);
        $buffer .= '</tbody></table></div></div>
';
        $buffer .= $indent . '</div>
';

        return $buffer;
    }

    private function section935207dbb135155d9033286c71d96189(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' course ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' course ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4b647e8c317e0c7bd8dc69b2d92349ab(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' allcourses, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' allcourses, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section85cf18307942aa0a878ed360612632ea(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' switchcourse, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' switchcourse, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9e2875c627d2dbad7c957250bbb623f7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'selected';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'selected';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC56bd66fc097d0a33857c935199760f4(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
                <option value="{{switch_url}}" {{#is_current}}selected{{/is_current}}>{{shortname}} - {{fullname}}</option>
                ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '                <option value="';
                $value = $this->resolveValue($context->find('switch_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" ';
                $value = $context->find('is_current');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $this->resolveValue($context->find('shortname'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ' - ';
                $value = $this->resolveValue($context->find('fullname'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section19dc20d609c61af79a73fbd8c5838131(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="card bg-light mb-3 p-2">
    <div class="d-flex flex-wrap justify-content-between align-items-center">
        <div>
            <span class="text-muted mr-1">📚 {{#str}} course {{/str}}:</span>
            <strong>{{current_course_name}}</strong>
            <a href="{{course_hub_url}}" class="badge badge-secondary ml-2">&larr; {{#str}} allcourses, local_testcase_exchange {{/str}}</a>
        </div>
        <div class="d-flex align-items-center mt-1 mt-md-0">
            <label for="switchCourseSelect" class="small text-muted mb-0 mr-2">{{#str}} switchcourse, local_testcase_exchange {{/str}}:</label>
            <select id="switchCourseSelect" class="custom-select custom-select-sm" onchange="if (this.value) window.location.href=this.value;">
                {{#available_courses}}
                <option value="{{switch_url}}" {{#is_current}}selected{{/is_current}}>{{shortname}} - {{fullname}}</option>
                {{/available_courses}}
            </select>
        </div>
    </div>
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="card bg-light mb-3 p-2">
';
                $buffer .= $indent . '    <div class="d-flex flex-wrap justify-content-between align-items-center">
';
                $buffer .= $indent . '        <div>
';
                $buffer .= $indent . '            <span class="text-muted mr-1">📚 ';
                $value = $context->find('str');
                $buffer .= $this->section935207dbb135155d9033286c71d96189($context, $indent, $value);
                $buffer .= ':</span>
';
                $buffer .= $indent . '            <strong>';
                $value = $this->resolveValue($context->find('current_course_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong>
';
                $buffer .= $indent . '            <a href="';
                $value = $this->resolveValue($context->find('course_hub_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" class="badge badge-secondary ml-2">&larr; ';
                $value = $context->find('str');
                $buffer .= $this->section4b647e8c317e0c7bd8dc69b2d92349ab($context, $indent, $value);
                $buffer .= '</a>
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '        <div class="d-flex align-items-center mt-1 mt-md-0">
';
                $buffer .= $indent . '            <label for="switchCourseSelect" class="small text-muted mb-0 mr-2">';
                $value = $context->find('str');
                $buffer .= $this->section85cf18307942aa0a878ed360612632ea($context, $indent, $value);
                $buffer .= ':</label>
';
                $buffer .= $indent . '            <select id="switchCourseSelect" class="custom-select custom-select-sm" onchange="if (this.value) window.location.href=this.value;">
';
                $value = $context->find('available_courses');
                $buffer .= $this->sectionC56bd66fc097d0a33857c935199760f4($context, $indent, $value);
                $buffer .= $indent . '            </select>
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '    </div>
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7b108c120350250de45d032e1ccc0e06(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' backtocurrentquiz, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' backtocurrentquiz, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section70c2ecfed881d1707308d6e1e1b28afd(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ': <strong>{{return_quiz_name}}</strong>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ': <strong>';
                $value = $this->resolveValue($context->find('return_quiz_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section87c59f451c3c43d874f31d52370163a7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="mb-3 d-flex align-items-center">
    <a class="btn btn-outline-secondary font-weight-bold" href="{{return_url}}">
        &larr; {{#str}} backtocurrentquiz, local_testcase_exchange {{/str}}{{#return_quiz_name}}: <strong>{{return_quiz_name}}</strong>{{/return_quiz_name}}
    </a>
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="mb-3 d-flex align-items-center">
';
                $buffer .= $indent . '    <a class="btn btn-outline-secondary font-weight-bold" href="';
                $value = $this->resolveValue($context->find('return_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">
';
                $buffer .= $indent . '        &larr; ';
                $value = $context->find('str');
                $buffer .= $this->section7b108c120350250de45d032e1ccc0e06($context, $indent, $value);
                $value = $context->find('return_quiz_name');
                $buffer .= $this->section70c2ecfed881d1707308d6e1e1b28afd($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '    </a>
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section813ec5a09be0517982e993b59ae572e1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' managepolicies, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' managepolicies, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBb0fa0981f84b55bb525290d43006ea0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<a class="btn btn-secondary mr-2 mb-2" href="{{policy_url}}">{{#str}} managepolicies, local_testcase_exchange {{/str}}</a>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<a class="btn btn-secondary mr-2 mb-2" href="';
                $value = $this->resolveValue($context->find('policy_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $context->find('str');
                $buffer .= $this->section813ec5a09be0517982e993b59ae572e1($context, $indent, $value);
                $buffer .= '</a>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD6c9c7713099e6e1d3a0d5742327ae77(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' reviewcontributions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' reviewcontributions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionEa1915e2afe8b2ed4bc70127991b37da(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<a class="btn btn-primary mr-2 mb-2" href="{{review_url}}">{{#str}} reviewcontributions, local_testcase_exchange {{/str}} <span class="badge badge-light ml-1">{{pending_contribution_count}}</span></a>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<a class="btn btn-primary mr-2 mb-2" href="';
                $value = $this->resolveValue($context->find('review_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $context->find('str');
                $buffer .= $this->sectionD6c9c7713099e6e1d3a0d5742327ae77($context, $indent, $value);
                $buffer .= ' <span class="badge badge-light ml-1">';
                $value = $this->resolveValue($context->find('pending_contribution_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span></a>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBfaacc9ad82beeea4d52803ed75a03c2(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="mb-3 d-flex flex-wrap align-items-center">
    {{#can_manage}}<a class="btn btn-secondary mr-2 mb-2" href="{{policy_url}}">{{#str}} managepolicies, local_testcase_exchange {{/str}}</a>{{/can_manage}}
    {{#can_review}}<a class="btn btn-primary mr-2 mb-2" href="{{review_url}}">{{#str}} reviewcontributions, local_testcase_exchange {{/str}} <span class="badge badge-light ml-1">{{pending_contribution_count}}</span></a>{{/can_review}}
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="mb-3 d-flex flex-wrap align-items-center">
';
                $buffer .= $indent . '    ';
                $value = $context->find('can_manage');
                $buffer .= $this->sectionBb0fa0981f84b55bb525290d43006ea0($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '    ';
                $value = $context->find('can_review');
                $buffer .= $this->sectionEa1915e2afe8b2ed4bc70127991b37da($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7f4c93c88a9f0477eae7a21e4f0de113(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' privateexploration, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' privateexploration, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section20e6029273ba25b28a497e75e6ad9f93(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<a class="btn btn-secondary mb-3" href="{{return_url}}">{{#str}} backtocurrentquiz, local_testcase_exchange {{/str}}</a>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<a class="btn btn-secondary mb-3" href="';
                $value = $this->resolveValue($context->find('return_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $context->find('str');
                $buffer .= $this->section7b108c120350250de45d032e1ccc0e06($context, $indent, $value);
                $buffer .= '</a>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBd2d40cdfbac59f93e95c6f826d86349(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' nocoderunnerquestions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' nocoderunnerquestions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7b243462cd63709e856d412a423ccfc6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' contributingtestcasefor, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' contributingtestcasefor, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section011aafb9c5a183398e8220f2138ac3e7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' currentquiz, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' currentquiz, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section66373fa0bc12e24ec9ec5b2b02abd7fe(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' currentquestion, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' currentquestion, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section813c30abbc8a83ca444a7ddc7de79f2d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="alert alert-primary" role="status">
    <strong>{{#str}} contributingtestcasefor, local_testcase_exchange {{/str}}</strong>
    <div><strong>{{#str}} currentquiz, local_testcase_exchange {{/str}}:</strong> {{current_quiz_name}}</div>
    <div><strong>{{#str}} currentquestion, local_testcase_exchange {{/str}}:</strong> {{current_question_name}}</div>
</div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="alert alert-primary" role="status">
';
                $buffer .= $indent . '    <strong>';
                $value = $context->find('str');
                $buffer .= $this->section7b243462cd63709e856d412a423ccfc6($context, $indent, $value);
                $buffer .= '</strong>
';
                $buffer .= $indent . '    <div><strong>';
                $value = $context->find('str');
                $buffer .= $this->section011aafb9c5a183398e8220f2138ac3e7($context, $indent, $value);
                $buffer .= ':</strong> ';
                $value = $this->resolveValue($context->find('current_quiz_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</div>
';
                $buffer .= $indent . '    <div><strong>';
                $value = $context->find('str');
                $buffer .= $this->section66373fa0bc12e24ec9ec5b2b02abd7fe($context, $indent, $value);
                $buffer .= ':</strong> ';
                $value = $this->resolveValue($context->find('current_question_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</div>
';
                $buffer .= $indent . '</div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE6ae7f7adcd3f965fbc7bb7fd6808afe(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<input type="hidden" name="question" value="{{selected_question_value}}"><input type="hidden" name="student_code" value="{{student_code}}">';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<input type="hidden" name="question" value="';
                $value = $this->resolveValue($context->find('selected_question_value'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><input type="hidden" name="student_code" value="';
                $value = $this->resolveValue($context->find('student_code'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section5b3c2c7359200a0f9ca8de84cb395381(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' selectquestion, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' selectquestion, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC87198b06c7ce18b3aeed72afb34afb9(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = 'disabled';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= 'disabled';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionCbe3190cb9c2ee849bc7ccfd30cf32c7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<option value="{{value}}" {{#disabled}}disabled{{/disabled}} {{#selected}}selected{{/selected}}>{{label}}</option>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<option value="';
                $value = $this->resolveValue($context->find('value'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '" ';
                $value = $context->find('disabled');
                $buffer .= $this->sectionC87198b06c7ce18b3aeed72afb34afb9($context, $indent, $value);
                $buffer .= ' ';
                $value = $context->find('selected');
                $buffer .= $this->section9e2875c627d2dbad7c957250bbb623f7($context, $indent, $value);
                $buffer .= '>';
                $value = $this->resolveValue($context->find('label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBabde6d5f03d016d0afcefdc51340b11(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' studentsource, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' studentsource, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE5482d460449c03f0f20dafaf564116b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="form-group"><label for="student_code"><strong>{{#str}} studentsource, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="student_code" name="student_code" rows="10" required>{{student_code}}</textarea></div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="form-group"><label for="student_code"><strong>';
                $value = $context->find('str');
                $buffer .= $this->sectionBabde6d5f03d016d0afcefdc51340b11($context, $indent, $value);
                $buffer .= '</strong></label><textarea class="form-control" id="student_code" name="student_code" rows="10" required>';
                $value = $this->resolveValue($context->find('student_code'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</textarea></div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionB944b350b43a30cdf4afb7551a33da5d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' testinput, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' testinput, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA232c2b70c8f3ce2647a2471a7d66f5d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' predictedoutput, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' predictedoutput, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF6d8114da9c7bff859d802d41c6c3256(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' category, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' category, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFd17c78ef00f792e56c2e6e6dbd0e401(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<option value="{{value}}">{{label}}</option>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<option value="';
                $value = $this->resolveValue($context->find('value'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $this->resolveValue($context->find('label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</option>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionC61de41a69f5133af082b83712eb88b3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' purpose, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' purpose, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section532b4b79f6bcbfdf245c28c944e13e3d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' reflection, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' reflection, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section4321b3170cc503c55e9daf7d7ce43719(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' runprivate, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' runprivate, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA1fb2f0e10fa89a72d960ebac307df6f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<button class="btn btn-primary" type="submit">{{#str}} runprivate, local_testcase_exchange {{/str}}</button>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<button class="btn btn-primary" type="submit">';
                $value = $context->find('str');
                $buffer .= $this->section4321b3170cc503c55e9daf7d7ce43719($context, $indent, $value);
                $buffer .= '</button>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD77449dff3c1415baf3e311b9bff5c55(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
{{#use_attempt_context}}
<div class="alert alert-primary" role="status">
    <strong>{{#str}} contributingtestcasefor, local_testcase_exchange {{/str}}</strong>
    <div><strong>{{#str}} currentquiz, local_testcase_exchange {{/str}}:</strong> {{current_quiz_name}}</div>
    <div><strong>{{#str}} currentquestion, local_testcase_exchange {{/str}}:</strong> {{current_question_name}}</div>
</div>
{{/use_attempt_context}}
<form method="post"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="run">
{{#use_attempt_context}}<input type="hidden" name="question" value="{{selected_question_value}}"><input type="hidden" name="student_code" value="{{student_code}}">{{/use_attempt_context}}
{{^use_attempt_context}}
<div class="form-group"><label for="question"><strong>{{#str}} selectquestion, local_testcase_exchange {{/str}}</strong></label><select class="form-control" id="question" name="question" required>{{#questions}}<option value="{{value}}" {{#disabled}}disabled{{/disabled}} {{#selected}}selected{{/selected}}>{{label}}</option>{{/questions}}</select></div>
{{#show_code_editor}}
<div class="form-group"><label for="student_code"><strong>{{#str}} studentsource, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="student_code" name="student_code" rows="10" required>{{student_code}}</textarea></div>
{{/show_code_editor}}
{{/use_attempt_context}}
<div class="row"><div class="col-md-6 form-group"><label for="test_input"><strong>{{#str}} testinput, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="test_input" name="test_input" rows="4" required></textarea></div><div class="col-md-6 form-group"><label for="predicted_output"><strong>{{#str}} predictedoutput, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="predicted_output" name="predicted_output" rows="4"></textarea></div></div>
{{^use_attempt_context}}
<div class="row"><div class="col-md-4 form-group"><label for="category">{{#str}} category, local_testcase_exchange {{/str}}</label><select class="form-control" id="category" name="category">{{#categories}}<option value="{{value}}">{{label}}</option>{{/categories}}</select></div><div class="col-md-8 form-group"><label for="purpose">{{#str}} purpose, local_testcase_exchange {{/str}}</label><input class="form-control" id="purpose" name="purpose" maxlength="1000"></div></div>
<div class="form-group"><label for="reflection">{{#str}} reflection, local_testcase_exchange {{/str}}</label><input class="form-control" id="reflection" name="reflection" maxlength="1000"></div><button class="btn btn-primary" type="submit">{{#str}} runprivate, local_testcase_exchange {{/str}}</button>
{{/use_attempt_context}}
{{#use_attempt_context}}<button class="btn btn-primary" type="submit">{{#str}} runprivate, local_testcase_exchange {{/str}}</button>{{/use_attempt_context}}
</form>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $value = $context->find('use_attempt_context');
                $buffer .= $this->section813c30abbc8a83ca444a7ddc7de79f2d($context, $indent, $value);
                $buffer .= $indent . '<form method="post"><input type="hidden" name="sesskey" value="';
                $value = $this->resolveValue($context->find('sesskey'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><input type="hidden" name="action" value="run">
';
                $value = $context->find('use_attempt_context');
                $buffer .= $this->sectionE6ae7f7adcd3f965fbc7bb7fd6808afe($context, $indent, $value);
                $buffer .= '
';
                $value = $context->find('use_attempt_context');
                if (empty($value)) {
                    
                    $buffer .= $indent . '<div class="form-group"><label for="question"><strong>';
                    $value = $context->find('str');
                    $buffer .= $this->section5b3c2c7359200a0f9ca8de84cb395381($context, $indent, $value);
                    $buffer .= '</strong></label><select class="form-control" id="question" name="question" required>';
                    $value = $context->find('questions');
                    $buffer .= $this->sectionCbe3190cb9c2ee849bc7ccfd30cf32c7($context, $indent, $value);
                    $buffer .= '</select></div>
';
                    $value = $context->find('show_code_editor');
                    $buffer .= $this->sectionE5482d460449c03f0f20dafaf564116b($context, $indent, $value);
                }
                $buffer .= $indent . '<div class="row"><div class="col-md-6 form-group"><label for="test_input"><strong>';
                $value = $context->find('str');
                $buffer .= $this->sectionB944b350b43a30cdf4afb7551a33da5d($context, $indent, $value);
                $buffer .= '</strong></label><textarea class="form-control" id="test_input" name="test_input" rows="4" required></textarea></div><div class="col-md-6 form-group"><label for="predicted_output"><strong>';
                $value = $context->find('str');
                $buffer .= $this->sectionA232c2b70c8f3ce2647a2471a7d66f5d($context, $indent, $value);
                $buffer .= '</strong></label><textarea class="form-control" id="predicted_output" name="predicted_output" rows="4"></textarea></div></div>
';
                $value = $context->find('use_attempt_context');
                if (empty($value)) {
                    
                    $buffer .= $indent . '<div class="row"><div class="col-md-4 form-group"><label for="category">';
                    $value = $context->find('str');
                    $buffer .= $this->sectionF6d8114da9c7bff859d802d41c6c3256($context, $indent, $value);
                    $buffer .= '</label><select class="form-control" id="category" name="category">';
                    $value = $context->find('categories');
                    $buffer .= $this->sectionFd17c78ef00f792e56c2e6e6dbd0e401($context, $indent, $value);
                    $buffer .= '</select></div><div class="col-md-8 form-group"><label for="purpose">';
                    $value = $context->find('str');
                    $buffer .= $this->sectionC61de41a69f5133af082b83712eb88b3($context, $indent, $value);
                    $buffer .= '</label><input class="form-control" id="purpose" name="purpose" maxlength="1000"></div></div>
';
                    $buffer .= $indent . '<div class="form-group"><label for="reflection">';
                    $value = $context->find('str');
                    $buffer .= $this->section532b4b79f6bcbfdf245c28c944e13e3d($context, $indent, $value);
                    $buffer .= '</label><input class="form-control" id="reflection" name="reflection" maxlength="1000"></div><button class="btn btn-primary" type="submit">';
                    $value = $context->find('str');
                    $buffer .= $this->section4321b3170cc503c55e9daf7d7ce43719($context, $indent, $value);
                    $buffer .= '</button>
';
                }
                $value = $context->find('use_attempt_context');
                $buffer .= $this->sectionA1fb2f0e10fa89a72d960ebac307df6f($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '</form>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section7e0ac1b1f422887f755320c47e173919(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' submitcodebeforetesting, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' submitcodebeforetesting, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA618260a25b02315a7a8cac66d0c1adf(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '{{#show_run_form}}
{{#use_attempt_context}}
<div class="alert alert-primary" role="status">
    <strong>{{#str}} contributingtestcasefor, local_testcase_exchange {{/str}}</strong>
    <div><strong>{{#str}} currentquiz, local_testcase_exchange {{/str}}:</strong> {{current_quiz_name}}</div>
    <div><strong>{{#str}} currentquestion, local_testcase_exchange {{/str}}:</strong> {{current_question_name}}</div>
</div>
{{/use_attempt_context}}
<form method="post"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="run">
{{#use_attempt_context}}<input type="hidden" name="question" value="{{selected_question_value}}"><input type="hidden" name="student_code" value="{{student_code}}">{{/use_attempt_context}}
{{^use_attempt_context}}
<div class="form-group"><label for="question"><strong>{{#str}} selectquestion, local_testcase_exchange {{/str}}</strong></label><select class="form-control" id="question" name="question" required>{{#questions}}<option value="{{value}}" {{#disabled}}disabled{{/disabled}} {{#selected}}selected{{/selected}}>{{label}}</option>{{/questions}}</select></div>
{{#show_code_editor}}
<div class="form-group"><label for="student_code"><strong>{{#str}} studentsource, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="student_code" name="student_code" rows="10" required>{{student_code}}</textarea></div>
{{/show_code_editor}}
{{/use_attempt_context}}
<div class="row"><div class="col-md-6 form-group"><label for="test_input"><strong>{{#str}} testinput, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="test_input" name="test_input" rows="4" required></textarea></div><div class="col-md-6 form-group"><label for="predicted_output"><strong>{{#str}} predictedoutput, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="predicted_output" name="predicted_output" rows="4"></textarea></div></div>
{{^use_attempt_context}}
<div class="row"><div class="col-md-4 form-group"><label for="category">{{#str}} category, local_testcase_exchange {{/str}}</label><select class="form-control" id="category" name="category">{{#categories}}<option value="{{value}}">{{label}}</option>{{/categories}}</select></div><div class="col-md-8 form-group"><label for="purpose">{{#str}} purpose, local_testcase_exchange {{/str}}</label><input class="form-control" id="purpose" name="purpose" maxlength="1000"></div></div>
<div class="form-group"><label for="reflection">{{#str}} reflection, local_testcase_exchange {{/str}}</label><input class="form-control" id="reflection" name="reflection" maxlength="1000"></div><button class="btn btn-primary" type="submit">{{#str}} runprivate, local_testcase_exchange {{/str}}</button>
{{/use_attempt_context}}
{{#use_attempt_context}}<button class="btn btn-primary" type="submit">{{#str}} runprivate, local_testcase_exchange {{/str}}</button>{{/use_attempt_context}}
</form>{{/show_run_form}}
{{^show_run_form}}<div class="alert alert-info">{{#str}} submitcodebeforetesting, local_testcase_exchange {{/str}}</div>{{/show_run_form}}
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $value = $context->find('show_run_form');
                $buffer .= $this->sectionD77449dff3c1415baf3e311b9bff5c55($context, $indent, $value);
                $buffer .= '
';
                $value = $context->find('show_run_form');
                if (empty($value)) {
                    
                    $buffer .= $indent . '<div class="alert alert-info">';
                    $value = $context->find('str');
                    $buffer .= $this->section7e0ac1b1f422887f755320c47e173919($context, $indent, $value);
                    $buffer .= '</div>';
                }
                $buffer .= '
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section304fa2eb9e4ba53d7cd3f469ac64b78b(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
<div class="card mb-4"><div class="card-header"><strong>{{#str}} privateexploration, local_testcase_exchange {{/str}}</strong></div><div class="card-body">
{{#has_return_url}}<a class="btn btn-secondary mb-3" href="{{return_url}}">{{#str}} backtocurrentquiz, local_testcase_exchange {{/str}}</a>{{/has_return_url}}
{{^has_questions}}<div class="alert alert-warning">{{#str}} nocoderunnerquestions, local_testcase_exchange {{/str}}</div>{{/has_questions}}
{{#has_questions}}{{#show_run_form}}
{{#use_attempt_context}}
<div class="alert alert-primary" role="status">
    <strong>{{#str}} contributingtestcasefor, local_testcase_exchange {{/str}}</strong>
    <div><strong>{{#str}} currentquiz, local_testcase_exchange {{/str}}:</strong> {{current_quiz_name}}</div>
    <div><strong>{{#str}} currentquestion, local_testcase_exchange {{/str}}:</strong> {{current_question_name}}</div>
</div>
{{/use_attempt_context}}
<form method="post"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="run">
{{#use_attempt_context}}<input type="hidden" name="question" value="{{selected_question_value}}"><input type="hidden" name="student_code" value="{{student_code}}">{{/use_attempt_context}}
{{^use_attempt_context}}
<div class="form-group"><label for="question"><strong>{{#str}} selectquestion, local_testcase_exchange {{/str}}</strong></label><select class="form-control" id="question" name="question" required>{{#questions}}<option value="{{value}}" {{#disabled}}disabled{{/disabled}} {{#selected}}selected{{/selected}}>{{label}}</option>{{/questions}}</select></div>
{{#show_code_editor}}
<div class="form-group"><label for="student_code"><strong>{{#str}} studentsource, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="student_code" name="student_code" rows="10" required>{{student_code}}</textarea></div>
{{/show_code_editor}}
{{/use_attempt_context}}
<div class="row"><div class="col-md-6 form-group"><label for="test_input"><strong>{{#str}} testinput, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="test_input" name="test_input" rows="4" required></textarea></div><div class="col-md-6 form-group"><label for="predicted_output"><strong>{{#str}} predictedoutput, local_testcase_exchange {{/str}}</strong></label><textarea class="form-control" id="predicted_output" name="predicted_output" rows="4"></textarea></div></div>
{{^use_attempt_context}}
<div class="row"><div class="col-md-4 form-group"><label for="category">{{#str}} category, local_testcase_exchange {{/str}}</label><select class="form-control" id="category" name="category">{{#categories}}<option value="{{value}}">{{label}}</option>{{/categories}}</select></div><div class="col-md-8 form-group"><label for="purpose">{{#str}} purpose, local_testcase_exchange {{/str}}</label><input class="form-control" id="purpose" name="purpose" maxlength="1000"></div></div>
<div class="form-group"><label for="reflection">{{#str}} reflection, local_testcase_exchange {{/str}}</label><input class="form-control" id="reflection" name="reflection" maxlength="1000"></div><button class="btn btn-primary" type="submit">{{#str}} runprivate, local_testcase_exchange {{/str}}</button>
{{/use_attempt_context}}
{{#use_attempt_context}}<button class="btn btn-primary" type="submit">{{#str}} runprivate, local_testcase_exchange {{/str}}</button>{{/use_attempt_context}}
</form>{{/show_run_form}}
{{^show_run_form}}<div class="alert alert-info">{{#str}} submitcodebeforetesting, local_testcase_exchange {{/str}}</div>{{/show_run_form}}
{{/has_questions}}</div></div>
';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '<div class="card mb-4"><div class="card-header"><strong>';
                $value = $context->find('str');
                $buffer .= $this->section7f4c93c88a9f0477eae7a21e4f0de113($context, $indent, $value);
                $buffer .= '</strong></div><div class="card-body">
';
                $value = $context->find('has_return_url');
                $buffer .= $this->section20e6029273ba25b28a497e75e6ad9f93($context, $indent, $value);
                $buffer .= '
';
                $value = $context->find('has_questions');
                if (empty($value)) {
                    
                    $buffer .= $indent . '<div class="alert alert-warning">';
                    $value = $context->find('str');
                    $buffer .= $this->sectionBd2d40cdfbac59f93e95c6f826d86349($context, $indent, $value);
                    $buffer .= '</div>';
                }
                $buffer .= '
';
                $value = $context->find('has_questions');
                $buffer .= $this->sectionA618260a25b02315a7a8cac66d0c1adf($context, $indent, $value);
                $buffer .= $indent . '</div></div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section08cb77ec4dd9c03b222e69f54d34993a(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' coursecontributions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' coursecontributions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2cfcb9ec042f9147f840659477ada1af(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <li class="nav-item"><a class="nav-link active font-weight-bold" data-toggle="tab" href="#course_contributions">{{#str}} coursecontributions, local_testcase_exchange {{/str}} ({{course_contribution_count}})</a></li>
    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <li class="nav-item"><a class="nav-link active font-weight-bold" data-toggle="tab" href="#course_contributions">';
                $value = $context->find('str');
                $buffer .= $this->section08cb77ec4dd9c03b222e69f54d34993a($context, $indent, $value);
                $buffer .= ' (';
                $value = $this->resolveValue($context->find('course_contribution_count'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= ')</a></li>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF9891d6cb4e7be1138d2f0b89848cc5f(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' myruns, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' myruns, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionF234ca24bbe7e007b280c1fc685f4fae(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' mycontributions, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' mycontributions, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section882ffa9f688030d6b54bece2b10773e5(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' myrewards, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' myrewards, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section622d1f2d1148fb424607e49d3ad122da(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<a class="btn btn-sm btn-primary" href="{{review_url}}">{{#str}} reviewcontributions, local_testcase_exchange {{/str}} &rarr;</a>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<a class="btn btn-sm btn-primary" href="';
                $value = $this->resolveValue($context->find('review_url'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $context->find('str');
                $buffer .= $this->sectionD6c9c7713099e6e1d3a0d5742327ae77($context, $indent, $value);
                $buffer .= ' &rarr;</a>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section058949d940063367d3d5381df0d810c8(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' student, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' student, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionFbf3bb14fdfb73409b8836554df1d06d(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' quizquestion, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' quizquestion, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9b9054987cd3b32d511d5845018cc8b0(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' oracleoutput, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' oracleoutput, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section99380e31c66dc018fdbb40851d8c070c(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' status ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' status ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section664f62332772dbc21a7a324f47ad636e(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' time ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' time ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDb7d5e03b02fdbe6f383a142674d4357(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' nocontributionsfound, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' nocontributionsfound, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionDcb7c630b327b3921b8c9316baeaf839(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<br><small class="text-muted">{{purpose}}</small>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<br><small class="text-muted">';
                $value = $this->resolveValue($context->find('purpose'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section6934b3556cd13e1ef08ec215d9f74237(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<div class="mt-1" title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <small class="badge badge-warning text-dark">{{rating_val}}/5 ★</small></div>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<div class="mt-1" title="';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 sao"><span class="text-warning font-weight-bold">';
                $value = $this->resolveValue($context->find('stars_emoji'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span> <small class="badge badge-warning text-dark">';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 ★</small></div>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionA945db33b7a7a3a2b3d9612f06c964bd(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 {{teacher_comment}}</div>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 ';
                $value = $this->resolveValue($context->find('teacher_comment'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</div>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section9772f68c89b33d6dbfd01fb72d678874(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<tr><td><strong>#{{id}}</strong></td><td><div><strong>{{student_name}}</strong></div><small class="text-muted">{{student_username}}</small></td><td><div><strong>{{quiz_name}}</strong></div><small class="text-muted">{{question_name}}</small></td><td><pre class="mb-0">{{input_normalized}}</pre></td><td><pre class="mb-0">{{oracle_output}}</pre></td><td><span class="badge badge-info">{{category}}</span>{{#purpose}}<br><small class="text-muted">{{purpose}}</small>{{/purpose}}</td><td><span class="{{status_badge_class}}">{{status_label}}</span>{{#has_rating}}<div class="mt-1" title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <small class="badge badge-warning text-dark">{{rating_val}}/5 ★</small></div>{{/has_rating}}{{#has_teacher_comment}}<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 {{teacher_comment}}</div>{{/has_teacher_comment}}</td><td><small>{{submitted_at}}</small></td></tr>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<tr><td><strong>#';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></td><td><div><strong>';
                $value = $this->resolveValue($context->find('student_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></div><small class="text-muted">';
                $value = $this->resolveValue($context->find('student_username'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td><td><div><strong>';
                $value = $this->resolveValue($context->find('quiz_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</strong></div><small class="text-muted">';
                $value = $this->resolveValue($context->find('question_name'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('input_normalized'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('oracle_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td><span class="badge badge-info">';
                $value = $this->resolveValue($context->find('category'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>';
                $value = $context->find('purpose');
                $buffer .= $this->sectionDcb7c630b327b3921b8c9316baeaf839($context, $indent, $value);
                $buffer .= '</td><td><span class="';
                $value = $this->resolveValue($context->find('status_badge_class'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $this->resolveValue($context->find('status_label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>';
                $value = $context->find('has_rating');
                $buffer .= $this->section6934b3556cd13e1ef08ec215d9f74237($context, $indent, $value);
                $value = $context->find('has_teacher_comment');
                $buffer .= $this->sectionA945db33b7a7a3a2b3d9612f06c964bd($context, $indent, $value);
                $buffer .= '</td><td><small>';
                $value = $this->resolveValue($context->find('submitted_at'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td></tr>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionD5e165378c5d857acff683bb0fdd36a3(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '
    <div class="tab-pane active" id="course_contributions">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="mb-0">{{#str}} coursecontributions, local_testcase_exchange {{/str}}</h5>
            {{#can_review}}<a class="btn btn-sm btn-primary" href="{{review_url}}">{{#str}} reviewcontributions, local_testcase_exchange {{/str}} &rarr;</a>{{/can_review}}
        </div>
        <div class="table-responsive"><table class="table table-sm table-striped table-hover"><thead><tr><th>ID</th><th>{{#str}} student, local_testcase_exchange {{/str}}</th><th>{{#str}} quizquestion, local_testcase_exchange {{/str}}</th><th>{{#str}} testinput, local_testcase_exchange {{/str}}</th><th>{{#str}} oracleoutput, local_testcase_exchange {{/str}}</th><th>{{#str}} category, local_testcase_exchange {{/str}}</th><th>{{#str}} status {{/str}}</th><th>{{#str}} time {{/str}}</th></tr></thead><tbody>
        {{^has_course_contributions}}<tr><td colspan="8" class="text-center text-muted py-3">{{#str}} nocontributionsfound, local_testcase_exchange {{/str}}</td></tr>{{/has_course_contributions}}
        {{#course_contributions}}<tr><td><strong>#{{id}}</strong></td><td><div><strong>{{student_name}}</strong></div><small class="text-muted">{{student_username}}</small></td><td><div><strong>{{quiz_name}}</strong></div><small class="text-muted">{{question_name}}</small></td><td><pre class="mb-0">{{input_normalized}}</pre></td><td><pre class="mb-0">{{oracle_output}}</pre></td><td><span class="badge badge-info">{{category}}</span>{{#purpose}}<br><small class="text-muted">{{purpose}}</small>{{/purpose}}</td><td><span class="{{status_badge_class}}">{{status_label}}</span>{{#has_rating}}<div class="mt-1" title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <small class="badge badge-warning text-dark">{{rating_val}}/5 ★</small></div>{{/has_rating}}{{#has_teacher_comment}}<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 {{teacher_comment}}</div>{{/has_teacher_comment}}</td><td><small>{{submitted_at}}</small></td></tr>{{/course_contributions}}
        </tbody></table></div>
    </div>
    ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= $indent . '    <div class="tab-pane active" id="course_contributions">
';
                $buffer .= $indent . '        <div class="d-flex justify-content-between align-items-center mb-3">
';
                $buffer .= $indent . '            <h5 class="mb-0">';
                $value = $context->find('str');
                $buffer .= $this->section08cb77ec4dd9c03b222e69f54d34993a($context, $indent, $value);
                $buffer .= '</h5>
';
                $buffer .= $indent . '            ';
                $value = $context->find('can_review');
                $buffer .= $this->section622d1f2d1148fb424607e49d3ad122da($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '        </div>
';
                $buffer .= $indent . '        <div class="table-responsive"><table class="table table-sm table-striped table-hover"><thead><tr><th>ID</th><th>';
                $value = $context->find('str');
                $buffer .= $this->section058949d940063367d3d5381df0d810c8($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->sectionFbf3bb14fdfb73409b8836554df1d06d($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->sectionB944b350b43a30cdf4afb7551a33da5d($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->section9b9054987cd3b32d511d5845018cc8b0($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->sectionF6d8114da9c7bff859d802d41c6c3256($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->section99380e31c66dc018fdbb40851d8c070c($context, $indent, $value);
                $buffer .= '</th><th>';
                $value = $context->find('str');
                $buffer .= $this->section664f62332772dbc21a7a324f47ad636e($context, $indent, $value);
                $buffer .= '</th></tr></thead><tbody>
';
                $buffer .= $indent . '        ';
                $value = $context->find('has_course_contributions');
                if (empty($value)) {
                    
                    $buffer .= '<tr><td colspan="8" class="text-center text-muted py-3">';
                    $value = $context->find('str');
                    $buffer .= $this->sectionDb7d5e03b02fdbe6f383a142674d4357($context, $indent, $value);
                    $buffer .= '</td></tr>';
                }
                $buffer .= '
';
                $buffer .= $indent . '        ';
                $value = $context->find('course_contributions');
                $buffer .= $this->section9772f68c89b33d6dbfd01fb72d678874($context, $indent, $value);
                $buffer .= '
';
                $buffer .= $indent . '        </tbody></table></div>
';
                $buffer .= $indent . '    </div>
';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section276f858459cc46f9ced627000e61c1c7(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' studentoutput, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' studentoutput, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionAbe614d010fb6a10d5921022b7c688b6(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<pre class="mb-0">{{oracle_output}}</pre>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<pre class="mb-0">';
                $value = $this->resolveValue($context->find('oracle_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section1a95c609d07f7e6597bd07fab0acb233(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' proposesharing, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' proposesharing, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionCe57a9ec29b5a48d2b27143381069153(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<form method="post"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="contribute"><input type="hidden" name="run_id" value="{{id}}"><button class="btn btn-sm btn-success" type="submit">{{#str}} proposesharing, local_testcase_exchange {{/str}}</button></form>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<form method="post"><input type="hidden" name="sesskey" value="';
                $value = $this->resolveValue($context->find('sesskey'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><input type="hidden" name="action" value="contribute"><input type="hidden" name="run_id" value="';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><button class="btn btn-sm btn-success" type="submit">';
                $value = $context->find('str');
                $buffer .= $this->section1a95c609d07f7e6597bd07fab0acb233($context, $indent, $value);
                $buffer .= '</button></form>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBdcb6a9a484e5b218a793ca0af5afc41(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<tr><td>{{id}}</td><td><pre class="mb-0">{{input_raw}}</pre></td><td><pre class="mb-0">{{predicted_output}}</pre></td><td><pre class="mb-0">{{student_run_output}}</pre><small>{{student_outcome}}</small></td><td>{{#show_oracle}}<pre class="mb-0">{{oracle_output}}</pre>{{/show_oracle}}{{^show_oracle}}—{{/show_oracle}}<small>{{oracle_outcome}}</small></td><td>{{display_status}}</td><td>{{#can_contribute}}<form method="post"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="contribute"><input type="hidden" name="run_id" value="{{id}}"><button class="btn btn-sm btn-success" type="submit">{{#str}} proposesharing, local_testcase_exchange {{/str}}</button></form>{{/can_contribute}}</td></tr>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<tr><td>';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('input_raw'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('predicted_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('student_run_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre><small>';
                $value = $this->resolveValue($context->find('student_outcome'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td><td>';
                $value = $context->find('show_oracle');
                $buffer .= $this->sectionAbe614d010fb6a10d5921022b7c688b6($context, $indent, $value);
                $value = $context->find('show_oracle');
                if (empty($value)) {
                    
                    $buffer .= '—';
                }
                $buffer .= '<small>';
                $value = $this->resolveValue($context->find('oracle_outcome'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</small></td><td>';
                $value = $this->resolveValue($context->find('display_status'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td><td>';
                $value = $context->find('can_contribute');
                $buffer .= $this->sectionCe57a9ec29b5a48d2b27143381069153($context, $indent, $value);
                $buffer .= '</td></tr>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section237a5b12de4e3e9871419c02873d73ea(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' starrating, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' starrating, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionE5e23567ad08a2707675347646352974(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' teachercomment, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' teachercomment, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function sectionBfaec5c595cdda909054b8cb1a9e20ed(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = ' resubmitexplanation, local_testcase_exchange ';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= ' resubmitexplanation, local_testcase_exchange ';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section8caef4868704df31045d6a8ea66a37fc(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<form method="post" class="mt-2"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="explain"><input type="hidden" name="contribution_id" value="{{id}}"><input class="form-control form-control-sm mb-1" name="explanation" required><button class="btn btn-sm btn-primary">{{#str}} resubmitexplanation, local_testcase_exchange {{/str}}</button></form>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<form method="post" class="mt-2"><input type="hidden" name="sesskey" value="';
                $value = $this->resolveValue($context->find('sesskey'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><input type="hidden" name="action" value="explain"><input type="hidden" name="contribution_id" value="';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '"><input class="form-control form-control-sm mb-1" name="explanation" required><button class="btn btn-sm btn-primary">';
                $value = $context->find('str');
                $buffer .= $this->sectionBfaec5c595cdda909054b8cb1a9e20ed($context, $indent, $value);
                $buffer .= '</button></form>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section17cea5af3ed72110e0cb70040acbc387(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<div title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <span class="badge badge-warning text-dark ml-1">{{rating_val}}/5 ★</span></div>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<div title="';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 sao"><span class="text-warning font-weight-bold">';
                $value = $this->resolveValue($context->find('stars_emoji'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span> <span class="badge badge-warning text-dark ml-1">';
                $value = $this->resolveValue($context->find('rating_val'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '/5 ★</span></div>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section2091fe7451d4f46b7dba8d5ade9a79a1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<tr><td>{{id}}</td><td><pre class="mb-0">{{input_normalized}}</pre></td><td>{{category}}</td><td><span class="{{status_badge_class}}">{{status_label}}</span>{{#can_explain}}<form method="post" class="mt-2"><input type="hidden" name="sesskey" value="{{sesskey}}"><input type="hidden" name="action" value="explain"><input type="hidden" name="contribution_id" value="{{id}}"><input class="form-control form-control-sm mb-1" name="explanation" required><button class="btn btn-sm btn-primary">{{#str}} resubmitexplanation, local_testcase_exchange {{/str}}</button></form>{{/can_explain}}</td><td>{{#has_rating}}<div title="{{rating_val}}/5 sao"><span class="text-warning font-weight-bold">{{stars_emoji}}</span> <span class="badge badge-warning text-dark ml-1">{{rating_val}}/5 ★</span></div>{{/has_rating}}{{^has_rating}}<span class="text-muted small">—</span>{{/has_rating}}{{#has_teacher_comment}}<div class="small text-muted mt-1 bg-light p-1 rounded border">💬 {{teacher_comment}}</div>{{/has_teacher_comment}}</td><td>{{submitted_at}}</td></tr>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<tr><td>';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('input_normalized'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td>';
                $value = $this->resolveValue($context->find('category'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td><td><span class="';
                $value = $this->resolveValue($context->find('status_badge_class'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '">';
                $value = $this->resolveValue($context->find('status_label'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</span>';
                $value = $context->find('can_explain');
                $buffer .= $this->section8caef4868704df31045d6a8ea66a37fc($context, $indent, $value);
                $buffer .= '</td><td>';
                $value = $context->find('has_rating');
                $buffer .= $this->section17cea5af3ed72110e0cb70040acbc387($context, $indent, $value);
                $value = $context->find('has_rating');
                if (empty($value)) {
                    
                    $buffer .= '<span class="text-muted small">—</span>';
                }
                $value = $context->find('has_teacher_comment');
                $buffer .= $this->sectionA945db33b7a7a3a2b3d9612f06c964bd($context, $indent, $value);
                $buffer .= '</td><td>';
                $value = $this->resolveValue($context->find('submitted_at'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td></tr>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

    private function section8669761b537ce5a6424ed580d3da2fe1(Mustache_Context $context, $indent, $value)
    {
        $buffer = '';
    
        if (!is_string($value) && is_callable($value)) {
            $source = '<tr><td>{{id}}</td><td><pre class="mb-0">{{input_normalized}}</pre></td><td><pre class="mb-0">{{oracle_output}}</pre></td><td>{{category}}</td><td>{{created_at}}</td></tr>';
            $result = (string) call_user_func($value, $source, $this->lambdaHelper);
            $buffer .= $result;
        } elseif (!empty($value)) {
            $values = $this->isIterable($value) ? $value : array($value);
            foreach ($values as $value) {
                $context->push($value);
                
                $buffer .= '<tr><td>';
                $value = $this->resolveValue($context->find('id'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('input_normalized'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td><pre class="mb-0">';
                $value = $this->resolveValue($context->find('oracle_output'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</pre></td><td>';
                $value = $this->resolveValue($context->find('category'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td><td>';
                $value = $this->resolveValue($context->find('created_at'), $context);
                $buffer .= ($value === null ? '' : call_user_func($this->mustache->getEscape(), $value));
                $buffer .= '</td></tr>';
                $context->pop();
            }
        }
    
        return $buffer;
    }

}
